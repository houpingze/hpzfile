#include <stdio.h>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

int read(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
int a[100005];
inline int max(int x,int y){
	return x>y?x:y;
}
priority_queue<int,vector<int>,greater<int> >Q;
priority_queue<int>Q1;
//priority_queue<int>Q;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n=read(),w=read(),num,len=1;
	a[1]=read();Q.push(a[1]);printf("%d ",Q.top());
	for(int i=2;i<=n;++i){
		//printf("%d ",i); 
		a[i]=read();num=max(1,i*w/100);
		//printf("%d 1:%d\n",a[i],Q.top());
		if(a[i]>=Q.top()){
			Q.push(a[i]);len++;
		}
		else Q1.push(a[i]);
		while(len>num){    //Q多(小)的给Q1(大)
			int x=Q.top();
			Q1.push(x);
			Q.pop();
			len--;
		}
		int h1,h2=Q1.top();
		while(len<num){       //Q少,Q1给(大)
			Q.push(h2);Q1.pop();h2=Q1.top();
			len++;
		}
		h1=Q.top(),h2=Q1.top();
		while(h1<h2){           //Q小的<Q1大的 交换 
			Q.pop();Q.push(h2);
			Q1.pop();Q1.push(h1);
			h1=Q.top();h2=Q1.top();
		}
		printf("%d ",Q.top());
	}
	printf("\n");
	return 0;
}
