#include <stdio.h>
using namespace std;

int read(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
int p[35],ans[35];
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n=read(),s=1,len=0;p[1]=2;
	for(int i=2;i<=25;++i){
		p[i]=p[i-1]*2;
	}
	while(1){
		if(p[s]>n)break;
		s++;
	}
	s--;
	for(int i=s;i>=1;--i){
		if(n==0)break;
		if(n>=p[i]){
			ans[++len]=p[i];
			n-=p[i];
		}
	}	
	if(n!=0)printf("-1\n");
	else for(int i=1;i<=len;++i)printf("%d ",ans[i]);
	return 0;
}