#include <stdio.h>
#include <cstring>
using namespace std;

int read(){
	int a1=0,k1=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')k1=-1;ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		a1=(a1<<3)+(a1<<1)+(ch^48);
		ch=getchar();
	}
	return a1*k1;
}
int n,m,a[1005][1005],f[1005][1005];
bool vis[1005][1005];
int ans=-100000000;

inline int max(int x,int y){
	return x>y?x:y;
}

void dfs(int x,int y,int k){
	if(x<1||x>n||y<1||y>m||vis[x][y])return ;
	if(x==n&&y==m){
		ans=max(ans,k);return ;
	}
	vis[x][y]=true;
	dfs(x+1,y,k+a[x+1][y]);
	dfs(x-1,y,k+a[x-1][y]);
	dfs(x,y+1,k+a[x][y+1]);
	vis[x][y]=false;
}

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			a[i][j]=read();
		}
	}
	dfs(1,1,a[1][1]);
	printf("%d\n",ans);
	return 0;
}
