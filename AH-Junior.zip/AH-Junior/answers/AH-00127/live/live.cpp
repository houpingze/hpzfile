#include<bits/stdc++.h>
using namespace std;
long long a[1000001];
bool cmp(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	long long n,i,s,w,k,m=1;
	cin>>n>>w;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
		sort(a+1,a+i+1,cmp);
		k=i*w/100;
		k=floor(k);
		s=max(m,k);
		cout<<a[s]<<' ';
	}
	return 0;
}