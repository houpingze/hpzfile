#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long  n,i;
	cin>>n;
	if(n%2==1){cout<<"-1"<<endl; return 0;}
	for(i=28;i>=1;i--)
	{
		if(n>=pow(2,i))
		{cout<<pow(2,i)<<' ';}
	}
	cout<<endl;
	return 0;
}