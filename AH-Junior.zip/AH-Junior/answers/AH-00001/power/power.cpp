#include <iostream>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,t,i,j;
	double a;
	cin>>n;
	if (n%2!=0)
	{
		cout<<"-1"<<endl;
	}
	else
	{
		a=n
		for(i=1;i<=50;i++)
		{
			if(a==2)
			{
				cout<<n<<<endl;
				return 0;
			}
			a=a/2;
		}
		if(n=6)
		{
			cout<<"4 2"<<endl;
		}
		else
		{
			t=n/2-1;
			for(i=1;i<=t;i++)
			{
				for(j=i+1;j<=t;j++)
				{
					if(pow(2,j)+pow(2,i)==n)
					{
						cout<<pow(2,j)<<" "<<pow(2,i)<<endl;
						return 0;
					}
				}
			}
		}
	}
	return 0;
}