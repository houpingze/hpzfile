#include <iostream>
#include <algorithm>
using namespace std;
int a[100005];
int s(int a,int b)
{
	return (a>b)?a:b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	long long n;
	int w;
	cin>>n>>w;
	int i,f,j=0;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=n;i++)
	{
		int x,t;
		t=i*w/100;
		if(t>=1)
		{
			x=t;
		}
		else
		{
			x=1;
		}
		sort(a,a+n,s);
		cout<<a[x-1]<<" ";
		if(a[x]==a[x-1])
		{
			f=1;
		}
		while(f)
		{
			cout<<a[x+j]<<" ";
			j++;
			if(a[x+j]!=a[x+j-1])
			{
				f=0;
			}
		}
	}
	cout<<endl;
	return 0;
}