#include <iostream>
#include <cstring>
using namespace std;
char s[1000001];
int a[100001],b[100001];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int n,q,i;
	cin>>n;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
	}
	cin>>q;
	for(i=0;i<q;i++)
	{
		cin>>b[i];
	}
	int flag=1;
	for(i=0;i<n;i++)
	{
		if(a[i]!=1)
		{
			flag=0;
		}
	}
	if(flag==1)
	{
		cout<<"1"<<endl;
		return 0;
	}
	flag=0;
	for(i=0;i<n;i++)
	{
		if(a[i]==1)
		{
			flag=1;
		}
	}
	if(flag==0)
	{
		cout<<"0"<<endl;
	}
	return 0;
}