#include <iostream>
using namespace std;
int a[51][51];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int i,j;
	int s=0;
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			cin>>a[i][j];
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=1;j<m;j++)
		{
			if(a[i+1][j]>a[i][j+1] && a[i+1][j+1]>a[i][j+1])
			{
				s+=a[i+1][j];
				break;
			}
			else if(a[i+1][j+1]>a[i][j+1] && a[i+1][j+1]>a[i+1][j])
			{
				s+=a[i+1][j+1];
				break;
			}
			else if(a[i][j+1]>a[i+1][j+1] && a[i][j+1]>a[i+1][j])
			{
				s+=a[i][j+1];
			}
		}
	}
	cout<<s<<endl;
	return 0;
}
