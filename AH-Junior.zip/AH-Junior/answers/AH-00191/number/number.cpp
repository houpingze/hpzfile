#include <bits/stdc++.h>
using namespace std;
ifstream fin("number.in");
ofstream fout("number.out");
long long n,m,s[1002][1002],f[1002][1002][3];
int main() {
	long long i,j;
	fin>>n>>m;
	for(i=1;i<=n;i++) {
		for(j=1;j<=m;j++) {
			fin>>s[i][j];
		}
	}
	for(i=1;i<=n;i++) {
		f[i][1][0]=f[i-1][1][0]+s[i][1];
	}
	for(j=2;j<=m;j++) {
		f[1][j][1]=f[1][j-1][0]+s[1][j];
		for(i=2;i<=n;i++) {
			f[i][j][1]=max(f[i][j-1][0],f[i-1][j][1])+s[i][j];
		}
		f[n][j][2]=f[n][j-1][0]+s[n][j];
		for(i=n-1;i>=1;i--) {
			f[i][j][2]=max(f[i][j-1][0],f[i+1][j][2])+s[i][j];
		}
		for(i=1;i<=n;i++) {
			f[i][j][0]=max(f[i][j][1],f[i][j][2]);
		}
	}
	fout<<f[n][m][0];
	fin.close();
	fout.close();
	return 0;
}
