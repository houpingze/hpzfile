#include <bits/stdc++.h>
using namespace std;
ifstream fin("power.in");
ofstream fout("power.out");
long long n;
int main() {
	long long k=1;
	fin>>n;
	if(n%2==1) {
		fout<<-1;
	} else {
		while(k<=n) {
			k*=2;
		}
		for(;k>1;k/=2) {
			if(n>=k) {
				n-=k;
				fout<<k<<' ';
			}
		}
	}
	fin.close();
	fout.close();
	return 0;
}
