#include <bits/stdc++.h>
using namespace std;
ifstream fin("live.in");
ofstream fout("live.out");
long long n,m,w,s[100010];
long long find(long long p) {
	long long l=1,r=p-1,mid;
	while(l<r) {
		mid=(l+r)/2;
		if(s[mid]==s[p]) {
			return mid;
		} else {
			if(s[mid]>s[p]) {
				l=mid+1;
			} else {
				r=mid;
			}
		}
	}
	if(s[l]>s[p]) {
		l++;
	}
	return l;
}
int main() {
	long long i,j,k,t;
	fin>>n>>w;
	for(i=1;i<=n;i++) {
		fin>>s[i];
		m=max((long long)1,i*w/100);
		k=s[i];
		t=find(i);
		for(j=i;j>t;j--) {
			s[j]=s[j-1];
		}
		s[t]=k;
		fout<<s[m]<<' ';
	}
	fin.close();
	fout.close();
	return 0;
}
