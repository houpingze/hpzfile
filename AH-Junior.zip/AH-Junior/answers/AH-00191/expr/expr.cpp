#include <bits/stdc++.h>
using namespace std;
ifstream fin("expr.in");
ofstream fout("expr.out");
long long n,m,tail,q[1000010];
bool s[100010];
string c;
vector<long long> v;
struct node {
	long long l,r;
} p[1000010];
void connect() {
	long long i;
	tail=0;
	for(i=0;i<v.size();i++) {
		switch(v[i]) {
			case -1: {
				p[i].l=q[tail-1]+1;
				p[i].r=q[tail]+1;
				q[--tail]=i;
				break;
			}
			case -2: {
				p[i].l=q[tail-1]+1;
				p[i].r=q[tail]+1;
				q[--tail]=i;
				break;
			}
			case -3: {
				p[i].l=q[tail]+1;
				q[tail]=i;
				break;
			}
			default: {
				q[++tail]=i;
				break;
			}
		}
	}
	return;
}
bool find(long long h) {
	long long a=p[h].l-1,b=p[h].r-1;
	switch(v[h]) {
		case -1: {
			if(!find(a)) {
				return false;
			}
			if(!find(b)) {
				return false;
			}
			return true;
			break;
		}
		case -2: {
			if(find(a)) {
				return true;
			}
			if(find(b)) {
				return true;
			}
			return false;
			break;
		}
		case -3: {
			return !find(a);
			break;
		}
		default: {
			return s[v[h]];
			break;
		}
	}
}
int main() {
	long long i,j,k;
	getline(fin,c);
	c=c+' ';
	for(i=0;i<c.size();i++) {
		switch(c[i]) {
			case 'x': {
				for(i++,k=0;c[i]!=' ';i++) {
					k=k*10+c[i]-'0';
				}
				v.push_back(k);
				break;
			}
			case '&': {
				i++;
				v.push_back(-1);
				break;
			}
			case '|': {
				i++;
				v.push_back(-2);
				break;
			}
			case '!': {
				i++;
				v.push_back(-3);
				break;
			}
			case ' ': {
				i++;
				break;
			}
		}
	}
	fin>>n;
	getline(fin,c);
	getline(fin,c);
	c=c+' ';
	for(i=0,j=1;i<c.size();i++) {
		if(c[i]!=' ') {
			s[j++]=c[i]-'0';
		}
	}
	connect();
	fin>>m;
	for(i=1;i<=m;i++) {
		fin>>k;
		s[k]=!s[k];
		fout<<find(v.size()-1)<<endl;
		s[k]=!s[k];
	}
	fin.close();
	fout.close();
	return 0;
}
