#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a[10001][10001],b[10001][10001];
int n,m,q=-10001;
void xunzhao(int x,int y,int z)
{
	if(x==n&&y==m)
	{
		if(z>q)
			q=z;
	}
	else
	{
		if(a[x-1][y]&&b[x-1][y]!=1)
		{
			b[x-1][y]=1;
			xunzhao(x-1,y,z+a[x-1][y]);
		}
		if(a[x+1][y]&&b[x+1][y]!=1)
		{
			b[x+1][y]=1;
			xunzhao(x+1,y,z+a[x+1][y]);
		}
		if(a[x][y+1]&&b[x][y+1]!=1)
		{
			b[x][y+1]=1;
			xunzhao(x,y+1,z+a[x][y+1]);
		}
	}
	b[x][y]=0;
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	}
	xunzhao(1,1,a[1][1]);
	printf("%d",q);
	fclose(stdin);
	fclose(stdout);
	return 0;
}