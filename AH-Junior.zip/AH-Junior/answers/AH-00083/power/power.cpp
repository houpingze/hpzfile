#include<iostream>
#include<cstdio>
using namespace std;
int a[10000001];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,m,z=1,i=0;
	scanf("%d",&n);
	if(n%2!=0)
		printf("-1");
	else
	{
		m=n/2;
		while(m!=0)
		{
			i++;
			if(m-z>=0)
			{
				a[0]=m;
				m-=z;
				a[i]=z*2;
				z*=2;
			}
			else
			{
				i--;
				a[i]=a[0]*2;
				m=0;
			}
		}
		for(int j=i;j>1;j--)
			printf("%d ",a[j]);
		printf("%d",a[1]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}