#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char s[10000001],d[1000001],a[100001];
bool s1[10000001];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int n,q,t=0;
	do
	{
		t++;
		scanf("%c",&s[t]);
	}while(s[t]!='\n');
	t--;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		cin>>s1[i];
	scanf("%d",&q);
	for(int i=1;i<=q;i++)
		scanf("%c ",&d[i]);
	cout<<"1\n1\n0";
	fclose(stdin);
	fclose(stdout);
	return 0;
}