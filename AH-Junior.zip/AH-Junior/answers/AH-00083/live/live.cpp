#include<iostream>
#include<cstdio>
#include<math.h>
using namespace std;
int a[100001],b[601],c[100001];
float w;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,m1=0,z,x,q;
	cin>>n>>w;
	w/=100;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[a[i]]++;
		if(a[i]>m1)
			m1=a[i];
		q=i;
		x=q*w;
		z=max(1,x);
		for(int j=m1;j>=0;j--)
		{
			if(z>0&&b[j])
			{
				z-=b[j];
				c[i]=j;
			}
		}
	}
	for(int i=1;i<n;i++)
		printf("%d ",c[i]);
	printf("%d",c[n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}