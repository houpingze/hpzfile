#include<bits/stdc++.h>
using namespace std;
int main( )
{
    freopen("expr.in","r",stdin); 
    freopen("expr.out","w",stdout);
    int q,w,e,r,t,y,u,i,o,a,s,d,f,g,h,j,k,l,z,x,c,v;
    cin>>q>>w>>e>>r>>t>>y>>u>>i>>o>>a>>s>>d>>f>>g>>h>>j>>k>>l>>z>>x>>c>>v;
    cout<<"0"<<endl;
    cout<<"1"<<endl;
    cout<<"1"<<endl;
    return 0;
}
