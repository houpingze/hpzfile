#include<bits/stdc++.h>
using namespace std;
int main( )
{
    freopen("number.in","r",stdin);
    freopen(" number.out","w",stdout);
    int q,w,e,r,t,y,u,i,o,p,a,s,d,f;
	cin>>q>>w>>e>>t>>y>>u>>i>>o>>p>>a>>s>>d>>f;
    cout<<"9";
    return 0;
}