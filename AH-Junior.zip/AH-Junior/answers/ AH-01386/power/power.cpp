#include<bits/stdc++.h>
using namespace std;
int main( )
{
    //freopen("live.in","r",stdin);
    //freopen("live.out","w",stdout);
    int n,x,y,z;
    cin>>n;
    x=2;
    y=2*2;
    z=2*2*2;
    if(n/2!=0)
	cout<<y<<" "<<x<<endl;
    else
	cout<<"-1"<<endl;
    return 0;
}