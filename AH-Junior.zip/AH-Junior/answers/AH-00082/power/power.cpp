#include<stdio.h>
bool a[11];
int b[31]={1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824};
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,n1,i;
	scanf("%d",&n);
	n1=n,i=1;
	while(n1!=0)
	{
		a[i]=n1%2;
		n1/=2;
		i++;
	}
	if(a[1]==1)
	{
		printf("-1");
		return 0;
	}
	for(int i1=i-1;i1>=1;i1--)
	{
		if(a[i1]==1)
		printf("%d ",b[i1-1]);
	}
	return 0;
}
