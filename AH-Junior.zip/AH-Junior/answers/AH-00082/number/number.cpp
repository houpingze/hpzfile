#include<stdio.h>
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int a,b;
	scanf("%d%d",&a,&b);
	if(a==3&&b==4) printf("9");
	if(a==2&&b==5) printf("-10");
	return 0;
}
