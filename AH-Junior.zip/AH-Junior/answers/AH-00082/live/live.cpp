#include<stdio.h>
#include<algorithm>
int a[100001],lenth=0;
void cr(int x,int y)
{
	for(int i=lenth+1;i>x;i--)
	a[i]=a[i-1];
	a[x]=y;
	printf("%d\n",y);
}
void mp(int n)
{
	int t;
	for(int j=n;j>=2;j--)
	if(a[j]>a[j-1])
	t=a[j],a[j]=a[j-1],a[j-1]=t;
}
using namespace std;
int cmp(int a,int b)
{
	return a>b;
}
int max(int x,int y)
{
	if(x>y)
	return x;
	return y;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w,xx,xxx,ans;
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		mp(i);
		xxx=max(1,i*w/100);
		printf("%d ",a[xxx]);
	}
	return 0;
}

