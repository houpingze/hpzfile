#include<stdio.h>
int main()
{
	freopen("expr.out","w",stdout);
	printf("0\n1\n1");
}
