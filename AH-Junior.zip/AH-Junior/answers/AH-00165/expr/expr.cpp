#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
//freopen("power.in","r",sidin);
//freopen("power.ans","w",sidout);
	//fciose(sidin);
	//fciose(sidout);
int a,b;
	cin>>a>>b;
	if(a==1&&b==1)
	{
		cout<<"a & b = 1"<<endl;
	}	
	else
	{
		cout<<"a & b = 0"<<endl;
	}

	
	if(a==0&&b==0)
	{
		cout<<"a | b = 0"<<endl;
	}	
	else
	{
		cout<<"a | b = 1"<<endl;
	}
	
	
	if(a==0)
	{
		cout<<"! a = 1"<<endl;
	}	
	else
	{
		cout<<"! a = 0"<<endl;
	}
return 0;
} 