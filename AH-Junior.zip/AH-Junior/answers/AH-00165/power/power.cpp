#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
//freopen("power.in","r",sidin);
//freopen("power.ans","w",sidout);
	//fciose(sidin);
	//fciose(sidout);
int x;
	for(int i=0;i<=1024;i++)
	{
		cin>>x;
		if(x%2==0)
		{
			cout<<x<<" "<<x/2;
			
		}
		else
		{
			cout<<"-1";
		}
	}
return 0;
}