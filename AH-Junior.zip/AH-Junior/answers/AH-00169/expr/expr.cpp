#include<bits/stdc++.h>
using namespace std;
char s[10000];
int n;
int a[100000];
int q;
int b[100000];
int s1[10000];
int p;
int m=1;
int main()
{
  freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
    gets(s);
	cin>>n;
	for(int i=0;i<n;i++)
	    scanf("%d",&a[i]);
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	    scanf("%d",&b[i]);
	for(int i=0;i<strlen(s);i++)
	{
	    if(s[i]>='0'&&s[i]<='9')
	    {s1[p]=s[i]-'0';p++;a[i]++;
		}
		
	}
	for(int i=0;i<p;i++)
	{
	    if(s1[b[i]]==0) s1[b[i]]=1;
		else s1[b[i]]=0;
	}
	for(int i=0;i<strlen(s);i++)
	{
	    if(s[i]=='&')
		{
            if(s1[m-1]==1&&s1[m]==1) {s1[m-1]=-1;s1[m]=1;}
            else {s1[m-1]=-1;s1[m]=0;}
		}
		else
		if(s[i]=='|')
		{
			if(s1[m-1]==0&&s1[m]==0) {s1[m-1]=-1;s1[m]=0;}
            else {s1[m-1]=-1;s1[m]=1;}
		}
	}
	for(int i=0;i<p;i++)
	    printf("%d\n",s1[m]);
	return 0;
}