#include<bits/stdc++.h>
using namespace std;
int n,w,y,ans,cnt,num;
int a[100000],s[100000];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(int i=0;i<n;i++)
	{
		ans+=a[i];
		sort(a,a+i+1,greater<int>());
		y=(i+1)*w/100;
		num=max(1,y);
	    cnt=a[num-1];
	    printf("%d ",cnt);
    } 
	return 0;
}