#include<bits/stdc++.h>
using namespace std;
int n;
int a[500000];
int k;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%d",&n);
	if(n%2==1) {printf("-1"); return 0;}
	else
	if(n%2==0)
	{
		for(int i=2;n!=0;i+=2)
		{ 
			if(n<i&&n!=0)
			{
				printf("-1");
				return 0;
			}
			else
			if((n-i)%2==0)
			{
			    a[k]=i;
				k++;
				n-=i;
			}
		}
	}
	sort(a,a+k+1,greater<int>());
	for(int i=0;i<k;i++)
		printf("%d ",a[i]);
	return 0;
}