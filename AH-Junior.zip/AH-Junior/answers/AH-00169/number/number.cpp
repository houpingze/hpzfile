#include<bits/stdc++.h>
using namespace std;
int n,m,ans,p,q;
int a[1000][1000];
bool pd=false;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			scanf("%d",&a[i][j]);
	ans+=a[0][0];
	a[0][0]=10001;
	int num=0;
	for(int j=0;a[n-1][m-1]!=10001;j++)
	{
		if(p>0&&p<n-1)
		{
			if(a[p+1][q]==a[p][q+1]&&a[p][q+1]==a[p-1][q])
			{ans+=a[p][q+1];a[p][++q]=10001;}
		    if(a[p+1][q]!=10001)
		    {num=max(a[p+1][q],a[p][q+1]);}
			if(a[p-1][q]!=10001)
			{
			    num=max(num,a[p-1][q]);
			}
            if(num==a[p+1][q]) 
			{a[++p][q]=10001;}
		    else
			if(num==a[p][q+1])
			{a[p][++q]=10001;}
			else
			if(num==a[p-1][q])
			{a[--p][q]=10001;}
			ans+=num;
		}
		else
		if(q==m-1)
		{
		    if(a[p][q]!=10001)
		    for(int i=p;i<=n-1;i++)
			    ans+=a[i][m-1];
			else
			for(int i=p+1;i<=n-1;i++)
		        ans+=a[i][m-1];	
			printf("%d",ans);
			pd=true;
			break;
		}
		else
		if(p==n-1)
		{
		    if(a[p-1][q]!=10001) 
			{
			    if(a[p-1][q]==a[p][q+1]) {ans+=a[p][q+1];a[p][++q]=10001;}
				num=max(a[p-1][q],a[p][q+1]);
				if(num==a[p-1][q])
				{a[--p][q]=10001;}
				else
				{a[p][++q]=10001;}
				ans+=num;
			}
			else
			{ans+=a[p][++q];a[p][q]=10001;}
		}
		else
		if(p==0&&q>=0)
		{
		    if(a[p+1][q]!=10001)
			{
		        num=max(a[p+1][q],a[p][q+1]);
			    if(num==a[p+1][q])
			    {a[++p][q]=10001;}
			    else
			    {a[p][++q]=10001;}
	            ans+=num;
			}
			else
			{ans+=a[p][++q];a[p][q]=10001;}
		}
	}
	if(pd==false) printf("%d",ans);
	return 0;
}