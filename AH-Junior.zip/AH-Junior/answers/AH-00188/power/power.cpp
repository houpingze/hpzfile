#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
    long long int n;
    if(n==2)
      cout<<"2";
    else if(n==4)
      cout<<"2 2";
	else if (n==6)
      cout<<"4 2";
    else if(n==8)
      cout<<"4 4";
    else if(n%2!=0)
      cout<<"-1";
	fclose(stdin);
	fclose(stdout);
    return 0;
}