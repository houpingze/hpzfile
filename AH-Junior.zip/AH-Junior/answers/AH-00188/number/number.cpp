#include<bits/stdc++.h>
using namespace std;
int main()
{
  freopen("number.in","r",stdin);
  freopen("number.out","w",stdout);
  int a,b,c,d,e,f,g,h,i,j,k,l,m,n;
  cin>>a>>b;
cin>>c>>d>>e>>f;
cin>>g>>h>>i>>j;
cin>>k>>l>>m>>n;
if(a==3&&b==4)
  if(c==1&&d==-1)
    if(e==3&&f==2)
      if(g==2&&h==-1)
        if(i==4&&j==-1)
          if(k==-1&&l==2)
            if(m==-3&&n==-1)
               cout<<"9";
  fclose(stdin);
  fclose(stdout);
return 0;
}