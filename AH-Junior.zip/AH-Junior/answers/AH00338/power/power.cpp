#include<iostream>
#include<math.h>
#include<cstdio>
using namespace std;
int main()
{   
	//freopen("power.in","r",stdin);
	//freopen("power.out","w",stdout);
	int n,a=1,x[10001]={0},i=10000;
	cin>>n;
	while(n>0)
	{
		a*=2;
		n-=a;
		x[i]=a;
		i--;
	}
	if(n==0||n%2==0)
	{
		for(i=10000;i>=1;i--)
		{
			if(x[i]==0)
			{
				break;
			}
			else cout<<x[i]<<" ";
		}
	}
	else if(n%2!=0)cout<<"-1";
	return 0;
}