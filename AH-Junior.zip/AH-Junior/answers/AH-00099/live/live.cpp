#include <bits/stdc++.h>
using namespace std;
int a[100001],b[100001];
int main()
{
  freopen("live.in","r",stdin);
  freopen("live.out","w",stdout);
	int n,w,m;
	cin>>n>>w;
    for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
	{
		m=ceil(i*w/100);
		if(m<1)
			m++;
		for(int j=1;j<=i;j++)
		{
			b[j]=a[j];
			b[j+1]=b[j+1];
			if(b[j+1]>b[j])
			swap(b[j],b[j+1]);
		    cout<<b[m]<<endl;
	    } 
	}
    return 0;
}
