#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("power.in","r",stdin);
    freopen("power.out","w",stdout);
    long long n,a=1;
	cin>>n;
    if(n%2!=0)
	cout<<"-1"<<endl;
	while(n!=0)
	{
		a*=2;
		if(a>n)
		{
			n-=a/2;
			cout<<a/2<<' ';
			a=1;
		}
		else if(a==n)
		{
			cout<<a<<endl;
			n-=a;
		}
	}
    return 0;
}