#include<cstdio>
#include<iostream>
using namespace std;
int a[1005][1005],n,m;
int f[1005][1005];
int p[1005][1005];
int t[1005][1005];
int max(int a,int b,int c){
	if (a>b){
		if (a>c) return a;
		else return c;
	}
	else {
		if (b>c) return b;
		else return c;
	}
}
int dfs(int i,int j){
	if (p[i][j]) return f[i][j];
	if (i==1&&j==1) return f[1][1];
	int p1=-1e9,p2=-1e9,p3=-1e9;
	if (i-1>=1&&t[i-1][j]==0) {t[i][j]=1;p1=dfs(i-1,j);t[i][j]=0;}
	if (j-1>=1&&t[i][j-1]==0) {t[i][j]=1;p2=dfs(i,j-1);t[i][j]=0;}
	if (i+1<=n&&t[i+1][j]==0) {t[i][j]=1;p3=dfs(i+1,j);t[i][j]=0;}
	f[i][j]=max(p1,p2,p3)+a[i][j];
	p[i][j]=1;
	return f[i][j];
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf ("%d %d",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			scanf ("%d",&a[i][j]);
	f[1][1]=max(0,a[1][1]);
	printf ("%d\n",dfs(n,m));
	return 0;
}