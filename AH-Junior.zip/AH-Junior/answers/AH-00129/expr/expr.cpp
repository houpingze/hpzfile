#include<bits/stdc++.h>
char s[10000005];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	gets(s);
	int n;
	scanf ("%d",&n);
	for (int i=1;i<=n;i++) printf ("1\n");
	return 0;
}