#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
int n,w,a[100005],pos;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf ("%d %d",&n,&w);
	for (int i=1;i<=n;i++){
		scanf ("%d",&pos);
		int p=max(1,i*w/100);
		int j=1;
		for (;j<i&&pos<a[j];j++);
		for (int k=i;k>j;k--) a[k]=a[k-1];
		a[j]=pos;
		printf ("%d ",a[p]);
	}
	return 0;
}