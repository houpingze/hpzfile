#include<cstdio>
int s=1<<30;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	scanf ("%d",&n);
	if (n%2) {printf ("-1");return 0;}
	while (n){
		while (s>n) s/=2;
		printf ("%d ",s);
		n-=s;
	}
	return 0;
}