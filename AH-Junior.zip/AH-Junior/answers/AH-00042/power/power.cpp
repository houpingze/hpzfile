#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("power.in");
ofstream fout("power.out");

const int maxN = 1e4 + 10;

unsigned long long n, AnsArr[int(maxN)];
long long ans[int(maxN)];

int num, ansnum = 1, AnsN = 1;
bool flag = false;

inline void rev();
inline void pre();
void dfs(int, long long);

int main()
{
	fin >> n;
	pre();
	dfs(1, n);
	if (!flag)
		fout << -1;
	else
		for (int i = 1; i < AnsN; i++)
			fout << ans[i] << ' ';
	return 0;
}

inline void pre()
{
	ans[1] = -1;
	unsigned long long x = 2;
	for (int i = 1; x <= n; i++)
	{
		AnsArr[i] = x;
		num = i;
		x *= 2;
	}
	rev();	
}

inline void rev()
{
	for (int i = 1, j = num; i < j; i++, j--)
		swap(AnsArr[i], AnsArr[j]);
}

void dfs(int thisNum, long long tot)
{
	if (tot < 0 || flag)
		return;
	if (tot == 0)
	{
		flag = true;
		AnsN = ansnum;
		return;
	}
	ans[ansnum++] = AnsArr[thisNum];
	dfs(thisNum + 1, tot - AnsArr[thisNum]);
	ansnum--;
}
