#include <fstream>
using namespace std;

ifstream fin("expr.in");
ofstream fout("expr.out");

int main()
{
  fout << "0\n1\n1";
  fout.close();
  return 0;
}
