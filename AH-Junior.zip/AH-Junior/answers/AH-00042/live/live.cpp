#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("live.in");
ofstream fout("live.out");

const int maxN = 1e6 + 10;

int n, w, mark[maxN];

bool cmp(int, int);
inline int max(int, int);

int main()
{
	fin >> n >> w;
	for (int i = 1; i <= n; i++)
	{
		fin >> mark[i];
		sort(mark + 1, mark + 1 + i, cmp);
		int result = max(int(1), i * w / 100);
		fout << mark[result] << ' ';
	}
	return 0;
}

bool cmp(int a, int b) { return (a > b); }
inline int max(int a, int b)
{
	if (a > b) return a;
	return b;
}
