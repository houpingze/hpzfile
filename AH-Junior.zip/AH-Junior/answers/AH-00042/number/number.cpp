#include <fstream>

using namespace std;

ifstream fin("number.in");
ofstream fout("number.out");

const int maxN = 1e4 + 10, moveCol [] = {1, 0, 0}, moveLine [] = {0, 1, -1};

int n, m, graph[maxN][maxN];
bool flag[maxN][maxN];
long long ans = -(9e15);

void dfs(int, int, long long);

int main()
{
	fin >> n >> m;
	for (int i = 1; i < n; i++)
		for (int j = 1; j < m; j++)
			fin >> graph[i][j];
	dfs(1, 1, 0);
	fout << ans + 1;
	return 0;
}

void dfs(int col, int line, long long tot)
{
	flag[line][col] = true;
	if (col > m || line > n || line < 1)
		return;
	if (line == n && col == m)
	{
		tot += graph[line][col];
		if (tot > ans)
			ans = tot;
		return;
	}
	for (int i = 0; i < 3; i++)
	{
		int col1 = col + moveCol[i], line1 = line + moveLine[i];
		if (!flag[line1][col1])
			dfs(col1, line1, tot + graph[line][col]);
		flag[line1][col1] = false;
	}
}
