#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
using namespace std;
double n,w,m,a[10005],b[10005];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	w/=100;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sort(a+1,a+1+i,greater<double>());
		m=max(1.0,(i*w));
		b[i]=a[(int)m];
	}
	for(int i=1;i<=n;i++){
		cout<<b[i]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}