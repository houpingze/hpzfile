#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
using namespace std;
int n,m,a[1005][1005],f[1005][1005],dir[4][2]={{},{1,0},{0,1},{-1,0}};
bool vis[1005][1005];
void dfs(int x,int y,int v){
	if(f[x][y]>=v){
		return ;
	}
	f[x][y]=v;
	if(x==n&&y==m){
		return ;
	}
	for(int i=1;i<=3;i++){
		int b=x+dir[i][0],c=y+dir[i][1];
		if(b>=1&&c>=1&&b<=n&&c<=m&&!vis[b][c]){
			vis[b][c]=true;
			dfs(b,c,v+a[b][c]);
			vis[b][c]=false;
		}
	}
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
		}
	}
	memset(f,-0x3f,sizeof(f));
	dfs(1,1,a[1][1]);
	vis[1][1]=true;
	cout<<f[n][m];
	fclose(stdin);
	fclose(stdout);
	return 0;
}