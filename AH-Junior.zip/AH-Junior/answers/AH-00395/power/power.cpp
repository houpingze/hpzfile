#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
using namespace std;
int n,cnt,a[10005];
void dfs(int x,int y,int v){
	if(y==n){
		for(int i=1;i<v;i++){
			cout<<pow(2,a[i])<<" ";
		}
		exit(0);
	}
	if(x==0) return ;
	if(y+pow(2,x)<=n){
		a[v]=x;
		dfs(x-1,y+pow(2,x),v+1);
	}
	dfs(x-1,y,v);
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	while(1){
		if(n<pow(2,cnt)){
			break;
		}
		cnt++;
	}
	cnt--;
	dfs(cnt,0,1);
	cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}