#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cmath>
using namespace std;
const int N=1005;
long long n,m,a[N][N],ans; long long f[N][N];
bool vis[N][N];
long long d[3][2]={{1,0},{0,1},{-1,0}};
long long maxx(long a,long b){
	if(a>b) return a;
	else return b;
}
int dfs(int  s1,int s2,long long sum){
	if(f[s1][s2]>=sum){
		return f[s1][s2];
	}
	vis[s1][s2]=1;
	if(s1==n&&s2==m){
		f[s1][s2]=max(f[s1][s2],sum);
		return f[s1][s2];
	}
	for(int i=0;i<3;i++){
		int ss1=s1+d[i][0];
		int ss2=s2+d[i][1];
		if(ss1>=1&&ss1<=n&&ss2>=1&&ss2<=m&&vis[ss1][ss2]==0){
			vis[ss1][ss2]=1;
			f[s1][s2]=maxx(dfs(ss1,ss2,sum+a[ss1][ss2]),f[s1][s2]);
			vis[ss1][ss2]=0;
		}
	}
	return f[s1][s2];
}
void dfss(int  s1,int s2,long long sum){
	vis[s1][s2]=1;
	if(s1==n&&s2==m){
		ans=maxx(sum,ans);
		return ;
	}
	for(int i=0;i<3;i++){
		int ss1=s1+d[i][0];
		int ss2=s2+d[i][1];
		if(ss1>=1&&ss1<=n&&ss2>=1&&ss2<=m&&vis[ss1][ss2]==0){
			vis[ss1][ss2]=1;
			dfss(ss1,ss2,sum+a[ss1][ss2]);
			vis[ss1][ss2]=0;
		}
	}
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	ans=-1<<30;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
			f[i][j]=-10000000000;
		}
	}
	if(n<=5&&m<=5){
		dfss(1,1,a[1][1]);
		printf("%lld",ans);
	}
	else{
		ans=dfs(1,1,a[1][1]);
		printf("%lld\n",ans);
	}
	return 0;
}
