#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cmath>
using namespace std;
int n;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%d",&n);
	if(n%2==1){
		printf("-1");
		return 0;
	}
	int temp=16777216;
	while(n!=0){
		if(n>=temp){
			n-=temp;
			printf("%d ",temp);
		}
		temp/=2;
	}
	return 0;
}
