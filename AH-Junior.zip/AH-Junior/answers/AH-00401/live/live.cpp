#include <cstdio>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
#include <queue>
using namespace std;
const int N=100005;
int a[N],n,w,b[N];
bool cmp(int a,int b){
	return a>b;
}
priority_queue <int> q;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	int p; int j=1;
	for(int i=1;i<=n;i++){
		j=1;
		p=i*w;
		p/=100;
		if(p<2){
			p=1;
		}
		/*b[i]=a[i];
		sort(b+1,b+i+1,cmp);
		printf("%d ",b[p]);*/
		q.push(a[i]);
		while(p!=1){
			b[j++]=q.top();
			q.pop();
			p--;
		}
		printf("%d ",q.top());
		for(int k=1;k<j;k++){
			q.push(b[k]);
		}
	}
	return 0;
}
