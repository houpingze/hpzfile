#include <bits/stdc++.h>
using namespace std;
int main ()
{
freopen("number.in","r",stdin);
freopen("number.out","w",stdout);
int n,m,a[10001][10001];
cin>>n>>m;
for (int i=1;i<=n;i++)
for (int j=1;j<=m;j++)
    cin>>a[i][j];
}