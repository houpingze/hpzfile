#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int main()
{
	 freopen("expr.in","r",stdin);
	 freopen("expr.out","w",stdout);
	 char s[10001],ss;
	 int n,p,i[10001]={0},c[10001]={0},s[10001]={0},pp,js=0,cs=1;
	 int mid [10001]={0},aa[10001]={0};
	 gets(s);
	 for(int i=0;i<n;i++) if(s[i]!=0) {js++;break;}
	 cin>>n;
	 for (int i=1;i<=n;i++) {cin>>a[i];mid[i]=a[i];}
	 cin>>p;
	 for (int i=1;i<=p;i++) cin>>c[i];
	 for(int i=1;i<=p;i++}
	 {
	     pp=1;
		 cs=1;
		 aa[10001]={0};
	     for (int i=1;i<=n;i++) {mid[i]=a[i];}
	     if(mid[i]==1) mid[i]=0;
		 else mid[i]=1;
		 for(int j=1;j>=10000;j++) if (s[j]=='&'||s[j]=='|'||s[j]=='!') {ss=s[j];break;}
		 while(js!<0)
		 {
		     if (ss=='&')if (a[pp]==1&&a[pp+1]==1) aa[cs]=1;else aa[cs]=0;
			 cs++; js=js-2;s[i]=aa[cs];if (js==0)break;
		     if (ss=='|')if (a[pp]==0&&a[pp+1]==0) aa[cs]=0;else aa[cs]=1;
			 cs++;js=js-2;s[i]=aa[cs];if (js==0)break;
		     if (ss=='!')if (a[pp]==0) aa[cs]=1;else aa[cs]=0;if (a[pp+1]==0) aa[cs+1]=1;else aa[cs+1]=0;
			 cs++;js=js-2;s[i]=aa[cs];if (js==0)break;
		 } 
	 }
	 for (int i=1;i<=p;i++)cout<<s[i]<<endl;
	 return 0;
}
