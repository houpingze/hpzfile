#include <iostream>
#include <cstdio>
using namespace std;
long long n,w,a[10001],b[10001]={0},max=2,mid=0;
int main ()
{
freopen("live.in","r",stdin);
freopen("live.out","w",stdout);
cin>>n>>w;
for (int i=1;i<=n;i++) cin>>a[i];
b[1]=a[1];
for (int i=2;i<=n;i++)
{
    mid=max*0.01*w-(max*0.01*w)%1;
    for (int j=max-1;j>=1;j--)
    {
        for (int e=1;e<=j;e++)
        {
            if (a[e]<a[e+1]) swap(a[e],a[e+1]);
        }
    }
    b[i]=a[mid];
    max++;
}
for(int i=1;i<=n;i++) cout<<b[i]<<" ";
return 0;
}