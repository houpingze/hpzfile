#include <iostream>
#include <cstdio>
using namespace std;
long long n,a[10001]={0},v=0,u=0;
int main()
{
freopen("power.in","r",stdin);
freopen("power.out","w",stdout);
long long j=1,s,mid=1;
cin>>n;
mid=n;
for (long long i=1;i<=10000;i++)
{
    s=1;
    for (int i=1;i<=mid;i++) {s=s*2;}
	mid++;
    if ((n-s)!<0) {a[j]=s;j++;n=n-s;,v++;}
    else {break;}
}
for (long long i=1;i<=v;i++)
{
    u+=a[i];
}
if (u==n) {cout<<u<<endl;}
else {cout<<-1<<endl;}
return 0;
}