#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
char s[1000010];
int n,m,p,s1,l,r,top,a[1000010],dp[1000010];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	while (cin>>s[s1])
	{
		if (s[s1]>='0' && s[s1]<='9' && s[s1-1]!='x')
		{
			n=(int)(s[s1]-48);
			break;
		}
		s1++;
	}
	for (int i=1;i<=n;i++)
		cin>>a[i];
	cin>>m;
	for (int i=1;i<=m;i++)
	{
		cin>>p;
		a[p]=1-a[p];
		top=0;
		memset(dp,0,sizeof(dp));
		for (int j=1;j<s1;j++)
		{
			if (s[j-1]=='x')
			{
				dp[++top]=a[(int)(s[j]-48)];
			}
			else
			{
				if (s[j]=='!')
					dp[top]=1-dp[top];
				else if (s[j]=='&')
				{
					l=dp[top];
					r=dp[top-1];
					top-=2;
					if (l==1 && r==1)
						dp[++top]=1;
					else
						dp[++top]=0;
				}	
				else if (s[j]=='|')
				{
					l=dp[top];
					r=dp[top-1];
					top-=2;
					if (l==1 || r==1)
						dp[++top]=1;
					else
						dp[++top]=0;
				}
			}
		}
		a[p]=1-a[p];
		cout<<dp[top]<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}