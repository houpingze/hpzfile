#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
int n,cnt,ans,a[110];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if (n%2==1)
		cout<<"-1";
	else
	{
		ans=1;
		while (n!=0)
		{
			a[++cnt]=(n%2)*ans;
			n=n/2;
			ans*=2;
		}
		for (int i=cnt;i>=1;i--)
		{
			if (a[i]!=0)
				cout<<a[i]<<" ";
		}
	}	
	fclose(stdin);
	fclose(stdout);
	return 0;
}