#include<iostream>
#include<cstdio>
using namespace std;
int a[27]={0,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864};
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,d=0,ts,ts2=0;
	cin>>n;
	int m=n;
	if(n%2==0)
	{
		for(int i=1;i<=27;i++)
		{
			d+=a[i];
			if(d>=n)
			{
				break;
			}
			ts2++;
		}
		if(d>n)
		{
		for(int i=1;i<=27;i++)
		{
			if(d-a[i]==n)
				ts=i;
		}
		for(int i=ts2+1;i>=1;i--)
		{	
			if(m<a[i])
			break;
			if(i!=ts&&m>=a[i])
			cout<<a[i]<<" "; 
			m-=a[i];
		}
	}
	if(d==n)
	{
		for(int i=ts2+1;i>=1;i--)
			cout<<a[i]<<" ";
	}
}
	if(n%2!=0)
		cout<<-1;
		
int r=m;
d=0;ts=0;ts2=0;
if(m>0&&m!=n)
for(int i=1;i<=27;i++)
		{
			d+=a[i];
			if(d>=m)
			{
				break;
			}
			ts2++;
		}
		if(d>m)
		{
		for(int i=1;i<=27;i++)
		{
			if(d-a[i]==m)
				ts=i;
		}
		for(int i=ts2+1;i>=1;i--)
		{	
			if(r<a[i])
			break;
			if(i!=ts&&r>=a[i])
			cout<<a[i]<<" "; 
			r-=a[i];
		}
	}
	if(d==m)
	{
		for(int i=ts2+1;i>=1;i--)
			cout<<a[i]<<" ";
	}
	
	
	int w=r;
d=0;ts=0;ts2=0;
	if(r>0&&r!=m)
for(int i=1;i<=27;i++)
		{
			d+=a[i];
			if(d>=r)
			{
				break;
			}
			ts2++;
		}
		if(d>r)
		{
		for(int i=1;i<=27;i++)
		{
			if(d-a[i]==r)
				ts=i;
		}
		for(int i=ts2+1;i>=1;i--)
		{	
			if(w<a[i])
			break;
			if(i!=ts&&w>=a[i])
			cout<<a[i]<<" "; 
			w-=a[i];
		}
	}
	if(d==r)
	{
		for(int i=ts2+1;i>=1;i--)
			cout<<a[i]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
}