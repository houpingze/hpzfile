#include<iostream>
#include<cstdio>
using namespace std;
int a[10000];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>a[i];
			for(int i=1;i<=n;i++)
		cout<<a[i]<<" ";
	fclose(stdin);
	fclose(stdout);
}