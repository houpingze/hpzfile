#include<bits/stdc++.h>
using namespace std;
int n,w,maxk,t;
priority_queue<int,vector<int>,greater<int> >q1;//小根堆 前k个
priority_queue<int>q2;//大根堆
int getint()
{
	char c=getchar();
	int s=0,sign=1;
	while(c!='-'&&!(c>='0'&&c<='9'))c=getchar();
	if(c=='-')sign=-1,c=getchar();
	while(c>='0'&&c<='9')s=s*10+c-'0',c=getchar();
	return s*sign;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	n=getint();
	w=getint();
	for(int i=1;i<=n;i++)
	{
		int k=max((i*w)/100,1);
		t=getint();
		if(i==1)
		{
			printf("%d ",t);
			q1.push(t);
			continue;
		}
		if(t>q1.top())
		{
			q2.push(q1.top());
			q1.pop();
			q1.push(t);
		}
		else q2.push(t);
		if(q1.size()<k)
		{
			q1.push(q2.top());
			q2.pop();
		}
		printf("%d ",q1.top());
	}
	return 0;
}