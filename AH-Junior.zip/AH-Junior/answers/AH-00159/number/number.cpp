#include<bits/stdc++.h>
using namespace std;
int n,m,a[1100][1100],rs[1100],rse[1100];
long long ans=LONG_LONG_MIN+10000;
bool vis[1100][1100];
int getint()
{
	char c=getchar();
	int s=0,sign=1;
	while(c!='-'&&!(c>='0'&&c<='9'))c=getchar();
	if(c=='-')sign=-1,c=getchar();
	while(c>='0'&&c<='9')s=s*10+c-'0',c=getchar();
	return s*sign;
}
void dfs(int x,int y,long long sum)
{
	sum+=a[x][y];
	if(x==n&&y==m)
	{
		ans=max(ans,sum);
		return ;
	}
	if(sum+rse[y]<ans)return;
	vis[x][y]=1;
	if(!vis[x-1][y])dfs(x-1,y,sum);
	if(!vis[x+1][y])dfs(x+1,y,sum);
	if(!vis[x][y+1])dfs(x,y+1,sum);	
	vis[x][y]=0;
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	n=getint();
	m=getint();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			a[i][j]=getint();
	for(int i=0;i<=n+1;i++)vis[i][0]=vis[i][m+1]=1;
	for(int j=0;j<=m+1;j++)vis[0][j]=vis[n+1][j]=1;
	for(int j=1;j<=m;j++)
		for(int i=1;i<=n;i++)
			rs[j]+=max(0,a[i][j]);
	for(int j=1;j<=m;j++)rs[j]+=rs[j-1];
	for(int j=1;j<=m;j++)rse[j]=rs[m]-rs[j-1];
	dfs(1,1,0);
	printf("%lld",ans);
	return 0;
}