#include<bits/stdc++.h>
using namespace std;
string s;
int t,n,q,sum;
bool x[100100];
int getint()
{
	char c=getchar();
	int s=0,sign=1;
	while(c!='-'&&!(c>='0'&&c<='9'))c=getchar();
	if(c=='-')sign=-1,c=getchar();
	while(c>='0'&&c<='9')s=s*10+c-'0',c=getchar();
	return s*sign;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='&'){t=1;break;}
		if(s[i]=='|'){t=2;break;};
	}
	n=getint();
	for(int i=1;i<=n;i++)x[i]=getint(),sum+=x[i];
		q=getint();
	if(t==1)
		for(int i=1;i<=q;i++)
		{
			int k=getint(),st=sum;
			if(x[k]==0)st++;
			else st--;
			if(st==n)printf("1\n");
			else printf("0\n");
		}
	if(t==2)
		for(int i=1;i<=q;i++)
		{
			int k=getint(),st=sum;
			if(x[k]==0)st++;
			else st--;
			if(st==0)printf("0\n");
			else printf("1\n");
		}
	return 0;
}