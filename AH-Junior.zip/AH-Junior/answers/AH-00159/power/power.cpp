
#include<bits/stdc++.h>
using namespace std;
int k,t=1;
int getint()
{
	char c=getchar();
	int s=0,sign=1;
	while(c!='-'&&!(c>='0'&&c<='9'))c=getchar();
	if(c=='-')sign=-1,c=getchar();
	while(c>='0'&&c<='9')s=s*10+c-'0',c=getchar();
	return s*sign;
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	k=getint();
	if(k&1)
	{
		printf("-1");
		return 0;
	}
	while(t<=k)t<<=1;
	t>>=1;
	while(k)
	{
		if(k>=t)
		{
			printf("%d ",t);
			k-=t;		
		}
		t>>=1;
	}
	return 0;
}