#include<iostream>
using namespace std;
int main()
{
	//freopen("number.in","r"stdin)
	//freopen("number.out","w"stdout)
	int n,m;
	cin>>n>>m;
	
	return 0;
}