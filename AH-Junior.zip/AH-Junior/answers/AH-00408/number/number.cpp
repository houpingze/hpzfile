#include<bits/stdc++.h>
using namespace std;

const int dx[]={INT_MAX,0,0,1,-1},dy[]={INT_MAX,1,-1,0,0};
const int N=1005;

int n,m;
int mp[N][N];
bool b[N][N];
int ans=INT_MIN;

void dfs(int x,int y,int sum){
	for(int i=1;i<=4;i++){
		int nx=dx[i]+x,ny=dy[i]+y;
		if(nx<1 || nx>n || ny<1 || ny>m || b[nx][ny])continue;
		if(nx==n && ny==m){
			ans=max(ans,sum+mp[n][m]);
		}
		else {
			b[nx][ny]=true;
			dfs(nx,ny,sum+mp[nx][ny]);
			b[nx][ny]=false;
		}
	}
}

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&mp[i][j]);
		}
	}
	dfs(1,1,mp[1][1]);
	printf("%d\n",ans);
	return 0;
}