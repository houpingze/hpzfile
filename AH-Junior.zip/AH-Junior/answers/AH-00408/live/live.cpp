#include<bits/stdc++.h>
using namespace std;

const int N=100005;
int a[N];
int n,m;

int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		int k=max(1,i*m/100);
		scanf("%d",&a[i]);
		sort(a+1,a+i+1,greater<int>());
		printf("%d ",a[k]);
	}
	return 0;
}
	