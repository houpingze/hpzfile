#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout); 
	string s;
	int n;
	getline(cin,s);
	scanf("%d",&n);
	while(n--){
		int x,y;
		scanf("%d%d",&x,&y);
		printf("0\n");
	}
	return 0;
}