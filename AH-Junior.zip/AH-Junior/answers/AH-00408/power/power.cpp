#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n%2 || n==0){
		printf("-1\n");
		return 0;
	}
	int m=0;
	int a[105]={0};
	while(n){
		a[++m]=n%2;n/=2;
	}
	int r=2;
	for(int i=2 ;i<=m;i++){
		a[i]=a[i]*r;
		r*=2;
	}
	for(int i=m;i>=2;i--){
		if(!a[i])continue;
		printf("%d ",a[i]);
	}
	return 0;
}	