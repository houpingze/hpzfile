#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("power.in", "r", stdin);
	freopen("power.out","w",stdout);
	int n, s = 1, a[1000001], ans = 0;
	cin>>n;
	if(n % 2 == 1) 
	{
		cout<<"-1";
		return 0;
	}
		while(n > 0)
23		{
			int x = 2;
			while(n >= x * 2)
			{
				x *= 2;
				a[s++] = x; 
				n -= x;
			}
	}
	for(int i = 1; i <= n; i++)
	{
	  cout<<a[i]<<" ";
	}
	return 0;
}
