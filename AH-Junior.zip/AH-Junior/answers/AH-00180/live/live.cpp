#include <bis/stdc++.h>
using namespace std;

int main()
{
	freopen("live.in", "r", stdin);
	freopen("live.out","w",stdout);
	int n, w, a[100001], c1, maxn, b[100001];
	cin>>n>>w;
	double w1 = w /100;
	for(int i = 1; i <= n; i++)
		cin>>a[i];
	sort(a,a+n);
	int len = strlen(a);
	for(int i = 1; i <= n; i++)
	{
		int x = int(i * w1);
		c1 = max(1, x);
		for(int  j = 1; j <= i; j++)
		{
			b[j] = a[a - c1]
		}
	}
}