#include<bits/stdc++.h>
using namespace std;
void  maxn()
{
	
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("eive.out","w",stdout);
	int w,n,a[1000],maxn;
	cin>>n>>w;
	for(int i=0;i<n;i++)
		cin>>a[i];
	for(int i=0;i<n;i++)
	{
	n=n*(w/100);
	}
	cout<<a[i];
	return 0;
}