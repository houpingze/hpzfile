#include<bits/stdc++.h>
using namespace std;
int a[100];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,i=2,num=0,max,maxx=0;
	cin>>n;
	max=n;
	if(n%2==1||n<6)
	{
		cout<<"-1";
		return 0;
	}
	else
	{
		while(n>1)
		{
			while(n>=i)
			{
				i*=2;
			}
			num++;     
			a[num]=i/2;
			n=n-i/2;   
			maxx+=i/2; 
			i=2;
		}
	}
	if(maxx!=max) cout<<"-1";
	else
	{
		for(int i=1;i<=num;i++)
		{
			cout<<a[i]<<' ';
		}
	}
	return 0;
}