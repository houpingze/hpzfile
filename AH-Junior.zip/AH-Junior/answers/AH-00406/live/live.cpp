#include<bits/stdc++.h>
using namespace std;
int x[100000];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w,max,min,p=0,t;
	float renshu;
	cin>>n>>w;
	for(int i=1;i<=n;i++)
	{
		cin>>x[i];
		p++;
		for(int j=1;j<=i;j++)
		{
			if(x[j]<x[j+1])
			{
				t=x[j];
				x[j]=x[j+1];
				x[j+1]=t;
			}
		}
		renshu=p*w*0.01;
		cout<<x[(int)renshu]<<' ';
	}
	return 0;
}