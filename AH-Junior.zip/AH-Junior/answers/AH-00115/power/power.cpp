#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	char a[100001];
	int n,L=1;
 cin>>n>>a;
 if(n%2==0){
 for(int i=1;i<=100000;i++){
L=L*2;
if(L<=n/2){
a[i]=L;
cout<<a[i]<<" ";
}
}
}
if(n%2!=0){
cout<<"-1";
return 0;
}
}