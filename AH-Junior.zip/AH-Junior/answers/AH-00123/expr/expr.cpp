#include<bits/stdc++.h>
using namespace std;
int n,m,a[100001];
string s;
int main()
{
	//freopen("expr.in","r",stdin);
	//freopen("expr.out","w",stdout);
	getline(cin,s)
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	cin>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>num;
		a[num]=-num;
	for(int i=1;i<=n;i++)
		if(s=="&")
		{
			
	return 0;
}