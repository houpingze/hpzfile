#include<bits/stdc++.h>
using namespace std;
int n,x=2,ans=1,num=0,f[30],a[30];
void dfs(int n,int step)
{
	if(n!=0)
	{
		f[step]=n%2;
		n/=2;
		ans++;
		dfs(n,++step);
	}
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2!=0) 
	{
		cout<<"-1";
		return 0;
	}
	while(x<=n)
	{
		if(x==n) 
		{
			cout<<x;
			return 0;
		}
		x*=2;
	}
	n/=2;
	dfs(n,1);
	a[1]=2;
	for(int i=2;i<=ans;i++)
		a[i]=a[i-1]*2;
	for(int i=ans;i>=1;i--)
		if(f[i]) cout<<a[i]<<' ';
	return 0;
}