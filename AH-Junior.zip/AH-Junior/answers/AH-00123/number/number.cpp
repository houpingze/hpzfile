#include<bits/stdc++.h>
using namespace std;
int n,m,maxn,a[1001][1001];
bool f[1001][1001];
int dx[3]={0,1,-1};
int dy[3]={1,0,0};
void dfs(int x,int y,int Num)
{
	if(x==n&&y==m)
	{
		maxn=max(Num,maxn);
		return;
	}
	for(int i=0;i<=2;i++)
	{
		int xx=x+dx[i],yy=y+dy[i];
		if(xx>=1&&yy>=1&&xx<=n&&yy<=m&&f[xx][yy]==0)
		{
			f[xx][yy]=1;
			dfs(xx,yy,Num+a[xx][yy]);
			f[xx][yy]=0;
		}
	}
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("numbert.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		  for(int j=1;j<=m;j++)
			  scanf("%d",&a[i][j]);
	f[1][1]=1;
	dfs(1,1,a[1][1]);
	cout<<maxn;
	return 0;
}