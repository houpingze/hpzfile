#include<bits/stdc++.h>
using namespace std;
int n,w,a[100001],p=1;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	while(p<=n)
	{
		int Num,x,z;
		z=w*p;
		if(z/100<1) Num=1;
			else Num=int(z/100);
		cin>>x;
		int m,f=0;
		for(int j=1;j<p;j++)
			if(x>=a[j])
			{f=1;m=j;break;}
		if(f==0) a[p]=x;
		if(f!=0)
		{
			for(int j=p-1;j>=m;j--)
			   a[j+1]=a[j];
			a[m]=x;
		}
		cout<<a[Num]<<' ';
		p++;
	}
	return 0;
}