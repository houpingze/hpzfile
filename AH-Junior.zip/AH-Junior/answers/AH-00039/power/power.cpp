#include<bits/stdc++.h>
using namespace std;
long long k[20];
long long ans[30];
void doit(){
	k[1]=2;
	for(int i=2;i<=20;i++) k[i]=2*k[i-1];
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	doit();
	bool b=true;
	long long n;
	int j=1;
	cin>>n;
	if(n%2==1)
		b=false;
	else
		for(int i=20;i>=1;i--){
			while(n>=k[i]){
				n-=k[i];
				ans[j]=k[i];
				j++;i--;
			}
		}
	for(int i=1;i<=j;i++)
		if(ans[i]==ans[i+1] && ans[i] && ans[i+1]) b=false;
	if(b) {
		for(int i=1;i<=j;i++)
			if(ans[i])
				cout<<ans[i]<<" ";
	}
	else 
		cout<<-1<<endl;
	return 0;
}