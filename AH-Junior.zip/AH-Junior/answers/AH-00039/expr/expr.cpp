#include<bits/stdc++.h>
using namespace std;
int d(int n) {
	return !n;
}
int p(int n,int m,char op){
	if(op=='&') return n&m;
	if(op=='|') return n|m;
	if(op=='!') return d(n);
}
int a[1000];
char op[1000];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int l=0,m=0;
	string s;
	getline(cin,s);
	for(int i=s.size()-1;i>=0;i--){
		if(s[i]=='0') a[l++]=0;
		else if(s[i]=='1') a[l++]=1;
		else op[m++]=s[i];
	}
	while(l--){
		if(l%2==0) cout<<0<<endl;
			else cout<<1<<endl;
			}
	return 0;
}