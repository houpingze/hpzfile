#include<bits/stdc++.h>
using namespace std;
int a[100005],d[100005];
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,j,k;
	double w,o;
	cin>>n>>w;
	w/=100;
	for(int i=1;i<=n;i++){
		cin>>a[i];d[i]=a[i];
	}
	for(int i=1;i<=n;i++){
		sort(d+1,d+i+1,cmp);
		o=i*w;j=o;k=max(1,j);
		cout<<d[k]<<" ";
	}
	cout<<endl;
	return 0;
}