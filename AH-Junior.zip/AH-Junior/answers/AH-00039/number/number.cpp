#include<bits/stdc++.h>
using namespace std;
int a[1005][1005],f[1005][1005];
int b[1005][1005]={1};
int n,m;
int dx[4]={0,1,-1,0},
	dy[4]={1,0,0,-1};
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int s,l,xb,yb,xe,ye;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	f[1][1]=a[1][1];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			for(int k=0;k<4;k++){
				xb=i+dx[k],yb=j+dy[k];
				if((xb>=1 and xb<=n) and (yb>=1 and yb<=m) and b[xb][yb])
					if(s<f[i][j]+a[xb][yb]){
						s=f[i][j]+a[xb][yb];
						l=k;
					}
			}
			xe=i+dx[l],ye=j+dy[l];
			b[xe][ye]=0;
			f[xe][ye]=s;
			s=INT_MIN;
		}
	cout<<f[n][m]<<endl;
	return 0;
}