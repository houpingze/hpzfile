#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);freopen("power.out","w",stdout);
	long long n;
	int a[11]={2,4,8,16,32,64,128,256,512,1024,0};
	cin>>n;int s=0,t;
	if(n%2!=0)
	{
		cout<<"-1";
	}
	else 
	{
		for(int i=0;i<=10;i++)
		{
			if(n==a[i])
			{
				cout<<n;
				return 0;
			}
		}
		int c=n/2;
		for(int i=1;i<c;i++)
		{
			int ji=2*(c-i);
			for(int j=0;j<10;j++)
			{
				if(ji==a[j])
				{
					s++;
					n-=j;
					if(s==1)
					{
						cout<<a[j];
					}
					else
					{
						cout<<" "<<a[j];
					}	
				}
			}
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}