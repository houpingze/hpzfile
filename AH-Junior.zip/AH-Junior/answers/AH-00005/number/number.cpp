#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;float a[1000][1000];
int main()
{
	freopen("number.in","r",stdin);freopen("number.out","w",stdout);
	cout<<"-1";
	fclose(stdin);fclose(stdout);
	return 0;
}
