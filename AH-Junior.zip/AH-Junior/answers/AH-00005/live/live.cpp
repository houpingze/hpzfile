#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;int a[100000],b[100000];
int main()
{
	freopen("live.in","r",stdin);freopen("live.out","w",stdout);
	int n,w;
	cin>>n>>w;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];b[i]=a[i];
	}
	for(int i=1;i<=n;i++)
	{
		int r=i*0.01*w;
		if(r<1)
		r=1;
		for(int j=0;j<n;j++)
		{
			a[j]=b[j];
		}
		if(i==1)
		{
			cout<<a[0];
			continue;
		}
		else
		{
			for(int q=0;q<i-1;q++)
			{
				for(int p=q+1;p<i;p++)
				{
					if(a[q]<a[p])
					swap(a[q],a[p]);
				}
			}
			cout<<" "<<a[r-1];
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}