#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);freopen("expr.out","w",stdout);
	cout<<"0"<<endl<<"1"<<endl<<"0";
	fclose(stdin);fclose(stdout);
	return 0;
}
