#include<iostream>
#include<stdio.h>
#include<cmath>
#include<string>
#include<algorithm>
#include<cctype>
long long n,line;
int w;
int a[10001];
using namespace std;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){

		cin>>a[i];
		line=max(1,int(i*w*0.01+0.05));
		unique(a+1,a+1+i);
		reverse(a+1,a+1+i);
		cout<<a[line]<<" ";
		}

	return 0;
}