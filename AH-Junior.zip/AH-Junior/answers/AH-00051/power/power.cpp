#include<iostream>
#include<stdio.h>
#include<cmath>
#include<string>
#include<algorithm>
#include<cctype>
long long n;

using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2==1){cout<<-1;return 0;}
	int r[10001],m,t=0,ans[10001],re[10001],tt=0;
	m=n;
    while(m!=0){
		t++;
		r[t]=m%2;
		m=m/2;
		}
		r[t]=1;
		m=t;
	for(int i=1;i<=t;i++)ans[i]=r[m--];
	for(int i=1;i<=t;i++)if(ans[i]==1){
		tt++;
		re[tt]=pow(2,i);
		}
		reverse(re+1,re+1+tt);
	for(int i=1;i<=tt;i++){cout<<re[i];if(i!=tt)cout<<" ";}

	return 0;
}