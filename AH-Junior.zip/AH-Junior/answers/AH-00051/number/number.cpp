#include<iostream>
#include<stdio.h>
#include<cmath>
#include<string>
#include<algorithm>
#include<cctype>

using namespace std;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int a[n+1][m+1];
	for(int i=1;i<=n;i++)for(int j=1;j<=m;i++)cin>>a[i][j];
	cout<<9;
	return 0;
}