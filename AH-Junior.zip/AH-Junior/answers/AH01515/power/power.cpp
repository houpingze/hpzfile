#include<iostream>
#include<cstdio>
#include<ctring>
using namespace std;
int main()
{
//freopen("power.cpp":"r":stdn);
//freopen("power.cpp":"w":stbout);
}
