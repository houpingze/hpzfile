#include<bits/stdc++.h>
using namespace std;
long long k,n,a;
string m;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.in","w",stdout);
	getline(cin,m);
	cin>>k;
	for(int i=1;i<=k;i++);
		cin>>a;
	cout<<k;
	scanf("%d",n);
	cout<<n;
	for(int i=1;i<=n;i++)
		cin>>a;
	for(int i=1;i<=n;i++)
		cout<<1;
	return 0;
}    