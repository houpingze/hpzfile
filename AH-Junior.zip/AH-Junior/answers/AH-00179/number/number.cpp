#include<bits/stdc++.h>
using namespace std;
int a[1001][1001],n,m,ans;
int ax[4]={1,-1,0};
int bx[4]={0,0,1};
int sh(int x,int y)
{
	int xa=1,ya=1;
	ans+=max(a[x+ax[1]][y+bx[1]],max(a[x+ax[2]][y+bx[2]],a[x+ax[3]][y+bx[3]]));
	cout<<ans <<endl;
	if(a[x+ax[1]][y+bx[1]]>a[x+ax[2]][y+bx[2]]>a[x+ax[3]][y+bx[3]]  ||  a[x+ax[1]][y+bx[1]]>a[x+ax[3]][y+bx[3]]>a[x+ax[2]][y+bx[2]]) xa=x+ax[1],ya=y+bx[1];
	else if(a[x+ax[2]][y+bx[2]]>a[x+ax[1]][y+bx[1]]>a[x+ax[3]][y+bx[3]]  ||  a[x+ax[2]][y+bx[2]]>a[x+ax[3]][y+bx[3]]>a[x+ax[1]][y+bx[1]]) xa=x+ax[2],ya=y+bx[2];
	else if(a[x+ax[3]][y+bx[3]]>a[x+ax[2]][y+bx[2]]>a[x+ax[1]][y+bx[1]]  ||  a[x+ax[3]][y+bx[3]]>a[x+ax[1]][y+bx[1]]>a[x+ax[2]][y+bx[2]]) xa=x+ax[3],ya=y+bx[3];
	if(xa==n && ya==m) return 0;
	a[x][y]=-10001;
	cout<<xa<<" "<<ya<<endl;
	sh(xa,ya);
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int x=1,y=1;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	cout<<sh(x,y);
	return 0;
}