#include<bits/stdc++.h>
using namespace std;
long long k,n,a[100001];
double m;
int cup(long long a,long long b)
{
	return a>b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
	{
		sort(a+1,a+i+1,cup);
		k=i*m;
		k/=100;
		if(k==0) k+=1;
		printf("%d ",a[k]);
	}
	return 0;
}