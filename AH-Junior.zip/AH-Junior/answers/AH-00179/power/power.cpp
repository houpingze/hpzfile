#include<bits/stdc++.h>
using namespace std;
long long n,a[500001],ans,c;
void d()
{
	long long t=1; 
	ans=0;
	while(n>=2)
	 {
		 ans++;
		 for(int i=1;i<=ans;i++) t*=2;
		 n-=t; 
		a[ans]=t;
		t=1;
	 }
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2!=0)
	{
		printf("-1");
		return 0;
	}
	d();
	for(int i=ans;i>=1;i--) printf("%d ",a[i]);
	return 0;
}