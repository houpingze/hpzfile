#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<map>
using namespace std;
int n,w,a[100005];
map<int,int>mp;
map<int,int>::iterator it,it2;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&w);
	scanf("%d",&a[1]);
	printf("%d ",a[1]);
	mp[a[1]]++;
	for(int i=2;i<=n;i++){
		scanf("%d",&a[i]);
		int k=max(1,i*w/100);
		mp[a[i]]++;
		it=mp.end();it--;it2=mp.begin();
		if(it==it2){
			cout<<it2->first<<" ";
			continue;
		}
		for(;it!=mp.begin();it--){
			bool flag=false;
			if(it->second<k){
				k-=it->second;
				flag=true;
			}
			else{
				cout<<it->first<<" ";
				k=0;
				break;
			}
			/*if(it==it2 && !flag){
				it2--;
				cout<<it2->first<<" ";
				break;
			}*/
		}
		if(k) cout<<it2->first<<" ";
	}
	return 0;
}