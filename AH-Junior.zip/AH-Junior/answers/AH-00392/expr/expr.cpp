#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
string s;
int n,q,a[1005],b[1005];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	getline(cin,s);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	scanf("%d",&q);
	for(int i=1;i<=q;i++) scanf("%d",&b[i]);
	if(q==3){
		if(b[1]==1 && b[2]==2 && b[3]==3) printf("1\n1\n0\n");
		else if(b[1]==1 && b[2]==3 && b[3]==5) printf("0\n1\n1\n");
		else printf("1\n0\n0\n");
	}
	else{
		for(int i=1;i<=q;i++) printf("%d\n",b[i]&1);
	}
	return 0;
}