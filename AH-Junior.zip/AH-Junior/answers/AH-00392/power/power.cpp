#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
#define ll long long
ll n,s[50],a[50],p;
bool v[50]={0},flag=false;
ll out(ll x){
    for(ll i=1;i<=x;i++) printf("%lld ",a[i]);
}
void dfs(ll k,ll t){
	if(k==0){
		flag=true;
		out(t-1);
		exit(0);
	}
	if(k<0) return;
	for(ll i=p;i>=1;i--){
		if(!v[i]){
			a[t]=s[i];
			v[i]=1;
			dfs(k-s[i],t+1);
			v[i]=0;
		}
	}
	return;
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%lld",&n);
	if(n%2){
		printf("-1\n");
		return 0;
	}
	s[0]=1;
	for(ll i=1;i<=32;i++) s[i]=s[i-1]*2;
	for(ll i=32;i>=1;i--){
		if(s[i]>n) continue;
		if(s[i]==n){printf("%lld\n",s[i]);return 0;}
		else {p=i;break;}
	}
	dfs(n,1);
	if(!flag) printf("-1\n");
	return 0;
}