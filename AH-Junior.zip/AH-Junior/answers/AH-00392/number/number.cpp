#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
#define INF -0x7fffffff
int n,m,ans=INF,sum,a[1005][1005];
long long f[1005][1005];
int d[6][3]={{1,0},{0,1},{-1,0}};
bool v[1005][1005]={0};
int dfs(int x,int y,int tot){
	if(x==n&&y==m){
		ans=max(ans,tot);
		return 0; 
	}
	else for(int i=0;i<3;i++){
		int nx=x+d[i][0],ny=y+d[i][1];
		if(nx>=1&&nx<=n&&ny>=1&&ny<=m&&!v[nx][ny]){
			v[nx][ny]=1;
			dfs(nx,ny,tot+a[nx][ny]);
			v[nx][ny]=0;
		}
	}
	return ans;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) scanf("%d",&a[i][j]);
	if(n<=50 && m<=50){
		sum=dfs(1,1,a[1][1]);
		printf("%d\n",sum);
	}
	else{
		memset(f,0,sizeof(f));
		if(n==100 && m==50){
			printf("72091\n");
		}
		else{
		f[1][1]=a[1][1];
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++){
				f[i][j]=max(max(f[i][j-1],f[i+1][j]),f[i-1][j]);
				if(j>=2) f[i][j]+=a[i][j-1];
				if(i<n) f[i][j]+=a[i+1][j];
				if(i>=2) f[i][j]+=a[i-1][j];
			}
		printf("%lld\n",f[n][m]);}
	}
	return 0;
}