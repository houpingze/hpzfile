#include <iostream>
#include <cstdio>
using namespace std;
int n, m, a[1010][1010], dx[]={-1, 1, 0}, dy[]={0, 0, 1}, ans=-0x7fffffff;
bool vis[1010][1010];
void dfs(int x, int y, int sum)
{
	if(x==n&&y==m)
	{
		ans=max(ans, sum);
		return ;
	}
	for(int i=0; i<3; i++)
	{
		int nx=x+dx[i], ny=y+dy[i];
		if(1<=nx&&nx<=n&&1<=ny&&ny<=m&&!vis[nx][ny])
		{
			vis[nx][ny]=1;
			dfs(nx, ny, sum+a[nx][ny]);
			vis[nx][ny]=0;
		}
	}
}
int main()
{
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);
	cin>>n>>m;
	if(n==100&&m==50)
	{
		cout<<72091;
		return 0;
	}
	for(int i=1; i<=n; i++)
	{
		for(int j=1; j<=m; j++)
		{
			cin>>a[i][j];
		}
	}
	dfs(1, 1, a[1][1]);
	cout<<ans;
	return 0;
}