#include <iostream>
#include <cstdio>
#include <string>
using namespace std;
string s;
int n, num[100010], q, stack[200010], top;
void ys()
{
	int len=s.size();
	for(int i=0; i<len; i++)
	{
		if(s[i]=='!')
		{
			stack[top]=!stack[top];
		}
		if(s[i]=='&')
		{
			top--;
			stack[top]=stack[top]&stack[top+1];
		}
		if(s[i]=='|')
		{
			top--;
			stack[top]=stack[top]|stack[top+1];
		}
		if(s[i]=='x')
		{
			stack[++top]=num[s[i+1]-'0'];
		}
	}
	cout<<stack[top]<<endl;
}

int main()
{
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	getline(cin, s);
	cin>>n;
	for(int i=1; i<=n; i++)
	{
		cin>>num[i];
	}
	cin>>q;
	while(q--)
	{
		int x;
		cin>>x;
		num[x]=!num[x];
		ys();
		num[x]=!num[x];
	}
	return 0;
}