#include <iostream>
#include <cstdio>
using namespace std;
int n, a[100], cnt, ans[100], anscnt;
bool havegood;
void dfs(int x, int last)//chai x, last: shang ci chai de bian hao xia yi wei
{
	if(havegood) return ;
	if(x==0)
	{
		havegood=1;
		for(int i=anscnt; i>=1; i--)
		{
			cout<<ans[i]<<" ";
		}
		return ;
	}
	for(int i=last; i<=cnt&&a[i]<=x; i++)
	{
		ans[++anscnt]=a[i];
		dfs(x-a[i], i+1);
		anscnt--;
	}
}
int main()
{
	freopen("power.in", "r", stdin);
	freopen("power.out", "w", stdout);
	cin>>n;
	if(n%2)
	{
		cout<<-1;
		return 0;
	}
	for(int i=2; i<=10000000; i*=2)
	{
		a[++cnt]=i;
	}
	dfs(n, 1);
	if(!havegood)
	{
		cout<<-1;
	}
	return 0;
}