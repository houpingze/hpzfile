#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cmath>
using namespace std;
int n, w, a[100010];
bool cmp(int x, int y)
{
	return x>y;
}
int main()
{
	freopen("live.in", "r", stdin);
	freopen("live.out", "w", stdout);
	cin>>n>>w;
	for(int i=1; i<=n; i++)
	{
		cin>>a[i];
		sort(a+1, a+i+1, cmp);
		int k;
		if(floor(i*w/100)>1) k=floor(i*w/100);
		else k=1;
//		for(int j=1;  j<=i; j++)
	//{
	//	cout<<a[j]<<" ";
	//	}cout<<endl;
		cout<<a[k]<<" ";
	}
	return 0;
}