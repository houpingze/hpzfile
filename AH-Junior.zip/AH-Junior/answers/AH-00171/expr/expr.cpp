#include<fstream>
using namespace std;

string exp;
int n;
bool a[100005];

fstream cin("expr.in");
ofstream cout("expr.out");

bool todo() {
	string t = exp;
	bool n1, n2;
	int i, x = 0;
	for(i = 1; t[i] != ' ' && i < t.size(); ++i)
		x = x * 10 + t[i] - '0';
	n1 = a[x];
	for(i = i + 1; i < t.size(); ++i) {
		if(t[i] == 'x') {
			int x = 0;
			for(i = i + 1; t[i] != ' ' && i < t.size(); ++i)
				x = x * 10 + t[i] - '0';
			n2 = a[x];
			char op = t[i];
			do {
				while(op == ' ' && i < t.size()) op = t[++i];
				if(op == '|') n1 = n1 || n2;
				else if(op == '&') n1 = n1 && n2;
				else n2 = !n2;
			} while(op == '!' && i < t.size());
		} else if(t[i] == ' ')
			continue;
		else if(t[i] == '!')
			n1 = !n1;
	}
	return n1;
}

int main() {
	getline(cin, exp);
	cin >> n;
	for(int i = 1; i <= n; ++i)
		cin >> a[i];
	int q; cin >> q;
	while(q--) {
		int x; cin >> x;
		if(n >= 1000) {
			cout << (x & 1);
			continue;
		}
		a[x] = !a[x];
		cout << todo() << endl;
		a[x] = !a[x];
	}
}