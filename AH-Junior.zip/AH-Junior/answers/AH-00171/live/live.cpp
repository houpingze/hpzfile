#include<fstream>
using namespace std;

int sc[605];
ifstream fin("live.in");
ofstream fout("live.out");

int b_search(int); //binary search

int main() {
	int n, w; fin >> n >> w;
	for(int i = 1; i <= n; ++i) {
		int x; fin >> x;
		for(int j = x; j >= 0; --j)
			++sc[j];
		int p = max(1, i * w / 100);
		fout << b_search(p) << ' ';
	}
}

int b_search(int p) { //binary search
	int l = 0, r = 600, m;
	while(l <= r) {
		m = ((l + r) >> 1) ;
		if(sc[m] >= p)
			l = m + 1;
		else
			r = m - 1;
	}
	return r;
}