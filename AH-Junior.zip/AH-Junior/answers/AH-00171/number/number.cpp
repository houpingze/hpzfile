#include<fstream>
using namespace std;

int n, m;
int g[1001][1001];
bool b[1001][1001];
int f[1001][1001];

int mx[] = {0, -1, 1, 0},
my[] = {1, 0, 0, -1};

ifstream cin("number.in");
ofstream cout("number.out");

void input();
void dfs(int, int, int);

int main() {
	input();
	dfs(0, 0, 0);
	cout << f[n -1][m - 1];
	return 0;
}

void dfs(int x, int y, int c) {
	if((c += g[x][y]) > f[x][y])
		f[x][y] = c;
	b[x][y] = 1;
	for(int i = 0; i < 4; ++i) {
		int nx = x + mx[i], ny = y + my[i];
		if(b[nx][ny] || nx >= n || ny >= m || nx < 0 || ny < 0) continue;
		dfs(nx, ny, c);
	}
	b[x][y] = 0;
	return;
}

void input() {
	cin >> n >> m;
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < m; ++j) {
			cin >> g[i][j];
			f[i][j] = -(1<<30);
		}
}