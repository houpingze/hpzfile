#include<bits/stdc++.h>
using namespace std;
double r;
int[100001]n;w;t;
int main( )
{
freopen("power.in","r",stdin);
freopen("power.out","w",stdiout);
cin>>n>>" ">>w;
for(int i=1;i>=n;i++)
{
cin>>a[i];
sort(a+1;a+1+n);
r=i"/100"w;
o=i"/100"w;
if(o>r)o=0-1;
cout<<n<<" "<<w<<endl;
return 0;
}
}