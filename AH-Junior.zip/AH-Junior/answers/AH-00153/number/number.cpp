#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("number","r",stdin);
	freopen("number.out","w",stdout);
	int i,n,m,j,a;
	cin>>n>>m;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			cin>>a;
	cout<<"1";
}