#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int i;
	char s[1001];
	gets(s);
	int n,b,q,aq;
	cin>>n;
	for(i=1;i<=n;i++)
		cin>>b;
	cin>>q;
	for(i=1;i<=q;i++)
		cin>>aq;
	for(i=1;i<=q;i++)
		cout<<'0'<<endl;
	}