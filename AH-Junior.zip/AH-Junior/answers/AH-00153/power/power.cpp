#include<bits/stdc++.h>
using namespace std;
long b[10000001],n;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int i,s=0,j,k,c,sum;
	cin>>n;
	if(n%2==1)
	{	
		cout<<"-1";
		return 0;
	}
	else
	{
		for(i=1;i<=10000000;i++)
		{
			s+=pow(2,i);
			b[i]=pow(2,i);
			if(n==b[i])
			{
				cout<<n;
				return 0;
			}
			if(n==s)
			{
				c=i;
				break;
			}
			if(s>n)
			{
				sum=n-(s-pow(2,i));
				for(k=1;k<=n;k++)
				{
					if(sum==b[k])
					{	
						b[n]=sum;
						break;
					}
					else
					{
						cout<<"-1";
						return 0;
					}
				}		
			}
		}
	}
	for(i=1;i<=n-1;i++)
			for(j=i+1;j<=n;j++)
				if(b[i]<b[j])
					swap(b[i],b[j]);
	for(i=1;i<=c;i++)
		cout<<b[i]<<' ';
	return 0;
}