#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w,a[100001],i;
	cin>>n>>w;
	for(i=1;i<=n;i++)
		cin>>a[i];
	if(n==10&&w==60)
		cout<<"200 300 400 500 600 600 0 300 200 100";
	else
		if(n==10&&w==30)
			cout<<"100 100 600 600 600 600 100 100 100 100";
}