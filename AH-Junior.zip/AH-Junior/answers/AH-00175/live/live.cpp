#include<iostream>
#include<cstdio>
using namespace std;
int a[100010];
int f[100010];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w;
	cin>>n>>w;
	int maxn;
	int a=0;
	int p;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		p=i;
		maxn=max(1,p*w/100);
		if(maxn==1&&p==1)
		{
			f[i]=a[i];
		}
		else if(maxn==a)
		{
			
		}
		a=maxn
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}