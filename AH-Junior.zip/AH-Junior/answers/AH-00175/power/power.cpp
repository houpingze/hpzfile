#include<iostream>
#include<cstdio>
using namespace std;
int a[10]={2,4,8,16,32,64,128,256,512,1024};
int n;
int ans;
int zuida(int n)
{
	int ans=0;
	int d=n;
	int b=0x3f3f3f3f;
	for(int i=0;i<10;i++)
	{
		if(d-a[i]<b&&d>a[i])
		{
			ans=a[i];
		}
	}
	return ans;
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	
	cin>>n;
	int sum=0;
	bool f=0;
	int pos=0;
	bool r=0;
	while(1)
	{
		if(n%2!=0)
		{
			cout<<-1;
			r=1;
			break;
		}
		else
		{
			for(int i=0;i<10;i++)
			{
				if(n==a[i])
				{
					cout<<a[i];
					return 0;
				}
				sum+=a[i];
				if(sum==n)
				{
					pos=i;
					f=1;
					break;
				}
			}
			break;
		}
	}
	if(f==1)
	{
		for(int i=pos;i>=0;i--)
		{
			cout<<a[i]<<" ";
		}
	}
	else if(r==0&&f==0)
	{
		cout<<zuida(n)<<" ";
		for(int i=0;i<10;i++)
		{
			if(n-zuida(n)==a[i])
			{
				cout<<n-zuida(n);
			}
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}