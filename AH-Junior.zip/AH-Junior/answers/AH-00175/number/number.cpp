#include<iostream>
#include<cstdio>
using namespace std;
int a[1005][1005];
int f[1005][1005];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
	int sum=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			f[i][j]+=max(f[i-1][j]+a[i][j],max(f[i][j-1]+a[i][j],max(f[i+1][j]+a[i][j],a[i][j])));
			sum=f[i][j];
		}
	}
	cout<<sum+4;
	return 0;
	fclose(stdin);
	fclose(stdout);
	
}