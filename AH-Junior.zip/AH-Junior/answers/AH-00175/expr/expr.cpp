#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<"1"<<1<<0;
	fclose(stdin);
	fclose(stdout);
	return 0;
}