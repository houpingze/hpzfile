#include<bits/stdc++.h>
using namespace std;
int n,a[51],tot=0,flag=0,ans=0,b[26]={0,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,0x3f3f3f3f},vis[11];
void print()
{
	flag=1;
	for(int i=tot;i>=1;i--)
		cout<<a[i]<<" ";
}
void search(int s)
{
	for(int i=1;i<=24;i++)
	{
		if(ans+b[i]<=n&&vis[i]==0)
		{
			ans+=b[i];
			a[++tot]=b[i];
			vis[i]=1;
			if(ans==n)
			{
				print();
			}
			search(s+1);
			ans-=b[i];
			tot--;
			vis[i]=0;
		}
		else
		{
			break;
		}
	}
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	search(2);
	if(!flag)
	{
		cout<<-1;
	}
}
