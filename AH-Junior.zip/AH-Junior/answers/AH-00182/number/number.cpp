#include<bits/stdc++.h>
using namespace std;
long long maxn=-0x7fffffff,n=0,m=0,a[1001][1001]={0},vis[1001][1001]={0},ans=0;
void dfs(int x,int y)
{
	ans+=a[x][y];
	vis[x][y]=1;
	if(x==n&&y==m)
	{
		maxn=max(maxn,ans);
	}
	if(x<n&&vis[x+1][y]==0)		dfs(x+1,y);
	if(x>1&&vis[x-1][y]==0)	    dfs(x-1,y);
	if(y<m&&vis[x][y+1]==0)	dfs(x,y+1);
	ans-=a[x][y];
	vis[x][y]=0;
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
	dfs(1,1);
	cout<<maxn;
}