#include<bits/stdc++.h>
using namespace std;
int n,w;
int a[100050],tot;
void charu(int x)
{
	a[++tot]=x;
	for(int j=tot-1;j>=1;j--)
	{
		if(a[j+1]>a[j])
		{	
			swap(a[j+1],a[j]);
		}
		else
			break;
	}
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++)	
	{
		int x;cin>>x;
		charu(x);
		int p=max(1,(i*w)/100);
		cout<<a[p]<<" ";
	}
}