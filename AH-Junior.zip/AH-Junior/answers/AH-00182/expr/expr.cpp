#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	int n,a,q;
	cin>>n;
	for(int i=1;i<=n;i++)	cin>>a;
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		cout<<a<<endl;
	}
}