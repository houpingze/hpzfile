#include<bits/stdc++.h>
using namespace std;
int b=1;
bool js(int n)
{
	bool hk=false;
	int k=1;
while(k!=n){
k*=2;
if(k==n){
	return true;}
}
return hk;
}
int main()
{
    freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	  int n,x;
	int  gj=0;
	  cin>>x;
	  if(x%2!=0){
	  cout<<"-1"<<endl;
	  return 0;}
	  for(int i=2;i<=10;i*=2){
	     n=x-i;
	     if(js(i))
	     if(js(n)){
	     cout<<n<<" "<<i<<endl;
			 gj=1;
	     return 0;}
		 }
		 if(gj==0){
			 cout<<"-1"<<endl;}
	     return 0;
}
