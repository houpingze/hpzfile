#include<bits/stdc++.h>
using namespace std;
int main()
{
     freopen("expr.in","r",stdin);
	  freopen("expr.out","w",stdout);
	  int n,x;
	  cin>>x;
	  cout<<"1"<<endl;
	   cout<<"1"<<endl;
	    cout<<"0"<<endl;
	     return 0;
}
