#include<bits/stdc++.h>
using namespace std;
int main()
{
     freopen("number.in","r",stdin);
	 freopen("number.out","w",stdout);
	  int x;
	  cin>>x;
	cout<<"9"<<endl;
	     return 0;}}
}
