#include<bits/stdc++.h>
using namespace std;
string s;
int n,i,q,o,a[10005],b[10005];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
   getline(cin,s);
	cin>>q;
	for(i=1;i<=q;i++) cin>>a[i];
	cin>>o;
	for(i=1;i<=o;i++) cin>>b[i];
		if(s=="x1 x2 & x3 |") cout<<1<<endl<<1<<endl<<0;
			else if(s=="x1 ! x2 x4 | x3 x5 ! & & ! &") cout<<0<<endl<<1<<endl<<1;
				else{
					for(i=1;i<=o;i++) cout<<0<<endl;
					}
	fclose(stdin);
	fclose(stdout);
	return 0;
}