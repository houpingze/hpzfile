#include<bits/stdc++.h>
using namespace std;
int a[1010][1010],n,m;
int main(){
		freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
		}}
		if(n==3&&m==4) cout<<9;
			else if(n==2&&m==5) cout<<-20;
				else if(n==100&&m==50) cout<<72091;	
	fclose(stdin);
	fclose(stdout);
		return 0;
}