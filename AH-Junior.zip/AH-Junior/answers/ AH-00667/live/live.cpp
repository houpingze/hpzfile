#include<bits/stdc++.h>
using namespace std;
int a[100010];
bool cmp(int x,int y){
	return x>y;
	}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w;
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		}
		for(int i=1;i<=n;i++){
				int h=max(1,(int)(i*w*0.01));
			sort(a+1,a+i+1,cmp);
			cout<<a[h]<<" ";
			}
	fclose(stdin);
	fclose(stdout);
	return 0;
}