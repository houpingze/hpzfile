#include<bits/stdc++.h>
using namespace std;
long long a[10000001],b[10000001],m;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	a[0]=1;
	for(int i=1;i<=25;i++){
		a[i]=a[i-1]*2;
		}
		while(n>1){
			for(int i=25;i>=1;i--)
			if(a[i]<=n){
				n-=a[i];
				b[++m]=a[i];
				break;
				}
			}
	if(n==1)  cout<<-1;
		else{
			for(int i=1;i<m;i++) cout<<b[i]<<" ";
				cout<<b[m];
		}
		fclose(stdin);
		fclose(stdout);
	return 0;
}