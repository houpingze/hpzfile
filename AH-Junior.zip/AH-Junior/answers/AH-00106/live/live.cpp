#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w;
	scanf("%d %d",&n,&w);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int b[n];
	int m=1;
	for(int i=0;i<n;i++)
	{
		int x=m*w;
		if(x==0) x+=1;
		b[i]=a[i];
		sort(b,b+i+1);
		cout<<b[x];
		m++;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}