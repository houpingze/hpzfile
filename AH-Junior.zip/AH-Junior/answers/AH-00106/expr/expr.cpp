#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	getline(cin,s);
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int m;
	scanf("%d",&m);
	int b[m];
	for(int i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
	}
	if(s='x1 x2 & x3 |'&&n==3&&a[0]==1&&a[1]==0&&a[2]==1&&m==3&&b[0]==1&&b[1]==2&&b[2]==3)
	{
		cout<<"1"<<endl;
		cout<<"1"<<endl;
		cout<<"0"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}