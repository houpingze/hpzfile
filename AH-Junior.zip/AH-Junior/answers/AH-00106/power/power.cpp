#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n%2!=0||n<=0)
	{
		cout<<"-1";
		return 0;
	}
	int x=n;
	int a=1;
	if(a==1)
	{
		x-=2;
		while(a==1)
		{
			x/=2;
			if(x!=0) a=2;
		}
	}
	cout<<n-2<<" "<<"2";
	fclose(stdin);
	fclose(stdout);
	return 0;
}