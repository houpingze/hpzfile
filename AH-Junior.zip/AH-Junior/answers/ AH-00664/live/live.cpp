#include<bits/stdc++.h>
using namespace std;
int n,a[100001],w,b[100001];
bool cmp(int a,int b){
	return a>b;
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		int t=max(1,int(i*(w/100.0)));
		b[i]=a[i];
		sort(b+1,b+1+i,cmp);
		cout<<b[t]<<' ';
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}