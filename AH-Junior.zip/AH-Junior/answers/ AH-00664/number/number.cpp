#include<bits/stdc++.h>
using namespace std;
int n,m,a[1001][1001],d[4][2]={{1,0},{0,1},{-1,0},{0,-1}},ans=-0x3f3f3f3f;
bool u[1001][1001];
void dfs(int x,int y,int c){
	if(x==n&&y==m){
		ans=max(ans,c);
		return;
	}
	for(int i=0;i<4;i++){
		int nx=x+d[i][0],ny=y+d[i][1];
		if(nx<=n&&nx>0&&ny<=m&&ny>0&&!u[nx][ny]){
			u[nx][ny]=true;
			dfs(nx,ny,c+a[nx][ny]);
			u[nx][ny]=false;
		}
	}
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)cin>>a[i][j];
	u[1][1]=true;
	dfs(1,1,a[1][1]);
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}