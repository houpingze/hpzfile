#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	string s;
	int n=1000;
	getline(cin,s);
	if(s=="x1 x2 & x3 |")cout<<"1\n1\n0";
	else if(s=="x1 ! x2 x4 | x3 x5 ! & & ! &")cout<<"0\n1\n1";
	else while(n--)cout<<"0\n";
	fclose(stdin);
	fclose(stdout);
	return 0;
}