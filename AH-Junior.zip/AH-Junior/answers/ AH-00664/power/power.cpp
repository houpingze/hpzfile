#include<bits/stdc++.h>
using namespace std;
int  t[100];
bool flag;
void f(int n,int x,int h){
	if(flag)return;
	if(n==0){
		for(int i=h-1;i>=1;i--)cout<<pow(2,t[i])<<' ';
		flag=true;
		return;
	}
	for(int i=x+1;i<=30;i++){
		int c=pow(2,i);
		if(n>=c){
			t[h]=i;
			f(n-c,i,h+1);
		}
	}
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	f(n,0,1);
	if(!flag)cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}