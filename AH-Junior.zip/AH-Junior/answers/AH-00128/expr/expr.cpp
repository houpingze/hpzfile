#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <stack>
using namespace std;

// 想到正解是建一棵树，从下往上搜，但是时间不够，调不出来

int read() {
	int d = 0, f = 1; char c = getchar(); while(!isdigit(c)) {if(c == '-') f = -1; c = getchar();}
	while(isdigit(c)) {d = d * 10 + c - '0'; c = getchar();}
	return d * f;
}

string s;

stack<int> st;

int a[100005], b[100005], n, q;

void work() {
	int len = s.size();
	int t = 0; // t用来存储下标
	for(int i = 0; i < len; i++) {
		if(s[i] == 'x') {
			t = 0;
			int j;
			for(j = i + 1; isdigit(s[j]); j++) {
				t = t * 10 + s[j] - '0';
			}
			//printf("read x%d\n", t);
			st.push(b[t]);
			i = j;
		} else {
			if(s[i] == '&') {
				int u = st.top();
				st.pop();
				int v = st.top();
				st.pop();
				//printf("%d & %d\n", u, v);
				st.push(u && v);
			} else if(s[i] == '|') {
				int u = st.top();
				st.pop();
				int v = st.top();
				st.pop();
				//printf("%d | %d\n", u, v);
				st.push(u || v);
			} else if(s[i] == '!') {
				//printf("!!!\n");
				st.top() = !st.top();
			}
		}
	}
	printf("%d\n", st.top());
}

int main() {
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	getline(cin, s);
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	
	cin >> q;
	while(q--) {
		while(!st.empty()) st.pop();
		for(int i = 1; i <= n; i++) b[i] = a[i];
		
		int t = read();
		b[t] = !b[t];
		work();
		b[t] = !b[t];
	}
	return 0;
}