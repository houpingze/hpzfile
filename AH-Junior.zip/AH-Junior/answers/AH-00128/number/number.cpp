#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cctype>
#include <cstring>
using namespace std;

int read() {
	int d = 0, f = 1; char c = getchar(); while(!isdigit(c)) {if(c == '-') f = -1; c = getchar();}
	while(isdigit(c)) {d = d * 10 + c - '0'; c = getchar();}
	return d * f;
}

const int dir[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

int n, m, a[1005][1005], vis[1005][1005], f[1005][1005];

long long ans = -0x3f3f3f3f3f3f3f3f;

bool isValid(int x, int y) {
	return 1 <= x && x <= n && 1 <= y && y <= m;
}

void dfs(int x, int y, long long sum) {
	if(x == n && y == m) {
		ans = max(ans, sum + a[n][m]);
		return;
	}
	for(int i = 0; i < 4; i++) {
		int nx = x + dir[i][0], ny = y + dir[i][1];
		if(isValid(nx, ny) && !vis[nx][ny]) {
			vis[nx][ny] = 1;
			dfs(nx, ny, sum + a[x][y]);
			vis[nx][ny] = 0;
		}
	}
}

int main() {
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);
	n = read(), m = read();
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= m; j++) {
			a[i][j] = read();
		}
	}
	vis[1][1] = 1;
	dfs(1, 1, 0ll);
	printf("%lld\n", ans);
	return 0;
}