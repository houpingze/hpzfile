#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <queue>
using namespace std;

int read() {
	int d = 0, f = 1; char c = getchar(); while(!isdigit(c)) {if(c == '-') f = -1; c = getchar();}
	while(isdigit(c)) {d = d * 10 + c - '0'; c = getchar();}
	return d * f;
}

int n, w, a[100005], num;

priority_queue<int, vector<int>, greater<int> > win;
priority_queue<int> lose;

int main() {
	freopen("live.in", "r", stdin);
	freopen("live.out", "w", stdout);
	cin >> n >> w;
	//printf("%d\n", n);
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
		//printf("%d %d\n", i, a[i]);
	}
	//printf("done");
	win.push(a[1]);
	num = 1;
	//printf("num=%d ", num);
	printf("%d ", win.top());
	for(int i = 2; i <= n; i++) {
		num = max(1, i * w / 100);
		//printf("num=%d ", num);
		lose.push(a[i]);
		while(win.top() < lose.top() && !win.empty() && !lose.empty()) {
			int s = win.top(), t = lose.top();
			win.pop(), lose.pop();
			win.push(t), lose.push(s);
		}
		while(win.size() != num && !lose.empty()) {
			win.push(lose.top());
			lose.pop();
		}
		printf("%d ", win.top());
	}
	return 0;
}