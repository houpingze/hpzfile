#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <queue>
using namespace std;

int read() {
	int d = 0, f = 1; char c = getchar(); while(!isdigit(c)) {if(c == '-') f = -1; c = getchar();}
	while(isdigit(c)) {d = d * 10 + c - '0'; c = getchar();}
	return d * f;
}

int n, t;

queue<int> q;

int main() {
	freopen("power.in", "r", stdin);
	freopen("power.out", "w", stdout);
	n = read();
	t = 1 << (int(log2(n) + 1));
	while(t != 1) {
		if(n >= t) {
			q.push(t);
			n -= t;
		}
		t >>= 1;
	}
	if(n != 0) {
		printf("-1\n");
	} else {
		while(!q.empty()) {
			printf("%d ", q.front());
			q.pop();
		}
	}
	return 0;
}