#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

int n,m;
int a[2000][2000],b[2000][2000];
long long ans;

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
		cin>>a[i][j];
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(i==1&&j==1){
				ans+=max(a[i+1][j],a[i][j+1]);
			}
			else{
				if(i==1&&j==m) ans+=max(a[i+1][j],a[i][j]);
				else
				if(i==n&&j==1) ans+=max(a[i-1][j],a[i][j+1]);
				else
				ans+=max(a[i-1][j],max(a[i+1][j],a[i][j+1]));
			}
			if(i==n&&j==m){
				cout<<ans<<endl;
				return 0;
			}
		}
	}
	return 0;
}