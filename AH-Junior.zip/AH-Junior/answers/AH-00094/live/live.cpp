#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w;
	int a[200000],b[200000];
	int p;
	int k;
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)
			b[j]=a[j];
		k=floor(i*w*0.01);
		p=max(1,k);
		sort(b+1,b+i+1);
		cout<<b[i-p+1]<<" ";
	}
	return 0;
}