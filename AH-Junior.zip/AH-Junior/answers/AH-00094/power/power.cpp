#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

long long ans[1000000],ans2[1000000];

bool power(long long a){
	long long i=0;
	while(a%2==0){
		a/=2;
		i++;
	}
	if(a==1) return true;
	else return false;
}

int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long n;
	long long i=1,k;
	long long p=1,b,j=1;
	long long m;
	cin>>n;
	m=n;
	while(1){
		if(pow(2,p)<n&&n<pow(2,p+1))
		  break;
		p++;
	}
	if((n%2)!=0) cout<<-1<<endl;
	else{
		if(power(n)) cout<<n<<endl;
		else{
			while(n>0){
				k=pow(2,i);
				if(power(n)){ 
					ans[i]=n;
					break;
				}
				if((n-k)>=0){
					n-=pow(2,i);
					ans[i]=pow(2,i);
					i++;
				}
				else{
					long long a=pow(2,p);
					while(n>0){
						m-=a;
						b=pow(2,j);
						if(power(m)){ 
							ans2[j]=m;
							break;
						}
						if((m-b)>=0){
							m-=pow(2,j);
							ans2[j]=pow(2,j);
							j++;
						}
						else{
							cout<<-1<<endl;
							return 0;
						}
					}
					cout<<a<<" ";
					for(long long c=j;c>=1;c--)
					  if(ans2[c]!=0)
						cout<<ans2[c]<<" ";
					return 0;
				}
			}
			for(long long c=i;c>=1;c--)
			 if(ans[c]!=0)
			  cout<<ans[c]<<" ";
		}
	}
	return 0;
}