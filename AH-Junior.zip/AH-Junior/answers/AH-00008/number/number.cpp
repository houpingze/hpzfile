#include<bits/stdc++.h>
#define ll long long
#define MAXN 1000+15

using namespace std;
ll a[MAXN][MAXN],dp[MAXN][MAXN];
bool vist[MAXN][MAXN];

inline ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0' or ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0' and ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x*f;
}

int main(){
	
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	
	ll n,m;
	
	n=read();m=read();
	
	for(ll i=1;i<=n;i++)
		for(ll j=1;j<=m;j++) a[i][j]=read();
			
	for(ll i=1;i<=n;i++)
		for(ll j=1;j<=m;j++) dp[i][j]=-999999;
	
	dp[1][1]=a[1][1],vist[1][1]=true;
	
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=m;j++){
			if(vist[i-1][j])
				dp[i][j]=max(dp[i][j],dp[i-1][j]+a[i][j]);
			if(vist[i][j-1]) 
				dp[i][j]=max(dp[i][j],dp[i][j-1]+a[i][j]);
			if(vist[i+1][j])
				dp[i][j]=max(dp[i][j],dp[i+1][j]+a[i][j]);
			if(vist[i][j+1])
				dp[i][j]=max(dp[i][j],dp[i][j+1]+a[i][j]);
			vist[i][j]=true;
		}
	}
	
	printf("%lld",dp[n][m]);
	
	return 0;
}