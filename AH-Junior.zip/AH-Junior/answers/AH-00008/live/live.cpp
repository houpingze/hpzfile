#include<bits/stdc++.h>
#define ll long long
#define MAXN 100000+15

using namespace std;
ll a[MAXN],ans[MAXN];
priority_queue<ll> pq;
priority_queue<ll , vector<ll> , greater<ll> > qp;

inline ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0' or ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0' and ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x*f;
}

bool cmp(ll a,ll b){
	return a>b;
}

int main(){
	
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	
	ll n,m,s,mid;
	
	n=read();m=read();
	
	for(ll i=1;i<=n;i++){
		s=(i*m)/100;
		a[i]=read();
		if(s<1) s=1;
		sort(a+1,a+i+1,cmp);
		printf("%lld ",a[s]);
	}
    
	return 0;
}