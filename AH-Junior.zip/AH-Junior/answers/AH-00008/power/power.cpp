#include<bits/stdc++.h>
#define ll long long

using namespace std;
ll a;

inline ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0' or ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0' and ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x*f;
}

int main(){
	
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	
	a=read();
	if(a%2==1){
		printf("-1\n");
		return 0;
	}
	ll b=1;
	while((b<<1)<=a) b=b<<1;
	
	while(b>=1 and a>0){
		a-=b;
		printf("%lld ",b);
		while(b>a) b=b>>1;
	}
	
	return 0;
}