#include<bits/stdc++.h>
#define ll long long

using namespace std;

inline ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0' or ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0' and ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x*f;
}

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ll a,b;
	string ch;
	getline(cin,ch);
	a=read();
	for(ll i=1;i<=a;i++){
		ll t;
		t=read();
	}
	b=read();
	for(ll i=1;i<=b;i++){
		ll t;
		t=read();
	}
	for(ll i=1;i<=b;i++)
		cout<<"1"<<endl;
}