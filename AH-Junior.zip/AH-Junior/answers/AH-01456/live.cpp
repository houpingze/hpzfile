#include<bits/stdc++.h>
using namespace std;
long long a[100200],n,w,x,i;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
		sort(a+1,a+i+1);
		x=i*w/100;
		if(i>100/w)cout<<a[i+1-x]<<" ";
		else cout<<a[i]<<" ";
	}
	return 0;
}