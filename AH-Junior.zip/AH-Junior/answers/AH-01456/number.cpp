#include<bits/stdc++.h>
using namespace std;
long long a[1001][1001],n,m,i,j,b;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(i=1;i<=n;i++)a[i][0]=a[i][m+1]-1000000000000;
	for(i=1;i<=m;i++)a[0][i]=a[n+1][i]=-1000000000000;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			cin>>a[i][j];
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		{
			a[i][j]+=max(a[i][j-1],max(a[i+1][j],a[i-1][j]));
		}
	}
	cout<<a[n][m];
	return 0;
}