#include<bits/stdc++.h>
using namespace std;
char a[100100];
int n,x[100100],i,j,q,m,c[100100],y,t;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	gets(a);
	cin>>q;
	for(i=1;i<=q;i++)cin>>x[i];
	n=strlen(a);
	cin>>m;
	for(i=1;i<=m;i++)
	{
		t=0;
		cin>>y;
		if(x[y]==0)x[y]=1;
		else x[y]=0;
		for(j=1;j<=q;j++)cout<<x[i]<<endl;
		for(j=0;j<n;j++)
		{
			if(a[i]=='x'){t++;c[t]=x[t];}
			if(a[i]=='&')
			{
				if(c[t]==1&&c[t-1]==1) c[--t]=1;
				else c[--t]=0;
			}
			if(a[i]=='I')
			{
				if(c[t]==1||c[t-1]==1) c[--t]=1;
				else c[--t]=0;
			}
			if(a[i]=='!')
			{
				if(c[t]==1) c[t]==0;
				else c[t]==1;
			}
		}
		cout<<c[1]<<endl;
		if(x[y]==0)x[y]=1;
		else x[y]=0;
	}
	return 0;
}