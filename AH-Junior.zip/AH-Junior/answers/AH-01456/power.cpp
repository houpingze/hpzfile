#include<bits/stdc++.h>
using namespace std;
long long n,i,j,x=1;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2==1){cout<<-1;return 0;}
	else
	{
		for(i=1;i<=log(n);i++)
			x*=2;
		if(n==x)
		{
			cout<<-1;
			return 0;
		}
	}
	if(n<=10)if(n==6)cout<<4<<" "<<2;else cout<<8<<" "<<2;
	else cout<<-1;
}