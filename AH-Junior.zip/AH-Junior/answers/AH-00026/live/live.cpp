#include<stdio.h>
using namespace std;
int n,w,a[100010],x;
int main(){
	freopen("live.in","r",stdin);freopen("live.out","w",stdout);
	scanf("%d %d",&n,&w);
	scanf("%d",&a[1]);printf("%d ",a[1]);
	for(int i=2;i<=n;i++){
		scanf("%d",&x);
		for(int j=1;j<i;j++)
			if(a[j]<x){
				for(int k=n;k>=j;k--)a[k+1]=a[k];
				a[j]=x;break;
			}
		if(i*w/100>1)printf("%d ",a[i*w/100]);
		else printf("%d ",a[1]);
	}
	return 0;
}
	