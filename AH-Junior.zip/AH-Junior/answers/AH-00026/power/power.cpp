#include<stdio.h>
using namespace std;
int n,a[20000];
int main(){
	freopen("power.in","r",stdin);freopen("power.out","w",stdout);
	scanf("%d",&n);
	int x=2;
	while(x<n)x*=2;
	if(x==n){
		printf("%d",x);
		return 0;
	}
	x/=2;int i;
	for(i=1;n>x;i++){
		a[i]=x;n-=x;x/=2;
	}
	if(x!=n||x==1){
		printf("-1");
		return 0;
	}
	else{
		a[i++]=x;
		for(int j=1;j<i;j++)printf("%d ",a[j]);
		return 0;
	}
	return 0;
}