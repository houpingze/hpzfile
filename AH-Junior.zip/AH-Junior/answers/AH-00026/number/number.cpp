#include<stdio.h>
using namespace std;
long long n,m,a[1010][1010],s;
int main(){
	freopen("number.in","r",stdin);freopen("number.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
			s+=a[i][j];
		}
	}
	printf("%lld",s);
	return 0;
}