#include<stdio.h>
#include<string.h>
using namespace std;
char a[1000010],c;
int n,num[100010],q,p[100010],qf,o,len;
int main(){
	freopen("expr.in","r",stdin);freopen("expr.out","w",stdout);
	while(1){c=getchar();if(c=='\n')break;else a[len++]=c;}
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&num[i]);
	scanf("%d",&q);
	while(q--){
		o=0;
		scanf("%d",&qf);
		num[qf]=!num[qf];
		for(int i=0;i<len;i++){
			if(a[i]=='x'){
				int m=0,nnnn=i+1;
				while(a[nnnn]>='0'&&a[nnnn]<='9')m=m*10+(a[nnnn++]-'0');
				p[o++]=num[m];
			}
			if(a[i]=='!'||a[i]=='&'||a[i]=='|'){
				if(a[i]=='!')p[o-1]=!p[o-1];
				if(a[i]=='&')o--,p[o-1]=(p[o]&&p[o-1]);
				if(a[i]=='|')o--,p[o-1]=(p[o]||p[o-1]);
			}
		}
		printf("%d\n",p[0]);
		num[qf]=!num[qf];
	}
	return 0;
}