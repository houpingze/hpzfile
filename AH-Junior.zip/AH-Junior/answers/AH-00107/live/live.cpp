#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
bool first=0;
bool cmp(const int &x,const int &y){
	return x>y;
}
int a[100000+10];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n;
	cin>>n;
	int w;
	cin>>w;
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(!first){
			sort(a,a+n,cmp);
			cout<<a[0]<<" ";
			first=1;
			continue;
		}
		int t=1+i;
		int se=t*w/100;
		if(se>0)
			se-=1;
		sort(a,a+n,cmp);
		cout<<a[se]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}