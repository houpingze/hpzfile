#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a[1000+10][1000+10];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=0;i<n;i++){
		for(int q=0;q<m;q++){
			cin>>a[i][q];
		}
	}
	int x=0,y=0,cnt=0;
	while(x!=n-1&&y!=m-1){
		int a1,a2,a3;//shang,you,xia
		if(x==0&&y==m){
			x++;
			continue;
		}
		else if(x==0){
			a1=-10010;
			a2=a[x][y+1];
			a3=a[x+1][y];
		}
		if(x==n&&y==0){
			a3=-10010;
			a2=a[x][y+1];
			a1=a[x-1][y];
		}
		if(y==m){
			a2=-10010;
			a1=a[x-1][y];
			a3=a[x+1][y];
		}
		if(a1>=a3&&a1>=a2){
			cnt+=a1;
			x--;
		}
		else if(a3>=a1&&a3>=a2){
			cnt+=a3;
			x++;
		}
		else if(a2>=a3&&a2>=a1){
			cnt+=a2;
			y++;
		}
		a[x][y]=-100000;
	}
	cout<<cnt;
	fclose(stdin);
	fclose(stdout);
	return 0;
}