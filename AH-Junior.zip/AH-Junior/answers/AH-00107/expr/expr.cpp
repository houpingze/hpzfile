#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;
	cin>>a;
	int n;
	cin>>n;
	int h[100000+10];
	for(int i=0;i<n;i++){
		cin>>h[i];
	}
	int q;
	cin>>q;
	for(int i=0;i<q;i++){
		int s;
		cin>>s;
	}
	for(int i=0;i<q;i++){
		cout<<1<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}