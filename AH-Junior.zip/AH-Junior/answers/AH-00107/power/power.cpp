#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[100];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	int h=0;
	int w=1;
	while(w<n){
		w*=2;
	}
	w/=2;
	int xy=-1;
	while(n>0&&w>1){
		if(w>n){
			w/=2;
			continue;
		}
		n-=w;
		xy++;
		a[xy]=w;
		w/=2;
	}
	if(n!=0){
		cout<<"-1";
	}
	else if(h==n){
		sort(a,a+xy+1);
		for(int i=xy;i>=0;i--){
			cout<<a[i]<<" ";
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}