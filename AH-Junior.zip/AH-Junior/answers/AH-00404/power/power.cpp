#include <iostream>
#include <cstdio>
using namespace std;
long long n,vis[1005],cnt;
long long ans;
bool ok=0;

int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	for(long long i=2;i<=n;i*=2)
	{
		vis[++cnt]=i;
		ans+=i;
		if(ans==n)
		{
			ok=1;
			break;
		}
	}
	if(ok)
		for(int i=cnt;i>=1;i--)
			cout<<vis[i]<<" ";
	else cout<<"-1";
	cout<<endl;
	return 0;
}