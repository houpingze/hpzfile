#include <iostream>
#include <cstdio>
using namespace std;
string s;
int n,q,vis[100005];

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s>>n;
	for(int i=1;i<=n;i++)
		cin>>vis[i];
	cin>>q;
	for(int i=1;i<=q;i++)
		cout<<1<<endl;
	return 0;
}