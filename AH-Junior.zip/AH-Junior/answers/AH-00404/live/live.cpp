#include <iostream>
#include <cstdio>
using namespace std;
int n,m,vis[100005];

void sp(int x,int y)
{
	int z=vis[x];
	vis[x]=vis[y];
	vis[y]=z;
}

int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>vis[i];
		if(i*m/100==0)
		{
			cout<<vis[i]<<" ";
			continue;
		}
		for(int j=i;j>1;j--)
			if(vis[j]>vis[j-1])
				sp(j,j-1);
		cout<<vis[i*m/100]<<" ";
	}
	cout<<endl;
	return 0;
}