#include <algorithm>
#include <iostream>
#include <cstdio>
using namespace std;
int n,m,mp[1005][1005],ans=-2147483647;
int vis[1000005][4];
int dx[3]={-1,0,1},
	dy[3]={0,1,0};

void bfs()
{
	int r=1,l=0;
	vis[r][0]=1;
	vis[r][1]=1;
	vis[r][2]=-1;
	vis[r][3]=mp[1][1];
	while(l!=r)
	{
		l++;
		if(l==1000001) l=1;
		for(int i=0;i<3;i++)
		{
			int lx=vis[l][0]+dx[i],ly=vis[l][1]+dy[i];
			if(lx<1 || lx>n || ly<1 || ly>m || (vis[l][2]==2-i && i!=1)) continue;
			r++;
			if(r==1000001) r=1;
			vis[r][0]=lx;
			vis[r][1]=ly;
			vis[r][2]=i;
			vis[r][3]=vis[l][3]+mp[lx][ly];
			if(lx==n&& ly==m)
				ans=max(ans,vis[r][3]);
		}
	}
}

int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>mp[i][j];
	bfs();
	cout<<ans<<endl;
	return 0;
}