 #include<iostream>
 #include<cstdio>
 #include<bits/stdc++.h>
 using namespace std;
 int main()
 {
 	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);\
	int a,b,s,q,n;
	cout<<q;
	fclose(stdin);
 	fclose(stdout);
	return 0;
}