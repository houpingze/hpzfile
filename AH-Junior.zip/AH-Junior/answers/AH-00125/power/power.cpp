 #include<iostream>
 #include<cstdio>
 #include<bits/stdc++.h>
 using namespace std;
 int main()
 {
 	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,l,ans;
 	int b[10000010];
	if(n%2!=0)
		cout<<"-1";
	else{
 		for(int i=1;i<=n;i++)
		{
			if( 2^i ==n)                                                        
				l=i;
				
		}
 		for(int j=1;j<=l;j++)
		{
			l=l-j;
 			ans++;
 		}
 		for(int m=ans;m>=1;m--)
 		{
			b[m]=m^2; 		}
	    for(int c=ans;c>=1;c--)
		{
			cout<<b[c];
		}
		}
		fclose(stdin);
 		fclose(stdout);
		return 0;
}