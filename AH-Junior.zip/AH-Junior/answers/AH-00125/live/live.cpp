 #include<iostream>
 #include<cstdio>
 #include<bits/stdc++.h>
 using namespace std;
 int main()
 {
 	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int p,n;
	char w;
	cin>>n>>w;
	fclose(stdin);
 	fclose(stdout);
	return 0;
}