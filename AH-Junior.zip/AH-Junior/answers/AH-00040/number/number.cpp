#include<bits/stdc++.h>
using namespace std;
const int dlt[3][2]={{1,0},{-1,0},{0,1}},N=1005;
int n,m,a[N][N],ans=0,s=0;
bool vis[N][N]={false};
bool check(int x,int y){
	return x<=n&&y<=m&&!vis[x][y]&&x>=1&&y>=1;
}
void dfs(int x,int y){
	if(x==n&&y==m){ans=max(ans,s);return;}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
		  int dx,dy;
		  dx=x+dlt[i][0];
		  dy=y+dlt[j][1];
		  if(check(dx,dy)){
			s+=a[dx][dy];
			vis[dx][dy]=true;
			dfs(dx,dy);
			vis[dx][dy]=false;
		  }else return;
	  }
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	vis[1][1]=true;
	dfs(1,1);
	cout<<ans;	
	return 0;
}