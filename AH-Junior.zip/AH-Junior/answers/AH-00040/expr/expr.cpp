#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5;
string s,st="",t[1000];
bool f[N]={false};
int n,a[N],m,b[N],c[N],v=1,k=0,x=0;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	getline(cin,s);
	s=s+' ';
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	cin>>m;
	for(int i=1;i<=m;i++)cin>>c[i];
	for(int i=0;i<s.size();i++){
		if(s[i]!=' ')st+=s[i];
		else if(st!=""&&st!="&"&&st!="|"){
			k++;
			f[k]=true;
			st="";
		}
		else{
			k++;
			f[k]=false;
			t[k]=st;
		}
	}
	for(int i=1;i<=m;i++){
		memset(b,0,sizeof(b));
		a[c[i]]=!a[c[i]];
		v=1;
		x=0;
		for(int j=1;j<=k;j++){
			if(f[j]){
			  x++;
			  b[x]=a[x];
			}
			if(!f[j]){
					if(t[j]=="&"){if(b[v]=b[v+1])b[v+1]=1;v++;}
					if(t[j]=="|"){if(b[v]==1||b[v+1]==1)b[v+1]=1;v++;}
					if(t[j]=="!"){if(b[x]==0)b[x]=1;else b[x]=0;}
				}
			}
			cout<<b[v]<<endl;
			a[c[i]]=!a[c[i]];
		}
	fclose(stdin);
	fclose(stdout);
    return 0; 
}