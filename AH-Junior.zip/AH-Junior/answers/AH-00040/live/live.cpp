#include<bits/stdc++.h>
using namespace std;
const int N=1e6;
int a[N],n,m,t;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		t=max(1,i*m/100);
		sort(a+1,a+i+1);
	    cout<<a[i-t+1]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}