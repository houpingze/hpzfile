#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,t1,t2,s=0,x=2,a[200],xt=2,st=0;
	cin>>n;
	if(n%2!=0){cout<<"-1";}else{
	t1=n/2;t2=n/2;
	if(t1%2!=0){t1=t1-1;t2=t2-1;s++;a[s]=x;}
	while(t2%2==0){
		st++;
		t2=t2/2;
	    xt=xt*2;
	}
	if(t2==1&&s==1){cout<<xt<<" "<<x;}
	else if(t2==1){cout<<xt;}
	else{
	while(t1>=x){
		t1-=x;
		x=x*2;
		s++;
		a[s]=x;
	}
	for(int i=s;i>=1;i--){
		if(a[i]!=0)cout<<a[i]<<" ";
	}
    }
   }
   fclose(stdin);
   fclose(stdout);
	return 0;
}