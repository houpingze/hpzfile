#include <bits/stdc++.h>
using namespace std;
int b[1001][1001];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int a[n+1][m+1][3],i,j;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
		{	cin>>a[i][j][1];
			a[i][j][2]=a[i][j][1];
		}
	int s=0;
	for(i=1;i<=n;i++)
	{
		//for(int i1=1;i1<=n;i1++)
		//for(int j1=1;j1<=m;j1++)
			//b[i1][j1]=0;
		for(j=1;j<=m;j++)
		{
			if(1<=i-1 && i-1<=n && b[i-1][j]!=1) {a[i-1][j][2]=max(a[i][j][2]+a[i-1][j][1],a[i-1][j][2]);b[i][j]=1;} 
			if(1<=i+1 && i+1<=n && b[i+1][j]!=1) {a[i+1][j][2]=max(a[i][j][2]+a[i+1][j][1],a[i+1][j][2]);b[i][j]=1;}
			if(1<=j-1 && j-1<=m && b[i][j-1]!=1) {a[i][j-1][2]=max(a[i][j][2]+a[i][j-1][1],a[i][j-1][2]);b[i][j]=1;}
			if(1<=j+1 && j+1<=m && b[i][j+1]!=1) {a[i][j+1][2]=max(a[i][j][2]+a[i][j+1][1],a[i][j+1][2]);b[i][j]=1;}
		}
	}
	for(i=1;i<=n;i++)
	{	for(j=1;j<=m;j++)
			cout<<a[i][j][2]<<" ";
		cout<<endl;
		}
	return 0;
}