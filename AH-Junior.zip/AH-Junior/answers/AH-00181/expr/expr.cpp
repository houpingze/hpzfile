#include <bits/stdc++.h>
using namespace std;
int b[1001][1001];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	getline(cin,s);
	int n;
	cin>>n;
	int a[n+1];
	int i;
	for(i=1;i<=n;i++)
		cin>>a[i];
	int m;
	cin>>m;
	int b[m+1];
	for(i=1;i<=m;i++)
		cin>>b[i];
	for(i=1;i<=m;i++)
		cout<<0<<endl;
	return 0;
}