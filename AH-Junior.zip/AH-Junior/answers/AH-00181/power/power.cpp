#include <bits/stdc++.h>
using namespace std;
int a[1000001];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	int k=1,s=0;
	int i,j;
	if(n%2==1) 
	{
		cout<<-1;
		return 0;
	}
	else
	{
		int s1=n;
		for(i=sqrt(n);i>=1;i--)
		{
			memset(a,0,sizeof(a));
			s1=n;
			s1-=pow(2,i);
			a[k]=pow(2,i);
			for(j=i-1;j>=1;j--)
			{
				if(s1-pow(2,j)==0)
				{
					s1=0;
					k++;
					a[k]=pow(2,j);
					break;
				}
				if(s1-pow(2,j)>0)
				{
					s1-=pow(2,j);
					k++;
					a[k]=pow(2,j);
				}
				
			}
		if(s1==0) break;
		}
		if(s1==0)
		{
			for(i=1;i<=k;i++)
				if(a[i]!=0)
					s++;
			for(i=1;i<=k;i++)
		     if(a[i]!=0 && s!=1)
		       cout<<a[i]<<" ";
		   if(s==1) cout<<-1;
		}
		else
			cout<<-1;
	}
   return 0;
}