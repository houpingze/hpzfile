#include <bits/stdc++.h>
using namespace std;
struct QQQ
{
	int x,y;
}a[111111];
int b[111111];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int i,j;
	for(i=1;i<=n;i++)
	{
	  cin>>a[i].x;
		a[i].y=max(1,i*m/100);
		//for(j=1;j<=i;j++)
		b[i]=a[i].x;
		sort(b+1,b+1+i);
		//for(j=1;j<=i;j++)
			//cout<<b[j]<<" ";
			//cout<<endl;
		cout<<b[i-a[i].y+1]<<" ";
	} 
	return 0;
}