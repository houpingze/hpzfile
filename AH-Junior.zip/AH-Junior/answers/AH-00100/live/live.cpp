#include<iostream>
#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int b[1000001]={0};
int n,w,c;
int main(void)
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++)
	{
		int x=0;
		scanf("%d",&x);
		b[i]=x;
	}
	for(int i=1;i<=n;i++)
	{
		int a[1000001]={0};
		for(int j=1;j<=i;j++)
		{
			a[j]=b[j];
		}
		sort(a+1,a+i+1);
		c=(i*w)-(i*w)%100;
		if(c==0)printf("%d ",a[i-c/100]);
		else if(c>0)printf("%d ",a[i-c/100+1]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}