#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int a=0,ans=0,b[100001]={0},flag=0;
void dfs(int t,int k)
{
	int i=0;
	if(k==1)
	{
		i=t;
	}
	else
	{
		i=t-1;
	}
	//printf("\n%d\n",k);
	for(int j=pow(2,i);j<=a;i--,j/=2)
	{
		ans+=j;
		//printf("%d %d %d %d\n",k,ans,j,i);
		if(ans<a)
		{
			dfs(i,k+1);
		}
		else if(ans>a)
		{
			ans-=j;
			//printf("!%d \n",ans);
		}
		else if(ans==a&&flag==0)
		{
			flag=1;
			b[0]=k;
		}
		if(flag==1)
		{
			//printf("k=%d\n",k);
			b[k]=j;//printf("b[%d]=%d ",k,b[k]);
			return;
		}
		//printf("\n");
	}
}
int main(void)
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%d",&a);
	if(a%2==0)
	{
		int maxx=0;
		int c=pow(2,1);
		while(c<=a)
		{
			maxx++;
			c=pow(2,maxx);
		}
		maxx-=1;
		//cout<<maxx<<endl;
		dfs(maxx,1);
		for(int i=1;i<=b[0];i++)
		{
			printf("%d ",b[i]);
		}
	}
	else
	{
		printf("-1");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}