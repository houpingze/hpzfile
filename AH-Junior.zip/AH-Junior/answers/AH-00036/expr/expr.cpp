#include<bits/stdc++.h>
using namespeas std;
int main()
{
	int n;
	cin>>n;
	cout<<n;
}