#include<bits/stdc++.h>
using namespace std;
int n,w;
int a[10001];
int main(){
	freopen("live.in","r",stdin);
        freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=10001;i++)
	 cin>>a[i];
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=w;j++)
	  if(a[i]>a[j])
	swap(a[i],a[j]);
	 cout<<n<<" "<<w<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
