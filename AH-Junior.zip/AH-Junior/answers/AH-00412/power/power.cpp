#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void prime(int n){
	if(n==2)
	 return true;
	else if(n!=2)
	 return false;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	cout<<n<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0; 
}