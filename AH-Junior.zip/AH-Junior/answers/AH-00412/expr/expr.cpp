#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char s;
	int n;
	int q;
	cin>>n>>q;
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=q;j++)
	  if(a[i]<a[j])
	   cout>>n>>q;
	fclose(stdin);
	fclose(stdout);
	return 0;
}