#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[5005][5005];
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=m;j++)
	  if(a[i][j]==2)
	   cout<<"no";
	else if(a[i][j]!=2)
	   cout<<a[i][j];
	fclose(stdin);
	fclose(stdout);
	return 0;
}