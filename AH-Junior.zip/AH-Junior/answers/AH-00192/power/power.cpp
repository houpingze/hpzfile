#include <cstdio>
using namespace std;
int a[30]={2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432};
bool b[20];
int c,d;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n%2!=0){
		printf("-1");
		return 0;
	}
	for(int i=0;i<=25;i++){
		if(n<=a[i]){
			c=i-1;
			break;
		}
	}
	d=c;
	while(n!=0){
		if(n-a[c]>=0){
			n-=a[c];
			b[c]=1;
			c--;
		}
		else c--;
	}
	for(int i=d+1;i>=0;i--)
		if(b[i])printf("%d ",a[i]);
	return 0;
}