#include <cstdio>
using namespace std;
int d1[5]={0,1,0},d2[5]={-1,0,1};
int n,m,a[1010][1010],ans=-10000010;
bool b[1010][1010];
void dfs(int x,int y,int s){
	if(x==n&&y==m){
		ans=s>ans?s:ans;
		return ;
	}
	b[x][y]=1;
	for(int i=0;i<3;i++){
		int x1=x+d1[i],y1=y+d2[i];
		if(x1>0&&x1<=n&&y1>=0&&y1<=m&&b[x1][y1]==0){
			return dfs(x1,y1,s+a[x1][y1]);
		}
	}
	b[x][y]=0;
	return;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	dfs(1,1,a[1][1]);
	printf("%d",ans);
	return 0;
}