#include <cstdio>
#include <algorithm>
using namespace std;
int n,w;
int score[100010],line;
int Down(int a,int b){
	int c=a*w;
	return c=(c-c%100)/100;
}
int maxn(int a,int b){
	return a>b?a:b;
}
bool cmp(const int & x,const int & y){
	return x>y;
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d %d",&n,&w);
	for(int i=1;i<=n;i++){
		scanf("%d",&score[i]);
		sort(score+1,score+1+i,cmp);
		line=maxn(1,Down(i,w));
		printf("%d ",score[line]);
	}
	return 0;
}