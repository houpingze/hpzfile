#include<iostream>
#include<cstdio>
using namespace std;
int a[35]={0};
void mi(int n){
	if(n==0)return;
	int k=2,cnt=1;
	while(n>=k*2){
		k*=2;
		cnt++;
	}
	a[cnt]++;
	if(a[cnt]==1)cout<<k;
	if(n-k!=0)cout<<" ";
	mi(n-k);
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	if(n%2!=0){
		cout<<"-1";
		return 0;
	}
	else{
		mi(n);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}