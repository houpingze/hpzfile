#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
bool cmp(int a,int b){
	return a>b;
}
int a[100001],b[100001];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w,c;
	cin>>n>>w;
	for(int i=1;i<=n;i++){
	cin>>a[i];
	sort(a+1,a+i+1,cmp);
	c=i*w/100;
	if(c==0)c=1;
	b[i]=a[c];
	}
	for(int j=1;j<=n;j++){
		cout<<b[j];
		if(j!=n)cout<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}