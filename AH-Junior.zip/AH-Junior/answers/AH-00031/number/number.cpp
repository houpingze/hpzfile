#include<iostream>
#include<cstdio>
using namespace std;
int a[1001][1001],book[1001][1001],sum=a[1][1];
int n,m,max_=-1999999999;
int dx[4]={-1,1,0},dy[4]={0,0,1};
void dfs(int x,int y){
	if(x==n&&y==m){
		return;
	}
	for(int i=0;i<3;i++){
		int nx=x+dx[i];
		int ny=y+dy[i];
		if(nx>0&&nx<=n&&ny>0&&ny<=m&&book[nx][ny]==0){
			book[nx][ny]=1;
			sum+=a[nx][ny];
			dfs(nx,ny);
			book[nx][ny]=0;
			max_=max(max_,sum);
			sum=a[nx][ny];
		}
	}
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
		}
	}
	if(n==1&&m==1){
		cout<<a[1][1];
		return 0;
	}
	book[1][1]=1;
	dfs(1,1);
	cout<<max_;
	fclose(stdin);
	fclose(stdout);
	return 0;
}