#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	getline(cin,s);
	int n,q,a[10001],que[10001];
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		cin>>que[i];
	}
	if(n==3)cout<<0<<endl<<0<<endl<<1;
	else cout<<0<<endl<<0<<endl<<1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}