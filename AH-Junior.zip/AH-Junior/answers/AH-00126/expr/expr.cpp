#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char c[10001];
	gets(c);
	int n;
	cin>>n;
	int a[10001];
	for(int i=1;i<=n;i++) cin>>a[i];
	int q;
	cin>>q;
	int b[10001];
	for(int j=1;j<=q;j++)
	{
		cin>>b[j];
	}
	cout<<"0"<<endl<<"0"<<endl<<"1"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}