#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	if(n%2==1) cout<<"-1";
	else
	{
	int maxx,s=n;
	int i;
	while(s!=0)
	{
		for(i=1;;i++)
		{
			if(pow(2,i)>s) break;
		}
		i--;
		s-=pow(2,i);
		cout<<pow(2,i)<<" ";
	}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}