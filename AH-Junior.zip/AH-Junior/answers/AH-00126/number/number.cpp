#include<bits/stdc++.h>
using namespace std;
int w[4]={0,-1,1,0};
int v[4]={0,0,0,1};
bool b[1001][1001];
int n,m,a[1001][1001];
int maxa=-99999999;
int baocun(int maxx)
{
	if(maxx>maxa) maxa=maxx;
}
void dfs(int x,int y,int maxx)
{
	//if(maxx>maxa) return;
	if(x==n&&y==m)
	{
		//cout<<"!!"<<maxx<<endl;
		baocun(maxx);
		return;
	}
	for(int i=1;i<4;i++)
	{
		int xx=x+w[i];
		int yy=y+v[i];
		if(xx<=0||xx>n||yy<=0||yy>m) continue;
		if(b[xx][yy]==0)
		{
			b[xx][yy]=1;
			maxx+=a[xx][yy];
			dfs(xx,yy,maxx);
			b[xx][yy]=0;
			maxx-=a[xx][yy];
		}
	}
}
int main()
{
freopen("number.in","r",stdin);
freopen("number.out","w",stdout);
cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
b[1][1]=1;
	dfs(1,1,a[1][1]);
	cout<<maxa;
fclose(stdin);
fclose(stdout);
	return 0;
}