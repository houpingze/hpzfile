#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int a[100001],n;
	int w;
	cin>>n>>w;
	int p;
	int s,i,j,v;
	bool flag=0;
	memset(a,0,sizeof(a));
	for(i=1;i<=n;i++)
	{
		cin>>v;
		flag=0;
		if(v>a[i-1])
		for(j=1;j<=i;j++)
		{
			if(v>a[j])
			{
				for(int z=i+1;z>=j+1;z--)
				{
					a[z]=a[z-1];
				}
				a[j]=v;
					flag=1;
				break;
			}
		}
		if(flag==0) a[i]=v;
		s=w*i/100;
		p=max(1,s);
		cout<<a[p]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}