#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
string s;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s=="x1 x2 & x3 |")cout<<"1\n1\n0";
		else cout<<"0\n1\n1";
	fclose(stdin);
	fclose(stdout);
	return 0;
}