#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int n,m,a[100005],b[605],fs;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		int t=max(1,i*m/100);;
		cin>>a[i];
		b[a[i]]++;
		for(int j=600;j>=0;j--){
			t-=b[j];
			if(t<=0){
				fs=j;
				break;
			}
		}
		cout<<fs<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}