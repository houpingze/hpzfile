#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int ans[35],n,l,s[10005],t;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	ans[1]=2;
	for(int i=2;i<=30;i++)ans[i]=ans[i-1]*2;
	for(int i=30;i>=1;i--)if(n>=ans[i]){
		l=i;
		break;
	}
	t=0;
	while(n!=0&&l>=1){
		if(n>=ans[l]){
			t++;
			s[t]=ans[l];
			n-=ans[l];
			l--;
		}
		else l--;
	}
	if(n==0){
		for(int i=1;i<=t;i++)cout<<s[i]<<" ";
	}
	else{
		cout<<"-1";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}