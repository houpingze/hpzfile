#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
using namespace std;
int n,m,a[1005][1005],dis[4][2]={{0,0},{-1,0},{1,0},{0,1}},ans=-0x3f;
bool jg[1005][1005];
void dfs(int x,int y,int s){
	if(x==n&&y==m){
		if(s>ans)ans=s;
		return ;
	}
	for(int i=1;i<=3;i++){
		int xx=x+dis[i][0],yy=y+dis[i][1];
		if(xx<=n&&xx>=1&&yy<=m&&yy>=1&&!jg[xx][yy]){
			jg[xx][yy]=1;
			dfs(xx,yy,s+a[xx][yy]);
			jg[xx][yy]=0;
		}
	}
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)cin>>a[i][j];
	jg[1][1]=1;
	dfs(1,1,a[1][1]);
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}