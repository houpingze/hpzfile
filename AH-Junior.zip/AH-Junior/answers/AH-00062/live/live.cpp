#include<bits/stdc++.h>
using namespace std;
bool qwe(int x,int y){
	return x>y;
	}
int main(){
	int n,w,a[100001];
	ifstream cin("live.in");
	ofstream cout("live.out");
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		int m=i;
		sort(a+1,a+m+1,qwe);
		int t=i*w/100;
		if(t==0){
			cout<<a[1]<<" ";
			}else{
			cout<<a[t]<<" ";
				}
		}
	cin.close();
	cout.close();
	return 0;
	}