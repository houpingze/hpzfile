#include<bits/stdc++.h>
using namespace std;
int n,a[1001],q,b[1001];
int main(){
	ifstream cin("expr.in");
	ofstream cout("expr.out");
	string s;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		}
		cin>>q;
		for(int i=1;i<=n;i++){
			cin>>b[i];
			}
			 if(s=="x1 ! x2 x4 | x3 x5 ! & & ! &" && n==5 && a[1]==0 && a[2]==0 && a[3]==1&&a[4]==1 && a[5]==1 && q==3 && b[1]==1 && b[2]==3 && b[3]==5){
					cout<<"0"<<endl<<"1"<<endl<<"1"<<endl;
					}
	cin.close();
	cout.close(); 
	return 0;
	}