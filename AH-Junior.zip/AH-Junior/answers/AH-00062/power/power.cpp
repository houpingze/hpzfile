#include<bits/stdc++.h>
using namespace std;
int a[10001],b=0,p=0,er[25]={0,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,10384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216};
void qwe(int x,int k){
	if(x==0){
		b=1;
		}else if(k==0 && x!=0){
			return ;
			}
	for(int i=k;i>=1;i--){
			if(x>=er[i]){
				p++;
				a[p]=er[i];
				qwe(x-a[p],i-1);
				if(b==1){
					return ;
					}
				p--;
				}
		}
	}
int main(){
	ifstream cin("power.in");
	ofstream cout("power.out");
	int n;
	cin>>n;
	if(n==1 || n%2==1){
		cout<<"-1"<<endl;
		return 0;
		}
	qwe(n,24);
	if(b==1){
		for(int i=1;i<p;i++){
			cout<<a[i]<<" ";
			}
			cout<<a[p]<<endl;
		}else{
			cout<<"-1"<<endl;
			return 0;
			}
	cin.close();
	cout.close();
	return 0;
	}