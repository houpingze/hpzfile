#include<bits/stdc++.h>
using namespace std;
int a[1001][1001],b[1001][1001],d[4][2]={{0,0},{1,0},{0,1},{-1,0}},k=-9999999;
int m,n;
void qwe(int x,int y){
	if(x==m && n==y){
		k=max(k,a[x][y]);
		}
		for(int i=1;i<=3;i++){
			int dx=x+d[i][0];
			int dy=y+d[i][1];
			if(dx>=1 && dx<=m && dy>=1 && dy<=n && b[dx][dy]==0){
				b[dx][dy]=1;
				a[dx][dy]+=a[x][y];
					qwe(dx,dy);
				a[dx][dy]-=a[x][y];	
				b[dx][dy]=0;
			}
		}
	}
int main(){
	ifstream cin("number.in");
	ofstream cout("number.out");
	cin>>m>>n;
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];
			b[i][j]=0;
			}
		}
	qwe(1,1);
	cout<<k<<endl;
	cin.close();
	cout.close();
	return 0;
	}