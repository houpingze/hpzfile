#include<cstdio>
#include<algorithm>
using namespace std;

inline void in(int &x){
    x=0;register char c=getchar();register int f=1;
    while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
    while(c>='0'&&c<='9') x=x*10+c-'0', c=getchar();
    x*=f;
}

int n,w,f[605];

int main(){
	freopen("live.in","r",stdin);freopen("live.out","w",stdout);
	in(n);in(w);
	for(int i=1;i<=n;i++){
		int x;in(x);
		f[x]++;
		int p=i*w/100,j;
		if(p<1){
			for(j=600;j>=0&&!f[j];j--);
			printf("%d ",j);
		}
		else{
			for(j=600;j>=0;j--)
				if(p<=f[j]) break;
				else p-=f[j];
			printf("%d ",j);
		}
	}
    return 0;
}