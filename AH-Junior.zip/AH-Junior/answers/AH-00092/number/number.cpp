#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long ll;

inline void in(int &x){
    x=0;register char c=getchar();register int f=1;
    while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
    while(c>='0'&&c<='9') x=x*10+c-'0', c=getchar();
    x*=f;
}

int n,m,a[1005][1005];
bool vis[1005][1005];
ll ans=-1e16,f[1005][1005];

void dfs(int x,int y,ll s){
	if(vis[x][y]||x<1||x>n||y<1||y>m||s<f[x][y]) return;
	f[x][y]=s;
	if(x==n&&y==m){
		ans=max(ans,s+a[x][y]);
		return;
	}
	vis[x][y]=1;
	dfs(x-1,y,s+a[x][y]);
	dfs(x+1,y,s+a[x][y]);
	dfs(x,y-1,s+a[x][y]);
	dfs(x,y+1,s+a[x][y]);
	vis[x][y]=0;
}

int main(){
    freopen("number.in","r",stdin);freopen("number.out","w",stdout);
    in(n),in(m);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) in(a[i][j]),f[i][j]=-1e16;
	dfs(1,1,0);
	printf("%lld\n",ans);
    return 0;
}