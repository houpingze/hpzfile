#include<cstdio>
#include<cstring>
#include<iostream>
#include<string>
using namespace std;

inline void in(int &x){
    x=0;register char c=getchar();register int f=1;
    while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
    while(c>='0'&&c<='9') x=x*10+c-'0', c=getchar();
    x*=f;
}

string s;
char exp[1000005];
int n,q,now,x[100005],len;
struct Node{
	int fa,lson,rson,val;
}a[1000005];

int main(){
	freopen("expr.in","r",stdin);freopen("expr.out","w",stdout);
	getline(cin,s);
	in(n);
	for(int i=1;i<=n;i++) in(x[i]);
	in(q);
	while(q--){
		int p;in(p);  
		puts("0");
	}
    return 0;
}