#include<cstdio>
using namespace std;

int n,p2[27];

int main(){
    freopen("power.in","r",stdin);freopen("power.out","w",stdout);
    p2[0]=1;
	for(int i=1;i<=25;i++) p2[i]=p2[i-1]*2;
	scanf("%d",&n);
	if(n%2) printf("-1\n");
	else{
		int j;
		for(j=25;n;j--)
			if(p2[j]<=n) n-=p2[j],printf("%d ",p2[j]);
	}
    return 0;
}