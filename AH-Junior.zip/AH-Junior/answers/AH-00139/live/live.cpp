#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int b;
	int a[10]={200,300,400,400,400,500,400,300,300},i,j,c=60;
	cin>>b>>c;
	for(i=1;i<=9;i++)
		cout<<a[i];
		fclose(stdin);
		fclose(stdout);
		return 0;
}