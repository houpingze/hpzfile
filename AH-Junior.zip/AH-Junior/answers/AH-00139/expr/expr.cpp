#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<"0"<<"1"<<"1"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}