#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int i=0,j,a,k,s=0,t;
	cin>>a;
	if(a%2==1||a==0)
	{
		cout<<"-1";
		return 0;
	}
	if(a==2)
	{
		cout<<"2";
		return 0;
	}
	for(i=1;i=1;i++)
	{
		if(k>a)
			{
				a=k-pow(2,s-1);
				s=0;k=0;
				cout<<a<<"  "<<endl;
					break;
			}
			s++;
		k=pow(2,s);
			
		}
		;
	fclose(stdin);
	fclose(stdout);
	return 0;
}