#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
using namespace std;
int main()
{
	freopen("number","r",stdin);
	freopen("number","w",stdout);
	int a=1;b=2;c=3;
	cout<<a<<b<<c;
	fclose(stdin);
	fclose(stdout);
	return 0;
}