#include<bits/stdc++.h>
using namespace std;
int a[100005];
int main(){
	int n,m,f;
	scanf("%d%d",&n,&m);
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int nom=n*m/100;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		if(a[i]>a[i-1]){
		a[i-1]=a[i];
	}
	}
	for(int i=1;i<=n;i++){
		if(i<=nom){
			cout<<a[i]<<" ";
			}
		}
		return 0;
}