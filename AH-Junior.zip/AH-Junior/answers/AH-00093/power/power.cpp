#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n%2==1){
		cout<<-1;
	}else{ 
	for(int i=4;i<=n;i=i*2){
		if(n==i){
		   printf("%d",-1);
		}
		if(n==2){
			printf("%d",-1);
		}
		if(i+2==n){
			printf("%d 2",i);
		}
	}
}
	return 0;
}