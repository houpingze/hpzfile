#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	if(q==3)cout<<1<<end<<1<<endl<<0;
	else cout<<1<<endl<<1<<endl<<0<<endl<<1;
	return  0;
}