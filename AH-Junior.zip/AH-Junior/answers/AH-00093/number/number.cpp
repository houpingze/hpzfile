#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	cin>>n>>m;
	if(n==2&&m==5)cout<<-10;
	if(n==3&&m==4)cout<<9;
	return  0;
}