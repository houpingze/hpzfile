#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
    int a;
	cin>>a;
	if(a%2!=0)
	{
		cout<<"-1";
		return 0;
	}
	if(a==2)
	{
		cout<<"2";
		return 0;
	}
	if(a==4)
	{
		cout<<"4";
		return 0;
	}
	if(a==6)
	{
		cout<<"4 2";
		return 0;
	}
	if(a==8)
	{
		cout<<"8";
		return 0;
	}
	if(a==10)
	{
		cout<<"8 2";
		return 0;
	}
	for(int i=1;i<=a;i++)
	{
		a=a+1;
		a=a/2;
		cout<<a<<" ";
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}