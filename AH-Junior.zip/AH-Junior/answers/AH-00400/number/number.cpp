#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);

	return 0;
	fclose(stdin);
	fclose(stdout);
}