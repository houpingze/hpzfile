#include<bits/stdc++.h>
using namespace std;
int a[100],m[100];
int main()
{
	freopen(power.in,"r",stdin);
	freopen(power.out,"w",stdout);
	int n,b=0,c=0;
	cin>>n;
	m[0]=1;
	for(int i=1;i<100;i++)
	{
		b++;
		m[i]=m[i-1]*2;
		if(m[i]>n)
		{
			break;
		}
	}
	b--;
	for(int i=b;i>=1;i--)
	{
		if(n>=m[i])
		{
			n=n-m[i];
			a[c]=m[i];
			c=c+1;
		}
		if(n==0)
		{
			for(int j=0;j<c;j++)
			{
				cout<<a[c]<<" "; 
			}
			return 0;
		}
	}
	cout<<"-1";
}