#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen(live.in,"r",stdin);
	freopen(live.out,"w",stdout);
	cout<<"100 100 600 600 600 600 100 100 100 100";
}