#include<bits/stdc++.h>
using namespace std;
int a[1000][1000];
int main()
{
	freopen(power.in,"r",stdin);
	freopen(power.out,"w",stdout);
	int n,m,b=0;
	cin>>n>>m;
	for(int i=0;i<n;i=i+1)
	{
		for(int j=0;j<m;j=j+1)
		{
			cin>>a[i][j];
			a[i][j]=a[i][j]+10000;
		}
	}
	for(int i=0;i<n;i=i+0)
	{
		for(int j=0;J<m;j=j+0)
		{
			b=b+a[i][j]-10000;
			if(a[i+1][j]>a[i][j+1]>a[i-1][j]||a[i+1][j]>a[i-1][j]>a[i][j+1])
			{
				a[i][j]=a[i][j]-10000;
				i++;
			}
			if(a[i][j+1]>a[i+1][j]>a[i-1][j]||a[i][j+1]>a[i-1][j]>a[i+1][j])
			{	
				a[i][j]=a[i][j]-10000;
				j++;
			}
			if(a[i-1][j]>a[i][j+1]>a[i+1][j]||a[i-1][j]>a[i+1][j]>a[i][j+1])
			{
				a[i][j]=a[i][j]-10000;
				i--;
			}
			if(i=n-1&&j=m-1)
			{
				cout<<b;
			}
		}
	}
}