#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
int a[10005];
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,temp=1;
	scanf("%d",&n);
	if (n%2==1){
		printf("-1\n");
		return 0;
	}
	int i=1;
	for (i=1;i<n;i*=2){
		i=i;
	}
	i/=2;
	for (i=i;i>1;i/=2){
		if (n>=i){
			n-=i;
			a[temp]=i;
			temp++;
		}
	}
	if (n==1){
		printf("-1\n");
		return 0;
	}
	for (int j=1;j<temp;j++){
		printf("%d ",a[j]);
	}
	printf("\n");
	return 0;
}