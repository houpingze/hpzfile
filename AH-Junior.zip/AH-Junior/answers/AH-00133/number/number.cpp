#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
int a[1005][1005];
bool b[1005][1005];
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m,ans=0,t;
	scanf("%d %d",&n,&m);
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for (int i=1;i<=n;i){
		for (int j=1;j<=m;j){
			if (i==n&&j==m) {
				printf("%d\n",ans);
				return 0;
			}
			ans+=a[i][j];
			b[i][j]=false;
			if (i==1&&j==1){
				if (a[i+1][j]>a[i][j+1]) i++;
				else j++;
			}
			if (i==1&&j!=1&&j!=m){
				if (a[i][j-1]>a[i][j+1]&&a[i][j-1]>a[i+1][j]&&b[i][j-1]) j--;
				if (a[i][j+1]>a[i][j-1]&&a[i][j+1]>a[i+1][j]&&b[i][j+1]) j++;
				if (a[i+1][j]>a[i][j+1]&&a[i+1][j]>a[i][j-1]&&b[i+1][j]) i++;
			}
			if (i!=1&&j==1&&i!=n){
				if (a[i-1][j]>a[i+1][j]&&a[i-1][j]>a[i][j+1]&&b[i-1][j]) i--;
				if (a[i+1][j]>a[i][j+1]&&a[i+1][j]>a[i-1][j]&&b[i+1][j]) i++;
				if (a[i][j+1]>a[i+1][j]&&a[i][j+1]>a[i-1][j]&&b[i][j+1]) j++;
			}
			if (i!=1&&j!=1&&j!=m&&i!=n){
				if (a[i][j-1]>a[i][j+1]&&a[i][j-1]>a[i+1][j]&&b[i][j-1]) j--;
				if (a[i][j+1]>a[i][j-1]&&a[i][j+1]>a[i+1][j]&&b[i][j+1]) j++;
				if (a[i+1][j]>a[i][j+1]&&a[i+1][j]>a[i][j-1]&&b[i+1][j]) i++;
				if (a[i-1][j]>a[i][j+1]&&a[i-1][j]>a[i][j-1]&&b[i-1][j]) i--;
			}
			if (i==n&&j==1){
				if (a[i][j+1]>a[i-1][j]&&b[i][j+1]) j++;
				if (a[i-1][j]>a[i][j+1]&&b[i-1][j]) i--;
			}
			if (j!=1&&j!=m&&i==n){
				if (a[i][j-1]>a[i][j+1]&&a[i][j-1]>a[i+1][j]&&b[i][j-1]) j--;
				if (a[i][j+1]>a[i][j-1]&&a[i][j+1]>a[i+1][j]&&b[i][j+1]) j++;
				if (a[i-1][j]>a[i][j+1]&&a[i-1][j]>a[i][j-1]&&b[i-1][j]) i--;
			}
			if (i==1&&j==m){
				if (a[i][j-1]>a[i][j+1]&&a[i][j-1]>a[i+1][j]&&b[i][j-1]) j--;
				if (a[i+1][j]>a[i][j+1]&&a[i+1][j]>a[i][j-1]&&b[i+1][j]) i++;
			}
			if (i!=1&&j==m&&i!=n){
				if (a[i][j-1]>a[i][j+1]&&a[i][j-1]>a[i+1][j]&&b[i][j-1]) j--;
				if (a[i+1][j]>a[i][j+1]&&a[i+1][j]>a[i][j-1]&&b[i+1][j]) i++;
				if (a[i-1][j]>a[i][j+1]&&a[i-1][j]>a[i][j-1]&&b[i-1][j]) i--;
			}
		}
	}
	return 0;
}