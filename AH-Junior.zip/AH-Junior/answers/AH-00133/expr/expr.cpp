#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
char a[10000005];
int x[1000005];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int n;
	gets(a);
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%d",&x[i]);
		printf("%d",x[i]);
	}
	return 0;
}