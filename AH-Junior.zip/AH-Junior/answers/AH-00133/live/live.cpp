#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
int a[100005];
bool cmp(int p,int q){
	return q<p;
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w,x;
	scanf("%d %d",&n,&w);
	for (int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sort(a+1,a+1+i,cmp);
		x=max(1.0,floor(1.0*i*(1.0*w/100.0)));
		printf("%d ",a[x]);
	}
	printf("\n");
	return 0;
}