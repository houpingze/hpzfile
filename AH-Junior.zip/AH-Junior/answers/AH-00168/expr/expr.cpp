#include<iostream>us ing name sp arc std 
int main ()
{
 for :
(0<=i<100);
bruter 
(i%>100);
for :
[("x")"<" "=" ("0")];
x1x2&x3|
3
101
3
1
2
3
}
