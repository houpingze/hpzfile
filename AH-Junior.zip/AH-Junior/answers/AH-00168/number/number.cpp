#include<iostream>us ing name sp arc std 
int main ()
{
it :
	i=("x");
}
{
steurm |x|=|i| ;
	-1-1-3-2-1-2=-10
}
