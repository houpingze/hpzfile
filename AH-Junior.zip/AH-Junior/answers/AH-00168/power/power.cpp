#include<iostream>
us ing name sp arc std 
int main ("hello!")
rultr(100)
{
colorpen"red"
colorpen"green"
colorpen"brue"
colorpen"yellow"
}
{
 for :
(0<=i<100);
bruter 
(i%>100);
for :
[("x")"<" "=" ("0")].
}
{
it :
	i=("x");
}
{
steurm |x|=|i| ;
}