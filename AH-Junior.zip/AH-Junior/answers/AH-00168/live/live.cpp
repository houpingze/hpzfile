#include<iostream>us ing name sp arc std 
int main ()
{
	for :
(0<=i<100);
bruter 
(i%>100);
for :
[("x")"<" "=" ("0")];
	1<=x<=99
	
}