#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w;
	int a[100001];
	cin>>n>>w;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		int f=i;
		for(int j=i;j>=1;j--)
		{
			if(a[i]>a[j])f=j;
		}
		int x=a[i];
		for(int j=i-1;j>=f;j--)
		{
			a[j+1]=a[j];
		}
		a[f]=x;
		for(int j=1;j<=i;j++)cout<<a[j]<<" ";
		cout<<endl;
		int s=max(1,i*w/100);
		cout<<"s="<<s<<endl;
		cout<<a[s]<<endl;
	}
	//while(true){}
	fclose(stdin);
	fclose(stdout);
	return 0;
}