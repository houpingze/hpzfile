#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	srand(time(0));
	string f;
	getline(cin,f);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){int k;cin>>k;}
	int q;
	cin>>q;
	for(int i=1;i<=q;i++){int k;cin>>k;}
	for(int i=1;i<=q;i++)
	{
		cout<<rand()%2<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}