#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long n;
	long long k=1;
	cin>>n;
	if(n%2==1)
	{
		cout<<-1;
		return 0;
	}
	while(n!=0)
	{
		k=1;
		while(true)
		{
			if(n<k*2)
			{
				n-=k;
				cout<<k<<" ";
				break;
			}
			k=k*2;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}