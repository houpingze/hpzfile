#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int n,m;
int a[1001][1001];
bool b[1001][1001];
int tot=-1;
bool s=false;
void dfs(int x,int y,int t)
{
	if(x>n||x<1||y>m||y<1||b[x][y])return;
	if(x==n&&y==m)
	{
		if(s==false)
		{
			s=true;
			tot=t;
		}
		else
		{
			tot=max(tot,t);
		}
	}
	b[x][y]=true;
	dfs(x+1,y,t+a[x+1][y]);
	dfs(x,y+1,t+a[x][y+1]);
	dfs(x-1,y,t+a[x-1][y]);
	b[x][y]=false;
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
	dfs(1,1,a[1][1]);
	cout<<tot;
	fclose(stdin);
	fclose(stdout);
}