#include<bits/stdc++.h>
using namespace std;
int xx[4]={0,-1,0,1},yy[4]={0,0,1,0},n,m,a[1005][1005],f[1005][1005],maxn=-0x7fffffff,sum,t;
int dfs(int x,int y){
	if(x==n&&y==m){
		sum=t;
		maxn=max(maxn,sum);
		sum=a[1][1];
		memset(f,0,sizeof(f));
		f[1][1]=1;
		t=a[1][1];
	}
	for(int i=1;i<=3;i++){
		if(f[x+xx[i]][y+yy[i]]==0&&x+xx[i]>=1&&x+xx[i]<=n&&y+yy[i]<=m){
			t+=a[x+xx[i]][y+yy[i]];
			f[x+xx[i]][y+yy[i]]=1;
			dfs(x+xx[i],y+yy[i]);
		}
		else{
			f[x][y]=0;
			t-=a[x][y];
		}
	}
	return maxn;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	f[1][1]=1;
	t=a[1][1];
	cout<<dfs(1,1);
	return 0;
}