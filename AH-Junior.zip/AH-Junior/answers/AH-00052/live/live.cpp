#include<bits/stdc++.h>
using namespace std;
int n,a[605],w,t,p,s,f,minn=0x7fffffff,maxn=-0x7fffffff;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>t;
		a[t]++;
		f=floor(i*w*1.0/100);
		p=max(1,f);
		maxn=max(t,maxn);
		for(int j=maxn;s<p;j--){
			if(a[j]!=0){
				s+=a[j];
				minn=min(j,minn);
			}
		}
		cout<<minn<<" ";
		s=0;
		minn=0x7fffffff;
	}
	return 0;
}