#include<bits/stdc++.h>
using namespace std;
char s[1000005];
int n,q,a[55555];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	gets(s);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	cin>>q;
	for(int i=1;i<=q;i++)cout<<0<<endl;
	return 0;
}