#include<bits/stdc++.h>
using namespace std;
int n,t=20,f[21]={0,2,4,8,16,32,64,128,256,512,1024,2048,4096,4096*2,4096*4,4096*8,4096*16,4096*32,4096*64,4096*128,4096*256};
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);

	cin>>n;
	if(n%2!=0)cout<<"-1\n";
	else{
		for(int i=1;i<=t;i++){
			if(n==f[i]){
				cout<<f[i]<<endl;
				return 0;
			}
			else{
				if(n<f[i]){
					if(n==0)return 0;
					cout<<f[i-1]<<" ";
					n-=f[i-1];
					t=i-1;
					i=1;
				}
			}
		}
	}
	return 0;
}