#include<bits/stdc++.h>
using namespace std;
int n,a[1010],s;
void read(int &x)
{
	x=0;
	int f=1;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	read(n);
	if(n%2!=0)
	{
		cout<<"-1";
		return 0;
	}
	while(n!=0)
	{
		a[++s]=n%2;
		n/=2;
	}
	for(int i=s;i>0;i--)
	{
		int t=a[i]*pow(2,i-1);
		if(t>0)printf("%d ",t);
	}
	return 0;
}