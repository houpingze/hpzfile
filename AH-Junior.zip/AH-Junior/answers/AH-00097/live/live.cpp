#include<bits/stdc++.h>
using namespace std;
int n,w,a[100100];
void read(int &x)
{
	x=0;
	int f=1;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
			ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	read(n);read(w);
	for(int i=1;i<=n;i++)
	{
		int x;
		read(x);
		a[i]=x;
		int k=i,t=i*w/100;;
		int s=max(1,t);
		for(int j=i-1;j>0;j--)
		{
			if(a[k]>a[j])
			{
				swap(a[k],a[j]);
				k=j;
			}
			else break;
		}
		printf("%d ",a[s]);
	}
	return 0;
}