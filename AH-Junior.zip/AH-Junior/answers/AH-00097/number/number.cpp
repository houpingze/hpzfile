#include<bits/stdc++.h>
using namespace std;
long long f[1010][1010][5],ans=-10000000;
int a[1010][1010],n,m;
void read(int &x)
{
	x=0;
	int f=1;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
			ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	read(n);read(m);
	for(int i=0;i<=n+1;i++)
	{
		for(int j=0;j<=m+1;j++)
			  for(int z=0;z<3;z++)
			f[i][j][z]=-10000000;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			read(a[i][j]);
	f[1][1][0]=f[1][1][1]=f[1][1][2]=a[1][1];
	for(int i=2;i<=n;i++)
	{
		f[i][1][2]=f[i-1][1][2]+a[i][1];
	}
	for(int j=2;j<=m;j++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int k=0;k<3;k++)
			   f[i][j][0]=max(f[i][j-1][k],f[i][j][0]);
		    f[i][j][0]+=a[i][j];
		    f[i][j][2]=max(f[i-1][j][0],f[i-1][j][2]);
		    f[i][j][2]+=a[i][j];
		}
		for(int i=n;i>=1;i--)
		{
			f[i][j][1]=max(f[i+1][j][0],f[i+1][j][1]);
			f[i][j][1]+=a[i][j];
		}
	}
	for(int i=0;i<3;i++)
	   ans=max(ans,f[n][m][i]);
    cout<<ans;
	return 0;
}