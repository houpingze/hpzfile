#include<bits/stdc++.h>
using namespace std;
int n,q,x;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char a[10000];
	cin.getline(a,10000);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
		cin>>q;
		for(int i=1;i<=q;i++)cin>>x;
	for(int i=1;i<=q;i++)
		cout<<"0"<<endl;
	return 0;
}