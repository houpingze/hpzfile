#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,w,r,j;
	cin>>n;
	int a[1000000]={};
	for(int i=0;i<n;i++){
		scanf("%d ",&a[i]);
		if(a[i-1]>a[i]){
			w=a[i-1];
			a[i]=w;
			a[i-1]=a[i];
		}
	}
	for(int j=0;j<n-1;j++){
		printf("%d ",a[j]);
		
	}
	return 0;
}