#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,b=1,w,j;
	scanf("%d",&n);
	int a[1000000]={};
	if(n%2!=0){
		cout<<-1;
		return 0;
	}
	for(int i=0;i<=n;i++){
		b=b*2;
		a[i]=b;
	}for(j=1;j<=n;j++){
	for(int m=0;m<=n;m++){
		if(n<=64){
        if(a[j]+a[m]==n){
			cout<<max(a[m],a[j])<<" "<<n-max(a[m],a[j]);
			return 0;
		}
	}
	
		}
	}
	}

