#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,m;
	cin>>n>>m;
	int a[1000][1000]={};
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			scanf("%d ",&a[i][j]);
		}
		sca1("/n");
	}
	for(int c=0;c<n;c++){
		for(int b=0;b<m;b++){
			printf("%d ",a[c][b]);
		}
	}
}

