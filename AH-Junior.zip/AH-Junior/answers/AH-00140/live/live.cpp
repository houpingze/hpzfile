#include<bits/stdc++.h>
using namespace std;
const int N=100000+10;
bool cmp(int a,int b){
	return a>b;
}
int ans[N];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	ios::sync_with_stdio(0);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
	    cin>>ans[i];
		sort(ans+1,ans+i+1,cmp);
		int peo=max(1,(int)(i*m/100));
		cout<<ans[peo];
		if(i!=n) cout<<" ";
	}
	return 0;
}
