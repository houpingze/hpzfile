#include<bits/stdc++.h>
using namespace std;
const int N=10300;
int inf=-10020;
int dp[N][N];
int mp[N][N];
int n,m;
int sum;
struct str{
	int x;
	int y;
};
str a,b,c,d;
bool vis[N][N];
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>mp[i][j];
		}
	}
	for(int i=0;i<=n;i++){
		mp[i][0]=inf;
	}
	for(int i=0;i<=m;i++){
		mp[0][i]=inf;
	}
    a.x=1;
	a.y=1;
	vis[1][1]=0;
	sum+=mp[1][1];
	while(a.x==n&&a.y==m){
		b.x=a.x+1;
		c.y=a.y+1;
		d.x=a.x-1;
		if(vis[b.x][b.y]){
			int maxn=max(mp[c.x][c.y],mp[d.x][d.y]);
			if(maxn==mp[c.x][c.y]){
		   	sum+=mp[c.x][c.y];
			a.y=c.y;
				vis[c.x][c.y]=1;
		    }else{
			sum+=mp[d.x][d.y];
			a.x=d.x;
				vis[d.x][d.y]=1;
		    }
			continue;
		}else if(vis[c.x][c.y]){
			int maxn=max(mp[b.x][b.y],mp[d.x][d.y]);
			if(maxn==mp[b.x][b.y]){
		   	sum+=mp[b.x][b.y];
			a.y=b.y;
				vis[b.x][b.y]=1;
		    }else{
			sum+=mp[d.x][d.y];
			a.x=d.x;
				vis[d.x][d.y]=1;
		    }
			continue;
		}
		if(vis[d.x][d.y]){
			int maxn=max(mp[b.x][b.y],mp[c.x][c.y]);
			if(maxn==mp[b.x][b.y]){
		   	sum+=mp[b.x][b.y];
			a.y=b.y;
				vis[b.x][b.y]=1;
		    }else{
			sum+=mp[c.x][c.y];
			a.x=c.x;
				vis[c.x][c.y]=1;
		    }
			continue;
		}
		int maxn=max(mp[b.x][b.y],max(mp[c.x][c.y],mp[d.x][d.y]));
		if(maxn==mp[b.x][b.y]){
			sum+=mp[b.x][b.y];
			a.x=b.x;
			vis[b.x][b.y]=1;
		}else if(maxn==mp[c.x][c.y]){
		   	sum+=mp[c.x][c.y];
			a.y=c.y;
			vis[c.x][c.y]=1;
		}else{
			sum+=mp[d.x][d.y];
			a.x=d.x;
			vis[d.x][d.y]=1;
		}
	}
	cout<<sum;
	return 0;
}