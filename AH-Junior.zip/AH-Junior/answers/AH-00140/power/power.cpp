#include<bits/stdc++.h>
using namespace std;
const int N=100000;
int n1;
int ans[N];
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n1;
	int n=n1;
	if(n%2!=0){
		cout<<-1;
		return 0;
	}
	int i=1;
	int j=0;
	int sum;
	while(n>0){//6
		sum=0;
		i=1;
		for(i=1;sum<=n;i++){
			sum=pow(2,i);
		}
		i-=2;
		ans[j++]=pow(2,i);
		n-=pow(2,i);
	}
	if(n==0){
		for(int k=0;k<j;k++){
			cout<<ans[k]<<" ";
		}
	}else{
	    cout<<"-1";
	}
	return 0;
}