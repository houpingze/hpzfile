#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
    string a;
	cin>>a;
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++){
	    cin>>a[i];	
	}
	for(int i=0;i<n;i++){
	    cout<<0;
	}
	return 0;
}
