#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("number","r",stdin);
	freopen("number","w",stdout);
	cout<<9;
	return 0;
	fclose(stdin);
	fclose(stdout);
}