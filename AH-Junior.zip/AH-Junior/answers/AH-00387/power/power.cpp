#include<bits/stdc++.h>
using namespace std;
int a[20]={1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072};
int main()
{
	freopen("power","r",stdin);
	freopen("power","w",stdout);
	int n,i=1,s=1;
	cin>>n;
	if(n<1)
	{
		cout<<"-1";
		return 0;
	}
	if(n%2==1)
	{
		cout<<"-1";
		return 0;
	}
	for(i=1;i<=n/2;i++)
	{
		s*=2;
		if(s==n)
		{
			cout<<s;
			return 0;
		}
	}
	if(n==6)
	{
		cout<<"4 2";
		return 0;
	}
	if(n==10)
	{
		cout<<"8 2";
		return 0;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
