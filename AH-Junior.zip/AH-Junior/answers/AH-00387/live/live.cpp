#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("live","r",stdin);
	freopen("live","w",stdout);
	int n,i,j,sum,y;
	float s,w;
	cin>>n>>w;
	int a[n+1],b[n+1+1];
	for(i=1;i<=n;i++)
		cin>>a[i];
	for(i=1;i<=n+1;i++)
		b[i]=0;
	for(i=1;i<=n;i++)
	{
		b[i]=a[i];
		for(int q=1;q<=i;q++)
		{
			for(int o=1;o<=i;o++)
			{
				if(b[o]<b[o+1])
					swap(b[o],b[o+1]);
			}
		}
		s=w/100;
		if(1>i*s)
			sum=1;
		if(i*s>1)
			sum=i*s;
		for(j=1;j<=sum;j++)
		{
			if(i==n&&j==sum)    cout<<b[j];
			else
			    if(j==sum) cout<<b[j]<<" ";
		}
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
