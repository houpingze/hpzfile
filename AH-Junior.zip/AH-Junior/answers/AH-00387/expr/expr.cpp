#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr","r",stdin);
	freopen("expr","w",stdout);
	cout<<"1"<<endl<<"1"<<endl<<"0";
	return 0;
	fclose(stdin);
	fclose(stdout);
}