#include<iostream>
#include<cstdio>
using namespace std;
long long n;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>m;
		if(n%1==1);
			cout<<"1";
			if(n%2==0);
				cout<<"2";
				if(n%3==0);
					cout<<"3";
					if(n%4==0);
						cout<<"4";
						if(n%5==0);
							cout<<"5";
	fclose(stdin);
	fclose(stdout);
}