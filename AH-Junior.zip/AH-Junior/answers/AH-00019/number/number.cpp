#include <iostream>
#include <cstdio>
#include <memory.h>
using namespace std;
const int N = 1005;
int n, m, a[N][N], f[N][N];
long long ans;
int main()
{
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);
	cin >> n >> m;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
		{
			scanf("%d", &a[i][j]);
			ans += a[i][j];
		}
	cout << ans << endl;
	/*
	for(int i = 1; i <= n; i++)
		f[i][1] = f[i - 1][1] + a[i][1];
	for(int j = 2; j <= m; j++)
		for(int i = 1; i <= n; i++)
			ans += f[i][j];
			f[i][j] = max(max(f[i][j], f[i-1][j] + a[i][j]), max(f[i-1][j+1]+a[i][j+1]+a[i][j], f[i-1][j-1]+a[i][j-1]+a[i][j]));
			
		
			/*{
				if(f[i][j] + a[i - 1][j] > f[i - 1][j] /*&& q[i][j] != i * m + j - m - m/)
					f[i - 1][j] = f[i][j] + a[i - 1][j], q[i - 1][j] = i * m + j - m;
				
				if(f[i][j] + a[i + 1][j] > f[i + 1][j] /&& q[i][j] != i * m + j)
					f[i + 1][j] = f[i][j] + a[i + 1][j], q[i + 1][j] = i * m + j - m;
				
				if(f[i][j] + a[i][j + 1] > f[i][j + 1])
				{
					f[i][j + 1] = f[i][j] + a[i][j + 1];
					if(i == 1 && j == 2) cerr << "( " << f[i][j] << ' ' << a[i][j + 1] << ") "; 
					q[i][j + 1] = i * m + j - m;
				}
				
			/	f[i + 1][j] = max(f[i + 1][j], f[i][j] + a[i + 1][j]);
			/	f[i][j + 1] = max(f[i][j + 1], f[i][j] + a[i][j + 1]);
			}
		for(int i = 1; i <= n; i++)
			if(f[i][j] + a[i][j + 1] > f[i][j + 1])
				{
					f[i][j + 1] = f[i][j] + a[i][j + 1];
					if(i == 1 && j == 2) cerr << "( " << f[i][j] << ' ' << a[i][j + 1] << ") "; 
					q[i][j + 1] = i * m + j - m;
				}
	cout << f[n][m];*/
	return 0;
}

