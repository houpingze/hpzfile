#include <iostream>
#include <cstdio>
#include <string>
#include <stack>
using namespace std;
string s, sears;
const int N = 100005;
int n, T, v, x[N], ans[N];
stack<bool> sta;
int main()
{
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	getline(cin, s);
	cin >> n;
	for(int i = 1; i <= n; i++) cin >> x[i];		
	cin >> T;
	while(T--)
	{
		cin >> v;   x[v] = 1 - x[v];
		for(int i = 0; i < s.length(); i++)
		{
			if(s[i] == '&') {
				bool x1 = sta.top();  sta.pop();
				bool x2 = sta.top();  sta.pop();
				sta.push(x1 && x2);
			}
			if(s[i] == '|')	{
				bool x1 = sta.top();  sta.pop();
				bool x2 = sta.top();  sta.pop();
				sta.push(x1 || x2);
			}
			if(s[i] == '!')
			{
				bool x2 = sta.top();  sta.pop();
				sta.push(!x2);
			}
			if(s[i] == 'x')
			{
				int res = 0;
				while(s[++i] >= '0' && s[i] <= '9') res = res * 10 + s[i] - '0';
				sta.push(x[res]);
			}
		}
		x[v] = 1 - x[v];
		cout << sta.top() << endl; sta.pop();
	}
	return 0;
}

//password : Ta&Shan?Zhi@Shi%