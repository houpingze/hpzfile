#include <iostream>
#include <cstdio>
using namespace std;
long long int n, now, k, ans[50];
int main()
{
	freopen("power.in", "r", stdin);
	freopen("power.out", "w", stdout);
	cin >> n;
	if(n % 2 != 0) cout << -1;
		else {
			now = 0; k = 1;
			while(n) {
				if(n % 2) ans[++now] = k;
				k = k * 2; n >>= 1;
			}
			for(int i = now; i; i--)
				cout << ans[i] << ' ';
		}
	return 0;
}