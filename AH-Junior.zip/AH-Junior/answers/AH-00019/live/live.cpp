#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
const int N = 100005;
int n, pct, x, wnn, ansp, a[N];
vector<int> v;
int main()
{
	freopen("live.in", "r", stdin);
	freopen("live.out", "w", stdout);
	cin >> n >> pct;
	for(int i = 1; i <= n; i++) 
	{
		cin >> x;
		int l = 0, r = i - 1;
		while(l < r)
		{
			int mid = (l + r) >> 1;
			if(v[mid] < x) r = mid;
				else l = mid + 1;
		}
		v.insert(v.begin() + l, x);
		wnn = max(1, i * pct / 100);
		cout << v[wnn - 1] << ' ';
	}
	return 0;
}