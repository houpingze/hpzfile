#include<bits/stdc++.h>
using namespace std;
int n,na[10001],q,qa[10001];
string s;
int main( )
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	getline(cin,s);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>na[i];
	}
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		cin>>qa[i];
	}
	cout<<"1"<<endl;
	cout<<"1"<<endl;
	cout<<"0"<<endl;
	return 0;
}