#include<bits/stdc++.h>
using namespace std;
int n,m,a[101][101],sum,x1=1,x2=1;
bool b[101][101];
int main( )
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];		
		}
	}
	sum=a[1][1];
	b[x1][x2]=false;
	while(x1==n&&x2==m)
	{
		if(a[x1-1][x2]>a[x1][x2+1]&&a[x1-1][x2]>a[x1+1][x2]&&b[x1-1][x2]!=false)
		{
			x1=x1-1;
			sum=sum+a[x1][x2];
			b[x1][x2]=false;
		}
		else if(a[x1-1][x2]<a[x1][x2+1]&&a[x1+1][x2]<a[x1][x2+1]&&b[x1][x2+1]!=false)
		{
			x2=x2+1;
			sum=sum+a[x1][x2];
			b[x1][x2]=false;
		}
		else if(a[x1+1][x2]>a[x1-1][x2]&&a[x1+1][x2]>a[x1][x2+1]&&b[x1+1][x2]!=false)
		{
			x1=x1+1;
			sum=sum+a[x1][x2];
			b[x1][x2]=false;
		}
	}
	cout<<sum;
	return 0;
}