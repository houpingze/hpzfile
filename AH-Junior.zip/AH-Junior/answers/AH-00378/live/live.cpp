#include<bits/stdc++.h>
using namespace std;
int n,w,a[20001],s;
int main( )
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	s=w/n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	for(int i=s;i>=1;i--)
	{
		cout<<a[i]<<" ";
	}
	return 0;
}