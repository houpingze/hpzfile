#include<bits/stdc++.h>
using namespace std;
int n,sum[20001],l=0;
bool re=false;
int main( )
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	for(int i=1;i*i<=n;i++)
	{
		if(pow(2,i)<n)
		{
			re=true;
			sum[i]=pow(2,i);
			l++;
		}
		else if(pow(2,i)>=n)
		{
			break;
		}
	}
	if(re==false)
	{
		cout<<"-1";
		return 0;
	}
	for(int i=l;i>=1;i--)
	{
		cout<<sum[i]<<" ";
	}
	return 0;
}