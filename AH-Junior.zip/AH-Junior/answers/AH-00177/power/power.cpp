#include<bits/stdc++.h>
using namespace std;
long long n;
long long s[28]={2};
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2==1){cout<<-1;return 0;}
	for(int i=1;i<=27;i++){
		s[i]=s[i-1]*2;
	}
	for(int i=27;i>=0;i--){
		if(s[i]>n)continue;
			else if(s[i]<=n){
				n=n-s[i];
				cout<<s[i]<<' ';
			}
			if(n==0)return 0;
	}
		return 0;
}
