#include<bits/stdc++.h>
using namespace std;

int n;
float w;
int a[100010],b[100010];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sort(a,a+i+1);
		int k=i*w/100;
		int s=max(1,k);
		b[i]=a[i-s+1];
	}
	for(int i=1;i<=n;i++)cout<<b[i]<<' ';
	return 0;
}
