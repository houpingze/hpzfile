#include<bits/stdc++.h>
using namespace std;
int a[100001];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	queue<char> l;
	string s;
	getline(cin,s);
	int n,q,m;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>q;
	for(int j=1;j<=q;j++)
	    cin>>m;
    if(s=="x1 x2 & x3 |")	
		cout<<"1"<<endl<<"1"<<endl<<"0";
	if(s=="x1 ! x2 x4 | x3 x5 ! & & ! &")
	    cout<<"0"<<endl<<"1"<<endl<<"1";
	return 0;
}