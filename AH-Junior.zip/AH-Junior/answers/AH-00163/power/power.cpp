#include<bits/stdc++.h>
using namespace std;
int a[101];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long n,sum=0,i=2;
	int ans=1;
	scanf("%lld",&n);
	if(n%2!=0){
		cout<<"-1";
		return 0;
	}
	while(1){
		if(sum==n){
			break;
		}
		if(sum>n){
			cout<<"-1";
			return 0;
		}
		sum+=i;
		a[ans]=i;
		i*=2;
		ans++;
	}
	for(int j=ans-1;j>=1;j--)
		cout<<a[j]<<' ';
    return 0;
}