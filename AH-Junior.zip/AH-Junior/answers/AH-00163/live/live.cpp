#include<bits/stdc++.h>
using namespace std;
int a[100001],b[100001];
int main() 
{
	 freopen("live.in","r",stdin);
	 freopen("live.out","w",stdout);
     int n,w,j;
	 scanf("%d%d",&n,&w);
	 for(int i=1;i<=n;i++)
		 scanf("%d",&a[i]);
	 for(j=1;j<=n;j++){
		 for(int k=1;k<=j;k++)
			 b[k]=a[k];
		 sort(b+1,b+1+j);
		 int q;
		 q=floor(j*w/100);
		 if(q==0) q=1;
		 cout<<b[j-q+1]<<" ";
	 }
	 return 0;
}