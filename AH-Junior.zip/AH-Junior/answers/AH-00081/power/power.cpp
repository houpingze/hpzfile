#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,k=1;
	cin>>n;
	if(n%2==1) 
	{
		cout<<-1;
		exit(0);
	}
	else if(n==2)
	{
		cout<<2;
		exit(0);
	}
	else if(n==4)
	{
		cout<<4;
		exit(0);
	}
	else if(n==6)
	{
		cout<<"4 2";
		exit(0);
	}
	else if(n==8)
	{
		cout<<8;
		exit(0);
	}
	else if(n==10)
	{
		cout<<"8 2";
		exit(0);
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			k*=2;
			if(n==k)
			{
				cout<<n;
				exit(0);
			}
		}
	}
	cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}