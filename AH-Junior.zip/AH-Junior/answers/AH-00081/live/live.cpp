#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,a[100001],k;
	double p,x;
	cin>>n>>x;
	x/=100;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		sort(a+1,a+i+1);
		p=i*x;
		k=floor(p);
		if(k==0) cout<<a[i]<<" ";
		else cout<<a[i-k+1]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}