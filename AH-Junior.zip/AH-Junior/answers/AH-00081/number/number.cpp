#include<bits/stdc++.h>
using namespace std;
int n,m,maxn=-100000000,maxm=-100000000,s=0;
int p[3][2]={0,1,1,0,-1,0},a[1001][1001],tx,ty,book[1001][1001];
int num(int nx,int ny)
{
	if(nx==n&&ny==m)
	{
		maxm=s;
		return 0;
	}
	for(int i=0;i<=2;i++)
	{
		nx+=p[i][1];
		ny+=p[i][2];
		if(book[nx][ny]==0&&1<=nx&&nx<=n&&1<=ny&&ny<=m&&a[nx][ny]>maxn)
		{
			tx=nx;
			ty=ny;
			maxn=a[nx][ny];
		}
		else
		{
			nx-=p[i][1];
		    ny-=p[i][2];
		}
	}
	s+=maxn;
	num(tx,ty);
}
int main()
{
	//freopen("number.in","r",stdin);
	//freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
	num(1,1);
	cout<<maxm;
	//fclose(stdin);
	//fclose(stdout);
}