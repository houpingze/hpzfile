#include<bits/stdc++.h>
using namespace std;
int main()
{
	ifstream fin("power.in");
	ofstream fout("power.out");
	long long n,a[1000001];
	int i,k=1;
	fin>>n;
	if(n%2!=0)
	{
		fout<<-1;
		return 0;
	}
	long long t=n/2;
	for(i=1;i<=t;i*=2)
	{
		if((t-i)>=(i*2))
		{
			a[k]=i*2;
			k++;
			t-=i;
		}
		else
		{	
			if(t%2==0)
			{
				a[k]=t*2;
				break;
			}
			else
			{
				fout<<-1;
				return 0;
			}
		}
	}
	for(i=k;i>=1;i--)
		fout<<a[i]<<" ";
	fin.close();
	fout.close();
	return 0;
}