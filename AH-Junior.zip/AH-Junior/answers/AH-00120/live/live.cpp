#include<bits/stdc++.h>
using namespace std;
int max(int a,int b)
{
	if(a>b)
		return a;
	else 
		return b;
}
bool cnt(int a,int b)
{
	return a>b;
}
int main()
{
	ifstream fin("live.in");
	ofstream fout("live.out");
	int n,i,j,a[100001],b[100001];
	double m;
	fin>>n>>m;
	for(i=1;i<=n;i++)
		fin>>a[i];
	for(i=1;i<=n;i++)
	{
		b[i]=max(1,int(i*(m/100)));
	}
	for(i=1;i<=n;i++)
	{
		sort(a+1,a+i+1,cnt);
		fout<<a[b[i]]<<" ";
	}
	fin.close();
	fout.close();
	return 0;
}