#include<bits/stdc++.h>
using namespace std;
int a[3]={+1,-1,1},b[3]={+1,1,1};
 int dfs(int n,int m,int x)
{
	if(n&&m&&a[1]&&b[1]==0)
		return 0;
	
}
int main()
{
	ifstream fin("power.in");
	ofstream fout("power.out");
	int i,j,a[1001][1001],b[1001][1001],n,m,s;
	fin>>n>>m;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
				fin>>a[i][j];
	dfs(n,m,3);
	fin.close();
	fout.close();
	return 0;
}
