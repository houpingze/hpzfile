#include<bits/stdc++.h>
using namespace std;
int main()
{
	ifstream fin("expr.in");
	ofstream fout("expr.out");
	
	fin.close();
	fout.close();
	return 0;
}