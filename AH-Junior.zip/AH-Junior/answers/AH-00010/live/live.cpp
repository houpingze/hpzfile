#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	long long n;
	int w,a[100001];
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}	
	for(int i=1;i<=n;i++){
		sort(a+1,a+i+1);
		int x=floor(i*w*1.0/100);
		int s=max(1,x);
		    cout<<a[i+1-s]<<" ";
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}