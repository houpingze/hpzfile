#include <bits/stdc++.h>
using namespace std;
int a[3]={}
struct f{
    int x[100];
	bool t=0;
};
int 
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	f a[100];
	cin>>n>>m;
	for(int i=1;i<=n;i++){
	    for(int i=1;i<=m;i++){
		    cin>>a[i].x[j];
			
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}