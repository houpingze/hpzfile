#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
using namespace std;
bool a[11];
int main()
{
	//freopen("expr.in","r",stdin);
	//freopen("expr.out","w",stdout);
	int n,c,i;
	scanf("%d",&n);
	c=n,i=1;
	while(c!=0)
	{
		a[i]=c%2;
		c/=2;
		i++;
	}
	for(int m=i-1;m>=1;m--)
	printf("%d\n",a[m]);
	printf("\n");
	//fclose(stdin);fclose(stdout);
	return 0;
}