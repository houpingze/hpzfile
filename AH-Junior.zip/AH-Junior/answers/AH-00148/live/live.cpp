#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
using namespace std;
int n[100001],l=0;
void cr(int x,int y)
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	for(int a=l-1;a>x;a--)
	n[a+1]=n[a];
	n[x]=y;
	printf("2\n");
}
void d(int x)
{
	l++;
	if(l==1)
	{
		a[1]=x;
		return;
	}
	int c=1,r=l;
	int mid=(c+r)/2;
	if(x>=n[mid])
	for(int a=1;a<=mid;a++)
	{
		if(x==n[a]);
		cr(a+1,x);
		if(x>n[a]&&<n[a-1]);
		cr(a+1,x);	
	}
		if(x>n[mid]);
		for(int a=0;a<=x;a++)
		{
			if(x>n[mid]);
			for(int a=mid+1;a<=c;a++)
			{
				if(x==n[i]);
				cr(a+1,x);
				if(x>n[a]&&<n[a+1]);
			}
		}
}
	fclose(stdin);fclose(stdout);
	return;
