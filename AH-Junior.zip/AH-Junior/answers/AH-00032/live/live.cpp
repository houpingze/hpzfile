#include<bits/stdc++.h>
using namespace std;
const int N=100001;
int n,w,a[N];
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sort(a+1,a+i+1,cmp);
		int x=i*w/100;
		int o=max(1,x);
		cout<<a[o]<<" ";
	}
	return 0;
}