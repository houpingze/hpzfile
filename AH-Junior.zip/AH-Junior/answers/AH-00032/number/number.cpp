#include<bits/stdc++.h>
using namespace std;
const int N=1005;
int n,m;
long long a[N][N],dp[N][N],sum;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
		}
	}
	dp[1][1]=a[1][1];
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			long long x=max(a[i-1][j],a[i+1][j]);
			dp[i][j]=a[i][j]+max(x,a[i][j-1]);
		}
	}
	for(int i=1;i<=n;i++){
		sum+=dp[i][m];
	}
	for(int i=1;i<=m;i++){
		sum+=dp[n][i];
	}
	cout<<sum;
	return 0;
}