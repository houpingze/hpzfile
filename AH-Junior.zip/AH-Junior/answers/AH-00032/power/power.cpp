#include<bits/stdc++.h>
using namespace std;
const int N=1000001;
int a[N];
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int  n,k=1,o=0;
	cin>>n;
	if(n%2!=0){
		cout<<"-1"<<endl;
		return 0;
	}
	int s=n;
	s-=2;
	while(n){
		if(s<=0){
			k=0;
			break;
		}
		int p=s,f=0;
		while(p!=1){
			p/=2;
			if(p==1){
				f=1;
				break;
			}
			if(p!=1 && p%2!=0){
			    break;
			}
		}
		if(f==1 && n-s>=0){
			o++;
			a[o]=s;
			n-=s;
		}
		s-=2;
	}
	if(k==1){
		for(int i=1;i<=o;i++){
			cout<<a[i]<<" ";
		} 
		cout<<endl;
	}else{
		cout<<"-1"<<endl;
	}
	return 0;
}