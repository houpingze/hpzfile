#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	getline(cin,s);
	int n,q;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>q;
	while(q--){
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}