#include <bits/stdc++.h>
using namespace std;
int n,isi,isj,is;
int check(int a,int b){
	if(a&1||b&1) return 0;
	while(a%2==0){
		a/=2;
	}
	while(b%2==0)
		b/=2;
	if(a==1&&b==1) return 1;
	return 0;
}
int ok(int a){
	if(a&1) return 0;
	while(a%2==0){
		a/=2;
	}
	if(a==1) return 1;
	return 0;
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n&1||n<=0||ok(n)){
		cout<<-1;
		fclose(stdin);
	    fclose(stdout);
		return 0;
	}
	for(int i=2;i<n;i+=2)
		if(check(i,n-i)){
			is=1;
			if(i>n-i){isi=n-i; isj=i;}
			else {isi=i; isj=n-i;}
			break;
		}	
	if(is==1) cout<<isj<<" "<<isi;
		else cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}