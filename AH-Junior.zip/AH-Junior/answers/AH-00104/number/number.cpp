#include <bits/stdc++.h>
using namespace std;
int n,m,dis[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int a[1001][1001],is[1001][1001];
long long dp[1001][1001];
inline bool ok(int a,int b){
	return !is[a][b]&&a>=1&&a<=n&&b>=1&&b<=m;
}
void dfs(int x,int y){
	is[x][y]=1;
	if(x==n&&y==m) return;
	for(int i=0;i<4;i++){
		long long sum=dp[x][y];
		int dx=x+dis[i][0];
		int dy=y+dis[i][1];
		if(ok(dx,dy)){
			dfs(dx,dy);
			sum+=a[dx][dy];
		}
		dp[dx][dy]+=sum;
	}
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
			dp[i][j]+=a[i][j];
		}
	if(n==1&&m==1) {
		cout<<a[1][1];
		fclose(stdin);
	    fclose(stdout);
	   return 0;
	}
	else if(n==2&&m==1) {
		cout<<a[1][1]+a[2][1];
		fclose(stdin);
	    fclose(stdout);
	   return 0;
	}
	else if(n==1&&m==2) {
		cout<<a[1][1]+a[1][2];
		fclose(stdin);
	    fclose(stdout);
	   return 0;
	}
	dfs(1,1);
	cout<<dp[n][m];
	fclose(stdin);
	fclose(stdout);
	return 0;
}