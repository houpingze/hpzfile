#include <bits/stdc++.h>
using namespace std;
int a[100010];
bool cmp(const int &a,const int &b){
	return a>b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,sum,w;
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(1>=i*w*1.0/100) sum=1;
		else sum=i*w*1.0/100;
		sort(a+1,a+i+1,cmp);
		cout<<a[sum]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}