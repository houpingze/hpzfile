#include<iostream>
#include<fstream>
using namespace std;
int b[10001]={0,2,4,8,16,32,64,128,256,512,1024,2048,4096};
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	if(n%2!=0)
	{
		cout<<-1;
		return 0;
		}
		for(int o=1;o<=12;o++)
			if(n==b[o])
			{
				cout<<n;
				return 0;
				}
	if(n==1||n==2||n==3||n==4||n==5||n==7||n==8||n==9)
	{
		cout<<-1;
		return 0;
		}
	if(n==6)
	{
		cout<<4<<' '<<2;
		return 0;
		}
	if(n==10)
	{
		cout<<8<<' '<<2;
		return 0;
		}
	
	return 0;
}
