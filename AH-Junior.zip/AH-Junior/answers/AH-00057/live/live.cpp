#include<iostream>
#include<cmath>
#include<bits/stdc++.h>
#include<fstream>
using namespace std;
int a[10001];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w;
	cin>>n>>w;
	int dq;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		if(i==1)cout<<a[1];
			else
			{
				dq=i*w/100;
				cout<<dq;
				}
		}
	return 0;
	}
