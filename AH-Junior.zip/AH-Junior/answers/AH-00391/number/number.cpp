#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int n,m,a[1010][1010],MAX=-12345,x=1,y=1,xd,yd,sum=0;
bool b[1010][1010];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	sum=a[1][1];
	b[1][1]=1;
	for(int i=1;;i++)
	{
		if(x==m&&y==n)
		{
			cout<<sum;
			break;
		}
		MAX=-12345;
		if(y>1&&a[y-1][x]>=MAX&&b[y-1][x]!=1)
		{
			xd=0;
			yd=-1;
			MAX=a[y-1][x];
		}
		if(y<n&&a[y+1][x]>=MAX&&b[y+1][x]!=1)
		{
			xd=0;
			yd=1;
			MAX=a[y+1][x];
		}
		if(x<m&&a[y][x+1]>=MAX&&b[y][x+1]!=1)
		{
			xd=1;
			yd=0;
			MAX=a[y][x+1];
		}
		if((b[y-1][x]==1||y<=1)&&(b[y+1][x]==1||y>=n)&&(b[y][x+1]==1||x>=m))
		{
			sum-=a[y][x];
			b[y][x]=1;
			x-=xd;
			y-=yd;
		}
		x+=xd;
		y+=yd;
		sum+=a[y][x];
		b[y][x]=1;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}