#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a,s[1234],ljq=1;
void powor(int i,int c)
{
	int S=i;
	for(int o=c;o>=2;o/=2)
	{
		
		if(i>=o)
		{
			i-=o;
			s[ljq]=o;
			ljq++;
		}
		if(i==0)
			break;
	}
}
int main()
{
	freopen("powor.in","r",stdin);
	freopen("powor.out","w",stdout);
	int i=1;
	cin>>a;
	if(a%2!=0||a==0)
		cout<<-1;
	else
	{
		for(i=1;;i*=2)
		{
			if(i>a)
			{	
				i/=2;
				break;
			}
		}
		powor(a,i);
		for(int o=1;o<=ljq-1;o++)
			cout<<s[o]<<' ';
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}