#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int  x;
int n,ans;
int a[120000];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);	
	cin>>n>>x;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		sort(a+1,a+i+1);
		ans=max(1,i*x/100);
		cout<<a[i-ans+1]<<' ';
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}