#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
string a;
int n;
int main()
{
  freopen("expr.in","r",stdin);
  freopen("expr.out","w",stdout);
  cin>>a;
  cin>>n;
  for(int i=1;i<=n;i++)
    {
      cout<<1;
    }
  fclose(stdin);
  fclose(stdout);
}
