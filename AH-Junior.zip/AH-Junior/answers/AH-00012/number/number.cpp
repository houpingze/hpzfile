#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
using namespace std;
int a[1001][1001];
long long f[4][1001][1001];
bool bb[4][1001][1001];
bool book[1001][1001];
int z[4][2]={{0,1},{1,0},{-1,0}};
int n,m;
long long dfs(int x,int y,int k)
{
	if(bb[k][x][y]!=0) return f[k][x][y];
	for(int i=0;i<3;++i)
	{
		int x1=x+z[i][0],y1=y+z[i][1];
		if(x1<1||x1>n||y1<1||y1>m||book[x1][y1]) continue;
		book[x1][y1]=1;
		long long t=dfs(x1,y1,i);
		f[k][x][y]=max(f[k][x][y],t);
		book[x1][y1]=0;
	}
	bb[k][x][y]=1;
	f[k][x][y]+=a[x][y];
	return f[k][x][y];
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	memset(f,128,sizeof(f));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j) scanf("%d",&a[i][j]);
	f[0][n][m]=f[1][n][m]=a[n][m];bb[0][n][m]=bb[1][n][m]=1;
	printf("%lld",dfs(1,1,0));
	return 0;
}