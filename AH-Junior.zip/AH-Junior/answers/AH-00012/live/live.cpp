#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;
int n,m;
int k[1001];
int a;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i) 
	{
		scanf("%d",&a);
		++k[a];
		int t=(i*m)/100.0;t=max(1,t);
		int num=0,o,q=1;
		for(o=600;o>=0;--o)
		{
			if(k[o]!=0)
			{
				num+=k[o];
				q=o;
				if(num>=t) break;
			}
		}
		printf("%d ",q);
	}
	return 0;
}