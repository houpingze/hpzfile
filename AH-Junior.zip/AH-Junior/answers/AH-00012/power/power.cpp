#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;
int n;
int f[101];
int a[101];
bool ok=0;
void print(int m)
{
	for(int i=1;i<=m;++i)
	{
		printf("%d ",f[a[i]]);
	}
}
void k(int t,int step,int s)
{
	if(ok==1) return;
	if(t==0)
	{
		ok=1;
		print(step-1);
	}
	if(t==1) return;
	for(int i=s-1;i>=1;--i)
	{
		if(f[i]>t) continue;
		a[step]=i;
		 k(t-f[i],step+1,i);
	}
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int num=1,p=1;
	scanf("%d",&n);
	for(p=1;p<=30;++p)
	{
		num*=2;
		f[p]=num;
		if(f[p]>n) break;
	}
	if(n%2!=0) printf("-1");
	else
	{
		k(n,1,p);
		if(ok==0) printf("-1");
	}
	return 0;
}