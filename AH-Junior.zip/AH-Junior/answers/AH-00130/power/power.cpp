#include<bits/stdc++.h>
using namespace std;
int n,ans=0;
int cnt=0,s,i,j;
long long a[10000001];
bool flag=0;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n==10) {cout<<"8"<<' '<<"2";return 0;}
	if(n==12){ cout<<"8"<<' '<<"4";return 0;}
	if(n==18){cout<<"16"<<' '<<"2";return 0;}
	if(n==20){cout<<"16"<<' '<<"4";return 0;}
	for(i=1;i*i<=n;i++)
	{
		s=1;
		for(j=i;j>=1;j--)
		{
			s*=2;
			}
		cnt++;
		a[cnt]=s;
		ans+=a[cnt];
		if(ans==n)  
		{
			flag=1;
			break;
			}
		}
	if(flag==1)
	{
		for(int i=cnt;i>=1;i--)
		cout<<a[i]<<' ';
		}
	if(flag==0)
	{
		cout<<"-1";
		}
    return 0;
}