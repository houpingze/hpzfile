#include<bits/stdc++.h>
using namespace std;
int n,m,c;
long long a[100001];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int j=1;j<=n;j++)
	{
		int s=1;
		s=j*m/100;
		if(s==0)
		{
			cout<<a[j]<<' ';
			}
		else
		{
			for(int k=1;k<=j;k++) 
		{
			for(int l=k+1;l<=j;l++)
			{
				if(a[k]<a[l])
				{
					int t=a[k];
					a[k]=a[l];
					a[l]=t;
					}
				}
			}
		cout<<a[s]<<' ';
		}
	}
	return 0;
	}