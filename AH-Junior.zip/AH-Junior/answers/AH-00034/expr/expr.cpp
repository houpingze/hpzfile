#include <cstdio>
#include <bitset>
int n,q, flagn, t;
bool And=false,Or=false, flagb;
bool x[1002];
char s[1000002];

int main()
{
	freopen ("expr.in","r",stdin);
	freopen("expr.out","w", stdout);
	gets(s);
	for (int i=0; s[i]!='\0'; ++i)
		if (s[i]=='&')
			And = true;
		else if (s[i]=='|')
			Or = true;
	scanf ("%d", &n);
	for (int i=1; i<=n; ++i)
		scanf("%d", &t), x[i]=t;
	scanf("%d", &q);
	if (And && !Or)
	{
		for (int i=1; i<=n; ++i)
			if (!x[i]){
				if (flagb){
					flagn=0;
					break;
				}
				flagn=i;
			}
		if (flagn){
			while (q--){
				scanf("%d", &t);
				printf("%d\n", t==flagn);
			}
		}
		else{
			while (q--)
				printf("0\n");
		}
	}
	else if (Or && !And)
	{
		for (int i=1; i<=n; ++i)
			if (x[i]){
				if (flagb){
					flagn=0;
					break;
				}
				flagn=i;
			}
		if (flagn){
			while (q--){
				scanf("%d", &t);
				printf("%d\n", t!=flagn);
			}
		}
		else{
			while (q--)
				printf("1\n");
		}
	}
	fclose(stdin);
	fclose(stdout);
}