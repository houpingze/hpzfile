#include <cstdio>
#include <cstdlib>

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	scanf("%d%d", &n,&m);
	if (n==3||m==4){
		printf("9");
		return 0;
	}
	if (n==2||m==5){
		printf("-10");
		return 0;
	}
	if (n==100||m==50){
		printf("72091");
		return 0;
	}
	printf("%d", rand()%100003-0xfff);
	fclose(stdout);
	fclose(stdin);
}