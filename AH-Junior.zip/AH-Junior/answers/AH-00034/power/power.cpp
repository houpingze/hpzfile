#include <iostream>
#include <cstdio>
int main()
{
    freopen("power.in","r",stdin);
    freopen("power.out","w",stdout);
    unsigned long n, base=0x40000000;
    std::cin>>n;
    if (n&1){
        std::cout << "-1" << std::flush;
        return 0;
    }
    while (base){
        if (n&base)
            std::cout << base <<' ';
        base >>= 1;
    }
	fclose(stdin);
	fclose(stdout);
    return 0;
}
