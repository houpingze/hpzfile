#include <cstdio>
#include <algorithm>

void read(int &n)
{
	static char c;
	while(c=getchar(), c<'0'||c>'9');
	n=c-'0';
	while(c=getchar(), '0'<=c&&c<='9')
		n = n*10 + (c-'0');
}

int n,w,p=0;
int scores[100002];
inline int max(const int &a, const int &b){
	return a>b?a:b;
}
bool cmp(const int &a, const int &b){
	return a>b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	read(n), read(w);
	for (int i=0; i<n; ++i){
		read(scores[i]);
		std::sort(scores, scores+i, cmp);
		printf("%d ", scores[max(1, int(i*w/100.0))-1]);
	}
	fclose(stdout);
	fclose(stdin);
}
