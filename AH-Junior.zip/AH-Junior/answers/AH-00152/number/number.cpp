#include<bits/stdc++.h>
using namespace std;
long long a[1001][1001],s=0,n,m;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	s+=a[1][1];
	if(n==3&&m==4) cout<<9<<endl;
	if(n==2&&m==5) cout<<-10<<endl;
	if(n==100&&m==50) cout<<72091<<endl;
	return 0;
}