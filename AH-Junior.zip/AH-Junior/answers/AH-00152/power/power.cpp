#include<bits/stdc++.h>
using namespace std;
long long a[1000001];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long n,s;
	cin>>n;
	if(n%2!=0) 
	{
		cout<<"-1"<<endl;
		return 0;
	}
	s=n/2-1;
	while(s!=0)
	{
		long long t=1,s1=n,k=0;
		bool pd=true;
		while(s1!=0)
		{
			a[k]=t*2;
			s1-=a[k];
			t=s1/2;
			k++;
		}

		for(int i=1;i<k;i++)
			if(a[i]==a[i-1])
			{
				pd=false;
				break;
			}
		if(pd)
		{
			for(int i=k-1;i>=0;i--)
			     cout<<a[i]<<" ";
		return 0;
		}
		s--;
	}
	cout<<"-1"<<endl;
	return 0;
}