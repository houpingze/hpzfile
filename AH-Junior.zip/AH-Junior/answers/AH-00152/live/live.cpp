#include<bits/stdc++.h>
using namespace std;
int a[100001];
bool cmp(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n;
	double w;
	cin>>n>>w;
	w=w*1.0/100;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		double x=i*1.0*w;
			long long v=x*10/10;
		if(i==1||v>i||v==0) cout<<a[i]<<" ";
			else
			{
				sort(a+1,a+1+i,cmp);
				cout<<a[v]<<" ";
			}
	}
	return 0;
}