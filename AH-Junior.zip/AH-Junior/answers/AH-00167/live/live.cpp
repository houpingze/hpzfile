#include<iostream>
#include<cstdio>
#include<fstream>
#include<algorithm>
using namespace std;
#define cin fin
#define cout fout
ifstream fin("live.in");
ofstream fout("live.out");
int n,f,w,a[1000005];
int main(){
	cin>>n>>w;
	for(int i=1;i<=n;++i){
		cin>>a[i];
		sort(a+1,a+i+1);
		f=max(1,(i*w)/100);
		cout<<a[i-f+1]<<" ";
	}
	return 0;
}