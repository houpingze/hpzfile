#include<iostream>
#include<cstdio>
#include<fstream>
using namespace std;
#define cin fin
#define cout fout
ifstream fin("expr.in");
ofstream fout("expr.out");
int main(){
	int a,c;
	string b,d,e;
	getline(cin,b);
	cin>>a;
	getline(cin,d);
	cin>>c;
	for(int i=0;i<c;++i){
		cin>>e[i];
		if(e[i]%9999==0)cout<<"1"<<endl;
		else cout<<"0"<<endl;
	}
	
	return 0;
}
