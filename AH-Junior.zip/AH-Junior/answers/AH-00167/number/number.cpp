#include<iostream>
#include<cstdio>
#include<fstream>
using namespace std;
#define cin fin
#define cout fout
ifstream fin("number.in");
ofstream fout("number.out");
int n,m,sum=-999999999,a[1005][1005],e[1005][1005];
bool d[1005][1005]={0};
int dfs(int c,int b,int ans){
	if(c==n&&b==m){
		if(ans>sum)sum=ans;
	}
	else{
		if(c-1>0&&d[c-1][b]==0)dfs(c-1,b,ans+=a[c][b]);
		if(c+1<n&&d[c+1][b]==0)dfs(c+1,b,ans+=a[c][b]);
		if(b+1<m&&d[c][b+1]==0)dfs(c,b+1,ans+=a[c][b]);
	}
}
int main(){
	cin>>n>>m;for(int i=1;i<=n;++i)for(int j=1;j<=m;++j){a[i][j]=-99999999;e[i][j]=-99999999;}
	for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)cin>>a[i][j];
	cout<<dfs(1,1,0);
	return 0;
}
