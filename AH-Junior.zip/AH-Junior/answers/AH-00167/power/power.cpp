#include<iostream>
#include<cstdio>
#include<fstream>
using namespace std;
#define cin fin
#define cout fout
ifstream fin("power.in");
ofstream fout("power.out");
int main(){
	int n,a[30]={1,0},b,c[30],k=0;
	cin>>n;
	if(n%2!=0){cout<<"-1"<<endl;return 0;}
	for(int i=1;i<30;++i){
		a[i]=a[i-1]*2;
		if(a[i]>=n){b=i;break;}
	}
	for(int i=b;i>0;--i){
		if(a[i]<=n){
			n-=a[i];
			c[k]=a[i];
			k++;
		}
	}
	for(int i=0;i<k;++i){cout<<c[i]<<" ";}
	return 0;
}