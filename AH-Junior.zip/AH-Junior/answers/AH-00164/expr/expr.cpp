#include <cstdio>
using namespace std;
int main ( ) {
	freopen ("expr.in", "r", stdin);
	freopen ("expr.our", "w", stdout);
	printf("1\n1\n0\n");
}