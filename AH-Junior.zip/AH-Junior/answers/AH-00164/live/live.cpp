#include <cstdio>
#include <algorithm>
using namespace std;
long long n, i, a[100005], b[100005];
int w, ans;
int max (int x, int y) {
	return x>y?x:y;
}
bool cmp (long long x, long long y) {
	return x>y;
}
int main ( ) {
	freopen ("live.in", "r", stdin);
	freopen ("live.out", "w", stdout);
	scanf ("%lld %d", &n, &w);
	for (i=1; i<=n; i++) scanf ("%lld", &a[i]);
	for (i=1; i<=n; i++) {
		b[i]=a[i];
		sort (b+1, b+1+i, cmp);
		ans=b[max(1, i*w/100)];
		printf ("%d ", ans);
	}
	return 0;
}