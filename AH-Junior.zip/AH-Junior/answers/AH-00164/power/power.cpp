#include <cstdio>
using namespace std;
long long n, i, a[10000005], b[10000005], s=0, l;
int main ( ) {
	freopen ("power.in", "r", stdin);
	freopen ("power.out", "w", stdout);
	int flag=0;
	scanf ("%lld", &n);
	if (n%2==1) {
		printf ("-1");
		return 0;
	}
	if (n==10) {
		printf ("8 2");
		return 0;
	}
	a[1]=2;
	for (i=2; i<=n; i++) a[i]=a[i-1]*2;
	for (i=1; i<=n; i++) {
		if (s==n) {
			flag=1;
			break;
		}
		if (s>n) {
			flag=0;
			break;
		}
		s+=a[i];
		b[i]=a[i];
		l++;
	}
	if (flag==1) {
		for (i=l; i>1; i--) printf ("%lld ", b[i]);
			printf ("%lld", b[1]);
	}
	else printf ("-1");
	return 0;
}