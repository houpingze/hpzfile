#include"cstdio"
#include"algorithm"
using namespace std;
int a[10005],n,k,i,m;
inline int read(){
	register int x=0,f=1;register char ch=getchar();
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
inline void out(int x){
	if(x>=10) out(x/10);
	putchar(x%10+'0');
}
bool cmp(int a,int b){
	return a>b;
}
int main(){
 	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	n=read();k=read();
	for(i=1;i<=n;i++) {
		int v=read();
		a[v]++;
		int m=max(m,v);
		int xx=max(1,(int) (k/100.*i)),j,vv;
		for(j=xx,vv=m;j>=1;vv--)
			if(a[vv]) j-=a[vv];
		printf("%d ",vv+1);
	}
	return 0;
}