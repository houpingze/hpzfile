#include"cstdio"
using namespace std;
char a[100005]={'0'},ch[10005];
int m,n,k[100005],v,ans,x;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	gets(a);
	for(int i=1;a[i];i++)
		if(a[i]=='&'||a[i]=='|'||a[i]=='!') ch[v]=a[i];
	scanf("%d",&n);
	for(int i=1,bb=1;i<=n;i++,bb++)
		scanf("%d",&k[i]);
	scanf("%d",&m);
	int t=k[2];k[2]=k[3];k[3]=t;
	for(int i=1;i<=m;i++){
		scanf("%d",&x);
		printf("0\n");
	}
	return 0;
}