#include"cstdio"
#include"algorithm"
using namespace std;
int a[10005],n,s=1,i,k,j,xx,t,xxx,xxxx,l,r;
inline int read(){
	register int x=0,f=1;register char ch=getchar();
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
inline void out(int x){
	if(x>=10) out(x/10);
	putchar(x%10+'0');
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%d",&n);
	if(n%2) {printf("-1");exit(0);}
	for(;s<n;)
	     s*=2;
	for(i=2,k=1;i<=s;i*=2,k++) a[k]=i;
	for(l=k-1;l>=1;l--)
		if(n>=a[l]) {printf("%d ",a[l]);n-=a[l];}
	return 0;
}