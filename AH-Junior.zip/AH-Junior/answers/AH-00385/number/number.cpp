#include"cstdio"
#include"algorithm"
using namespace std;
long long a[1005][1005],n,j,x,m,i,ans=-(1<<30);
bool f[1005][1005];
inline  long long read(){
	register long long x=0,f=1;register char ch=getchar();
	while(ch<'0'||ch>'9') {if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
inline void dfs(long long x,long long y,long long xx){
	if(x>=n&&y>=m) {ans=max(ans,xx);return;}
	if(x<n&&!f[x+1][y]) {f[x+1][y]=true;dfs(x+1,y,xx+a[x+1][y]);f[x+1][y]=false;}
	if(y<m&&!f[x][y+1]) {f[x][y+1]=true;dfs(x,y+1,xx+a[x][y+1]);f[x][y+1]=false;}
	if(x>1&&!f[x-1][y]) {f[x-1][y]=true;dfs(x-1,y,xx+a[x-1][y]);f[x-1][y]=false;}
}
inline void out(long long x){
	if(x>=10) out(x/10);
	putchar(x%10+'0');
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	n=read();m=read();
	for(i=1;i<=n;i++){
		for(j=1;j<=m;j++)
			a[i][j]=read();
	}
	dfs(1,1,a[1][1]);
	printf("%lld",ans);
	return 0;
}