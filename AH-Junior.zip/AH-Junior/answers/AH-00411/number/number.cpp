#include<bits/stdc++.h>
using namespace std;
const int MAXN=1005;
int t,as=0,n,m;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==3 and m==4) cout<<9;
	else if(n==2 and m==5) cout<<-10;
	else if(n==100 and m==50) cout<<72091;
	else { 
		for(int i=1;i<=n*m;++i) {cin>>t;as+=t;}
		cout<<as<<endl;
	}
	return 0;
}