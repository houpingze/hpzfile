#include<bits/stdc++.h>
using namespace std;
int n,a[100005];
int w;
int ans;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;++i){
		scanf("%d",a+i);
		if(i==1){ printf("%d ",a[i]); continue;}
		int now=ceil(i*(w*0.01)+0.000001)-1;
		now=max(1,now);  
		sort(a+1,a+i+1,greater<int>());
		printf("%d ",a[now]);
	}
	return 0;
}