#include<bits/stdc++.h>
using namespace std; 
long long n;
int a[10000005],t;
int pow(int a){
	int ans=1;
	for(int i=1;i<=a;++i) ans*=2;
	return ans;
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%lld",&n);
	while(n){
		t++;
		a[t]=n%2;
		n/=2;
	}
	if(a[1]==1) {
		puts("-1");
	}
	else {
		for(int i=t;i>=1;--i) {
			if(a[i]==1){
				printf("%d ",pow(i-1));
			}
		}
	}
	return 0;
}
