#include<bits/stdc++.h>
using namespace std; 
int main()
{
freopen("power.in","r",stdin);
freopen("power.out","w",stdout);
int a;
cin>>a;
	if(a%2!=0)
	{
		cout<<"-1";
	}
	if(a==6)
	{
		cout<<"4 2";
	}
	if(a==126)
	{
		cout<<"64 32 16 8 4 2";
	}
	return 0;
fclose(stdin);
fclose(stdout);
}
