#include<bits/stdc++.h>
using namespace std; 
int main()
{
freopen("number.in","r",stdin);
freopen("number.out","w",stdout);
return 0;
fclose(stdin);
fclose(stdout);
}