#include<bits/stdc++.h>
using namespace std; 
int main()
{
freopen("expr.in","r",stdin);
freopen("expr.out","w",stdout);
return 0;
fclose(stdin);
fclose(stdout);
}