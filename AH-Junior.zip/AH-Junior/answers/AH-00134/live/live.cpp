#include <iostream>
#include <cstdio>
using namespace std;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,t;
	int	m,k=2,z=2,u=2;
	float i=2;
	cin>>n;
	cin>>m;
	int a[n+1];
	cin>>a[1];
	cout<<a[1]<<" ";
	while(u<=n)
	{
		cin>>a[u];
		while(u>=z)
		{
			if(a[z]>a[z-1])
			{
				t=a[z];
				a[z]=a[z-1];
				a[z-1]=t;
			}
			z++;
		}
		z=2;
		k=(i*m/100);
		if(k<i*m/100)
			k++;
		cout<<a[k]<<" ";
		i=i+1;
		u++;
	}
	return 0;
}