#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int a,i=2,k=1,n=1,f=0;
	int s[10001];
	cin>>a;
	while(a>1)
	{
		
		if(a%2==1)
		{
			cout<<"-1";
			break;
		}
		else
		{
			if(a-i<0)
			{
				s[k]=i/2;
				a=a-(i/2);
				i=1;
				k++;
				if(a==0)
				{
					f=1;
					break;
				}
			}
			else
			{
				;
			}
		}
		i=(i*2);
		
	}
	k--;
	if(f==1)
	{
		while(n<=k)
		{
			cout<<s[n]<<" ";
			n++;
		}
	}
	return 0;
}