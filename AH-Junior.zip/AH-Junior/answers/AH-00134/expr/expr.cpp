#include <iostream>
#include <cstdio>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	return 0;
}