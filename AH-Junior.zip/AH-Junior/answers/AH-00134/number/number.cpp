#include <iostream>
#include <cstdio>
using namespace std;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m,i=1,k=1,s=0;
	cin>>n; 
	cin>>m;
	int a[n+1][m+1];
	while(n>=i)
	{
		while(m>=k)
		{
			cin>>a[i][k];
			s=s+a[i][k];
			k++;
			
		}
		k=1;
		i++;
	}
	cout<<s;
	return 0;
}