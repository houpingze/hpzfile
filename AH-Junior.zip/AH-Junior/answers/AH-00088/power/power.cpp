#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int i;
	cin>>i;
	cout<<-1;
	fclose(stdin);fclose(stdout);
	return 0;
}