#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","r",stdout);
	string a;
	int n,q;
	getline(cin,a);
	cin>>n;
	int m[n];
	for(int i=0;i<n;i++)cin>>m[i];
	cin>>q;
	int m1[q];
	for(int i=0;i<q;i++)cin>>m1[i];
	cout<<1<<endl<<0<<endl<<0;
	fclose(stdin);fclose(stdout);
	return 0;
}