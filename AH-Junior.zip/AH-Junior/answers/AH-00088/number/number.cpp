#include<iostream>
#include<cstdio>
using namespace std;
int b[1001][1001];
int n,m,s;
int a[1001][1001];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","r",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	cin>>a[i][j];
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		if(a[i][j+1]>a[i+1][j])
		{
			if(b[i][j+1]!=1)
			{
				s+=a[i][j+1];
			    b[i][j+1]=1;
			    j+=1;
			}
			if(b[i][j+1]==1)
			{
				s+=a[i+1][j];
				b[i+1][j]=1;
			}
		}
		if(a[i+1][j]>a[i][j+1])
		{
			if(b[i+1][j]!=1)
			{
				s+=a[i+1][j];
			    b[i+1][j]=1;
			    i+=1;
			}
			if(b[i+1][j]==1)
			{
				s+=a[i][j+1];
				b[i][j+1]=1;
			}
		}
	}
	cout<<s+a[1][1];
	fclose(stdin);fclose(stdout);
	return 0;
}