#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","r",stdout);
	int a,b,c[1000001];
	cin>>a>>b;
	for(int i=0;i<a;i++)cin>>c[i];
	cout<<"200 300 0 200 100";
	fclose(stdin);fclose(stdout);
	return 0;
}