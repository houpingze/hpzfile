#include <bits/stdc++.h>
using namespace std;
int a[100001];
bool bmp(int a,int b)
{
	if (a>b)
	{
		return true;
	}
	return false;
}
int main()
{
    freopen ("live.in","r",stdin);
    freopen ("live.out","w",stdout);
	int n,x,w;
	cin>>n>>w;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		sort(a,a+i+1,bmp);
		x=(i+1)*w/100;
	    x=max(1,x);
		cout<<a[x-1]<<" ";
	}
	return 0;
}