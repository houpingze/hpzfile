#include <bits/stdc++.h>
using namespace std;
bool pd=false,pdp[16777216];
int a[30],a1=1;
bool p(bool pd,int n)
{
	int c;
	int d;
	for(int i=2;i<=n;i*=2)
	{
		if (i*2>=n)
		{
			d=i;
		}
	}
	for(int i=d;i>=2;i/=2)
	{
		c=n;
		if (n-i>=0&&pdp[i]==true)
		{
			n-=i;
			pdp[i]=false;
			pd=p(pd,n);
			if(pd==true||n==0)
			{
				a[a1]=i;
				a1++;
				return true;
			}
		}        
		if (n-i<0)
		{
			n=c;
			pdp[i]=true;
			return false;
		}
	}
}
int main()
{
    freopen ("power.in","r",stdin);
    freopen ("power.out","w",stdout);
	int n,c=0;
	bool l=true;
	int b=1;
	cin>>n;
	if(n%2!=0)
	{
		cout<<"-1"<<endl;
		return 0;
	}
	for(int i=2;i<=n;i*=2)
	{
		pdp[i]=true;
	}
	l=p(pd,n);
	for(int i=a1-1;i>=1;i--)
	{
		cout<<a[i]<<" ";
	}
    return 0;
}