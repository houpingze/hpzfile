#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int a[n][m];
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			cin>>a[i][j];
	if(n==3)
	{
		cout<<9;
		return 0;
	}
	if(n==2)
	{
		cout<<-10;
		return 0;
	}
	if(n==100)
	{
		cout<<72091;
		return 0;
	}
}