#include<bits/stdc++.h>
using namespace std;
long long a[100001];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long n;
	cin>>n;
	if(n%2==1)
	{
		cout<<-1;
		return 0;
	}
	long long a[n];
	for(long long i=0;i<n;i++)
		a[i]=0;
	long long k=0;
	long long n2=n;
	for(long long i=2;i<=n;i*=2)
	{
		if(n-i>=0)
		{
			n=n-i;
			a[k]=i;
			k++;
		}
		if(n%2==1)
		{
			cout<<"-1";
			return 0;
		}
	}
	long long x=0;
	for(long long i=0;i<k;i++)
		x+=a[i];
	if(x==n2)
		for(long long i=k-1;i>=0;i--)
			cout<<a[i]<<" ";
	else
		cout<<"-1";
	fclose(stdin);
	fclose(stdout);
	return 0;
}