#include<bits/stdc++.h>
using namespace std;
bool cmp(int x,int y)
{
	return x>y;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n;
	double w;
		cin>>n>>w;
	w/=100;
	int a[n+1];
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int k=0;
	for(int p=1;p<=n;p++)
	{
		int s=floor(p*w);
		k=max(1,s);
		sort(a+1,a+p+1,cmp);
		cout<<a[k]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
}