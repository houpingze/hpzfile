#include<bits/stdc++.h>
using namespace std;
int ans[30],cnt;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	if(n%2==1)
	{
		cout<<-1;
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	for(int i=1;1<<i<=n;i++)
	{
		if((n>>i)&1)
		{
			ans[++cnt]=1<<i;
		}
	}
	for(int i=cnt;i>=1;i--)
	{
		cout<<ans[i]<<' ';
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}