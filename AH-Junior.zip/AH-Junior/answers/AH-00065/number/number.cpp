#include<bits/stdc++.h>
using namespace std;
const int maxn=1000,maxm=1000;
const int dx[]={1,0,-1,0};
const int dy[]={0,1,0,-1};
int n,m,a[maxn+1][maxm+1],f[maxn+1][maxm+1];
bool vis[maxn+1][maxm+1];
void bfs(int x,int y)
{
	queue<pair<int,int> >q;
	q.push(make_pair(x,y));
	vis[x][y]=true;
	while(!q.empty())
	{
		pair<int,int>u=q.front();
		q.pop();
		for(int i=0;i<4;i++)
		{
			x=u.first+dx[i];
			y=u.second+dy[i];
			if(x<1||x>n||y<1||y>m)
			{
				continue;
			}
			f[x][y]=max(f[x][y],f[u.first][u.second]+a[x][y]);
			if(vis[x][y])
			{
				continue;
			}
			q.push(make_pair(x,y));
			vis[x][y]=true;
		}
	}
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
	memset(f,-0x3f,sizeof(f));
	f[1][1]=a[1][1];
	vis[1][1]=true;
	bfs(1,1);
	cout<<f[n][m];
	fclose(stdin);
	fclose(stdout);
	return 0;
}