#include<bits/stdc++.h>
using namespace std;
const int maxn=100000;
string s;
int n,q;
bool x[maxn+1];
char tree[maxn*2+1];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.put","w",stdout);
	getline(cin,s);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>x[i];
	}
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		int t;
		cin>>t;
		cout<<!x[t];
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}