#include<bits/stdc++.h>
using namespace std;
const int maxn=100000;
int n,w,a[maxn+1];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++)
	{
		int x;
		cin>>x;
		int j=i-1;
		while(j>=1&&a[j]<x)j--;
		for(int k=i;k>j+1;k--)
		{
			a[k]=a[k-1];
		}
		a[j+1]=x;
		cout<<a[max(1,i*w/100)]<<' ';
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}