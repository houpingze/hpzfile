#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("unmber.in","r",stdin);
	freopen("unmber.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(m=1;m>=n;m++)
	cout<<m;
	return 0;
	fclose(stdin);fclose(stdout);
}