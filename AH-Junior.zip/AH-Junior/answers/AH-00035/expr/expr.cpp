#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int a,b;
	cin>>a>>b;
	cout<<"1"<<endl<<"0"<<endl<<"0"<<endl;
	return 0;
	fclose(stdin);fclose(stdout);
}