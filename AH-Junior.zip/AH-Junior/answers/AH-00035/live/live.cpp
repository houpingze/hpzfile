#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
        freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int x;
	cin>>x;
    cout<<"200 300 400 400 400 500 400 400 300 300";
	return 0;
	fclose(stdin);fclose(stdout);
