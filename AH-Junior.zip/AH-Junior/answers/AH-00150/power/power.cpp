#include<bits/stdc++.h>
using namespace std;
int p[10001],k,n,a[10001];
void ts(int step,int sum,int pre){
	int i;
	if(sum==n){
		for(i=1;i<=step;i++)cout<<a[i]<<' ';exit(0);
	}
	for(i=pre-1;i>=1;i--)
		if(sum+p[i]<=n){a[step+1]=p[i];ts(step+1,sum+p[i],i);}

}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int x=2;
	cin>>n;if(n%2!=0)goto sc;
	while(x<=n){p[++k]=x;x*=2;}
	ts(0,0,k+1);
	sc: cout<<-1;
	fclose(stdin);fclose(stdout);
	return 0;
}