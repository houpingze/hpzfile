#include<bits/stdc++.h>
using namespace std;
int n,m,a[1001][1001],f[1001][1001],p[1001][1001];
int d1[3]={0,1,-1},d2[3]={1,0,0};
int dfs(int x,int y){
	if(x==n&&y==m)return a[n][m];
	int i,t=-999999;
	for(i=0;i<3;i++){
		int kx=x+d1[i],ky=y+d2[i];
		if(kx<1||kx>n||ky<1||ky>m||p[kx][ky])continue;
		p[x][y]=1;t=max(t,dfs(kx,ky)+a[x][y]);p[x][y]=0;
	}
	return f[x][y]=t;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int i,j;
	cin>>n>>m;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++){cin>>a[i][j];f[i][j]=-999999;}
	cout<<dfs(1,1);
	fclose(stdin);fclose(stdout);
	return 0;
}