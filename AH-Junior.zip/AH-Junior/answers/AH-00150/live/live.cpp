#include<bits/stdc++.h>
using namespace std;
int n,w,b[601],ans[100001];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	int i,a;
	for(i=1;i<=n;i++){
		cin>>a;b[a]++;
		int s=0,x=601,k=max(1,int(i*w/100.0));
		while(s<k){s+=b[x];x--;}
		ans[i]=x+1;
	}
	for(i=1;i<=n;i++)cout<<ans[i]<<' ';
	fclose(stdin);fclose(stdout);
	return 0;
}