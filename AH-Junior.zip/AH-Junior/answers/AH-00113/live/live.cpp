#include<fstream>
#include<cmath>
#include<algorithm>
using namespace std;
int peo[100002];
bool cmp(const int x,const int y){
    return x>=y;
}
int main(){
	ifstream fin("live.in");//
	ofstream fout("live.out");//
	//.code
	double w;
	int n;
	fin>>n>>w;
	w=w*0.01;
	int mapc,last=1;
	for(int i=1;i<=n;i++){
		fin>>peo[i];
		mapc=floor(i*w);
		mapc=max(1,mapc);
		if(peo[i]>peo[last])
			sort(peo+1,peo+i+1,cmp);
		else 
			sort(peo+last,peo+i+1,cmp);
		fout<<peo[mapc]<<' ';
		last=mapc;
	}
	//
	fin.close();
	fout.close();
	return 0;
	}