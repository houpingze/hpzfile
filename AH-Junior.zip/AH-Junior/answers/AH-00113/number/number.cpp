#include<fstream>
using namespace std;
bool bsq[1002][1002];
int sq[1002][1002]; 
int n,m;
long long ans=-10000000002,jl=0;
bool dfs(int x,int y){
	if(x==n and y==m){
		ans=max(ans,jl+sq[n][m]);
		return 0;
	}
	bsq[x][y]=true;
	jl=jl+sq[x][y];
	if(x!=0&&!bsq[x-1][y])
		dfs(x-1,y);
	if(y!=0&&!bsq[x][y-1])
		dfs(x,y-1);
	if(x!=n&&!bsq[x+1][y])
		dfs(x+1,y);
	if(y!=m&&!bsq[x][y+1])
		dfs(x,y+1);
	jl=jl-sq[x][y];
	bsq[x][y]=false;
	return 0;
}
int main(){
	ifstream fin("number.in");//
	ofstream fout("number.out");//
	fin>>n>>m;
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			fin>>sq[i][j];
	n=n-1;
	m=m-1;
	dfs(0,0);
	fout<<ans;
	fin.close();//
	fout.close();//
	}