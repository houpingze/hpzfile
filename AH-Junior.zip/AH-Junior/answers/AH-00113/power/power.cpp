#include<fstream>
using namespace std;
int ans[10000];
int ansj=0;
bool f(int least,int myn){
	if(myn==0) return 1;
	if(myn<0) return 0;
	int mymi=least*2;
	if(mymi>myn) return 0;
	if(f(mymi,myn-mymi)){
	 	ans[ansj]=mymi;
		ansj++;
		return 1;
	}
	if(f(mymi,myn))
		return 1;
	return 0;
}
int main(){
	ifstream fin("power.in");//
	ofstream fout("power.out");//
	int n;
	fin>>n;
	if(n%2!=0){
		fout<<"-1";
		return 0;
	}
	if(!f(1,n))
		fout<<"-1";
	else{
		for(int i=0;i<ansj;i++)
			fout<<ans[i]<<' ';
	}
	fin.close();//
	fout.close();//
	return 0;
	}