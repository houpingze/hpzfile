#include<fstream>
#include<string>
using namespace std;
bool bed[100002];
int poin;
string ain;
int n;
bool cz[100002];
bool mya(void){
	int asize=ain.size();
	int czj=0;
	bool le,ri,an;
	poin=0;
	for(int i=0;i<asize;i++){
		if(ain[i]=='x')
			bed[poin++]=cz[czj++];
		else if(ain[i]=='!'){
			an=bed[poin-1];
			an=!an;
			bed[poin-1]=an;
		}
		else{
			le=bed[poin-1];
			ri=bed[poin-2];
			an=0;
			if(ain[i]=='&')
				if(le==1 and ri==1) an=1;
			if(ain[i]=='|')
				if(le==1 or ri==1) an=1;
			bed[poin-2]=an;
			poin--;
		}
	}
	return bed[poin-1];
}
int main(){
	ifstream fin("expr.in");//
	ofstream fout("expr.out");//
	int q,qz;
	bool ans=0;
	getline(fin,ain);
	fin>>n;
	int asize=ain.size();
	for(int i=0;i<asize;i++){
		if((ain[i]>47 and ain[i]<58)){
			fin>>ans;
			cz[ain[i]-49]=ans;
			ain.erase(i,1);
			i--;
		}
		if(ain[i]==' '){
			ain.erase(i,1);
			i--;
		}
	}
	fin>>q;
	for(int i=0;i<q;i++){
		fin>>qz;
		cz[qz-1]=!cz[qz-1];
		ans=mya();
		cz[qz-1]=!cz[qz-1];
		fout<<ans<<endl;
	}
	fin.close();//
	fout.close();//
	}