#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen ("live.in","r",stdin);
    freopen ("iive.out","w",stdout);
	int n;
	double w;
	cin>>n>>w;
	int x[10001];
	int p=0;
	if (1/w==0)
	{
		p=p;
	}
	else if (1/p!=0)
	{
		p+=1;
	}
	w=w/100;
	p=p+1/w;
	
	int num=0;
	for (int i=1;i<=n;i++)
	{
		cin>>x[i];
		for (int j=1;i<=p;j++)
		{
			if (num!=p)
			{
				if(x[j]==x[j-1])
					cout<<x[i];
				else if (x[j]!=x[j-1])
				{
					cout<<x[i];
					num++;
				}
			}
		}
	}
	//max(1, ⌊p × w%⌋)

    fclose (stdin);
    fclose (stdout);
	return 0;
}