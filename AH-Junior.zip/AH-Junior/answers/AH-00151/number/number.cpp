#include <bits/stdc++.h>
using namespace std;
int main()
{
  freopen ("number.in","r",stdin);
  freopen ("number.out","w",stdout);

  fclose (stdin);
  fclose (stdout);
  return 0;
}
