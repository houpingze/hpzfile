#include <bits/stdc++.h>
using namespace std;
int main()
{
  freopen ("expr.in","r",stdin);
  freopen ("expr.out","w",stdout);

  fclose (stdin);
  fclose (stdout);
  return 0;
}
