#include <bits/stdc++.h>
using namespace std;
int main()
{
  freopen ("power.in","r",stdin);
  freopen ("power.out","w",stdout);
  int n;	
  cin>>n;
  int a=2; 
  int num[1001];
  int sum[1001];
  int s=2;
  int x=2;
	  if (n%2==0)
	  {
		for (int i=0;i<=n ;i++)
		{
			if (i==1)
			{
				a=a;
			}
			else if (i>1)
			{
				s=s*2;
				num[i]=s;
		
				for (int j=1;j<=n;j++)
				{
					x=x*2;
					sum[j]=x;
					if (a+num[i]==n)
						cout<<i<<" "<<1;
					else if (num[i]+sum[j]==n)
					{
						if (j>i)
							cout<<j<<i;
						else if (i>j)
							cout<<i<<j;
					}
					else 
						cout<<-1;
				}	
			}	
		}
	}
	else 
		cout<<-1;
	fclose (stdin);
	fclose (stdout);
	return 0;
}




