#include<bits/stdc++.h>
using namespace std;
queue <int> ans;
void dfs(int n)
{
	int s=2;
	while(n>0)
	{
		while(s*2<=n)
			s*=2;
		n-=s;
		ans.push(s);
		s=2;
	}
	return ;
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	if(n%2!=0 || n==0)
		cout<<-1;
	dfs(n);
	cout<<ans.front();
	ans.pop();
	while(!ans.empty())
	{
		int a=ans.front();
		ans.pop();
		cout<<" "<<a;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}