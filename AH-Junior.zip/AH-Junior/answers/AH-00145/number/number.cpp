#include<bits/stdc++.h>
using namespace std;
int ans,maxn=INT_MIN;
int n,m;
int visit[1000][1000],a[1000][1000];
void dfs(int x,int y)
{
	if(x<0 || y<0 || x>=n || y>=m || visit[x][y])
		return ;
	ans+=a[x][y];
	if(x==n-1 && y==m-1)
	maxn=max(maxn,ans);
	visit[x][y]=1;
	dfs(x+1,y);
	dfs(x-1,y);
	dfs(x,y+1);
	dfs(x,y-1);
	ans-=a[x][y];
	visit[x][y]=0;
	return ;
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			cin>>a[i][j];
	memset(visit,0,sizeof(visit));
	dfs(0,0);
	cout<<maxn;
	fclose(stdin);
	fclose(stdout);
	return 0;
}