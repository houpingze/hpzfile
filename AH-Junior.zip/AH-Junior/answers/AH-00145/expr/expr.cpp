#include<bits/stdc++.h>
using namespace std;
long long ans,maxn=INT_MIN;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<0;
	fclose(stdin);
	fclose(stdout);
	return 0;
}