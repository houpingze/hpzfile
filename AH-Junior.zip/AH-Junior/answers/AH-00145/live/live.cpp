#include<bits/stdc++.h>
using namespace std;
long long ans,maxn=INT_MIN;
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int w,n;
	cin>>n>>w;
	vector<int> a(n,0);
	vector<int> s(601,0);
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		s[a[i]]++;
		int m=max(1,(i+1)*w/100);
		int j=600;
		while(j>=0 && m>0)
		{
			m-=s[j];
			j--;
			//cout<<m<<" "<<s[j]<<" "<<j<<endl;
		}
		cout<<j+1<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}