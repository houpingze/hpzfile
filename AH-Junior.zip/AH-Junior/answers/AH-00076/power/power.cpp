#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int a,a1,b[100002];
	cin>>a;
	if(a%2==1)
	cout<<"-1"<<endl;
	for(int i=2;i<=a;i+=2){
		if(a1>=a){
		a1-=i;
		b[i]=i;
		}
		else
		break;
	}
	for(int i=2;i<=a;i+=2)
	cout<<b[i]<<" ";
	return 0;	
}