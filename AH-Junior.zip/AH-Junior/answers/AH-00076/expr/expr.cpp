#include<bits/stdc++.h>
using namespace std;
int main(){	
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;
	getline(cin,a);
	int n;
	cin>>n;
	int a[100001]
	for(int i=1;i<=n;i++)
	cin>>a[i];
	int w;
	cin>>w;
	int q,b[100001]
	for(int i=1;i<=q;i++)
	cin>>b[i];
	cout"1"<<endl;
	cout"1"<<endl;
	cout"0"<<endl;
	return 0;
}