#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int x,y,a[1000001];
	cin>>x>>y;
	for(int i=1;i<=x*y;i++)
		cin>>a[i];
	cout<<"9";
	return 0;
}