#include <iostream>
#include <cstdio>
using namespace std;
int main() {
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long n, a=2, b=4, c=8, d=16, e=32, f=64, g=128, h=256, i=512, j=1024, k=2048, l=4096, m=8192, o=16384, p=32768, q=65536, r=131072, s=262144, t=524288, u=1048576, v=2097152, w=4194304, x=8388608, y=16777216, z=33554432;
	cin >> n;
	for(int ai = 0; ai < n; ai++){
		if(a==n){
			cout<<a<<endl;
		}
		if(a+b==n){
			cout<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c==n){
			cout<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d==n){
			cout<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e==n){
			cout<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f==n){
			cout<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g==n){
			cout<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h==n){
			cout<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i==n){
			cout<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j==n){
			cout<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k==n){
			cout<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l==n){
			cout<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m==n){
			cout<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o==n){
			cout<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p==n){
			cout<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q==n){
			cout<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r==n){
			cout<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s==n){
			cout<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s+t==n){
			cout<<t<<" "<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s+t+u==n){
			cout<<u<<" "<<t<<" "<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s+t+u+v==n){
			cout<<v<<" "<<u<<" "<<t<<" "<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s+t+u+v+w==n){
			cout<<w<<" "<<v<<" "<<u<<" "<<t<<" "<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s+t+u+v+w+x==n){
			cout<<x<<" "<<w<<" "<<v<<" "<<u<<" "<<t<<" "<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s+t+u+v+w+x+y==n){
			cout<<y<<" "<<x<<" "<<w<<" "<<v<<" "<<u<<" "<<t<<" "<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
		if(a+b+c+d+e+f+g+h+i+j+k+l+m+o+p+q+r+s+t+u+v+w+x+y+z==n){
			cout<<z<<" "<<y<<" "<<x<<" "<<w<<" "<<v<<" "<<u<<" "<<t<<" "<<s<<" "<<r<<" "<<q<<" "<<p<<" "<<o<<" "<<m<<" "<<l<<" "<<k<<" "<<j<<" "<<i<<" "<<h<<" "<<g<<" "<<f<<" "<<e<<" "<<d<<" "<<c<<" "<<b<<" "<<a<<endl;
			return 0;
		}
	}
	cout << "-1";
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}