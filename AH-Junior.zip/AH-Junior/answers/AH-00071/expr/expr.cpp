#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;cin >> a;
	int n,q;
	cin >> n;
	for (int i=0;i<n;i++){
		int x;
		cin >> x;
	}
	cin >> q;
	for (int i=0;i<q;i++){
		int x;
		cin >> x;
	}
	for (int i=0;i<q;i++){
		cout <<"1";
	}
	return 0;
}