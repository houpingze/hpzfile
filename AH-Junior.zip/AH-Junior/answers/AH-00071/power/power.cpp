#include <bits/stdc++.h>
using namespace std;
int main(){
	queue<long long> q;
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long  m;
	cin >> m;
	while(m>1){
		q.push(pow(2,floor(log(double(m))/log(2))));
		m-=pow(2,floor(log(double(m))/log(2)));
	}
	if (m==1){
		cout << -1;	
	}else{
		cout << q.front() ;
		q.pop();
		while (!q.empty()){
			cout << ' ' <<q.front() ;
			q.pop();
		}
	}
	return 0;
}