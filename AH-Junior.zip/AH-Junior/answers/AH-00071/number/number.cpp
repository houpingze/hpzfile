#include <bits/stdc++.h>
using namespace std;
struct pos{
	int x,y,num,type;
};
int main(){
	int maxx=-32768*32768;
	queue<pos> q;
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	pos nw,now;
	int n,m;cin >> n >> m;
	int g[n][m];
	int mag[n][m];
	for (int i=0;i<n;i++){
		for (int j=0;j<m;j++){
			cin >> g[i][j];
			mag[i][j]=-32768*32768;
		}
	}
	int r[m];
	r[m-1]=0;
	for (int i=n-2;i>=0;i--){
		r[i]=r[i+1]+g[i-1][m-1];
	}
	now.x=0;now.y=0;now.num=0;now.type=0;
	q.push(now);
	while (!q.empty()){
		now=q.front();
		now.num+=g[now.x][now.y];
		if (now.num>mag[now.x][now.y]){
			mag[now.x][now.y]=now.num;
		}else{
			q.pop();
			continue;
		}
		nw.num=now.num;
		if (now.x==n-1&&now.y==m-1){
			if (now.num>maxx){
				maxx=now.num;
			}
			q.pop();
			continue;
		}
		if (now.x>0&&now.type!=3&&now.y<m-1){
			nw.x=now.x-1;
			nw.y=now.y;
			nw.type=2;
			q.push(nw);
		}
		if (now.x<n-1&&now.type!=2){
			nw.x=now.x+1;
			nw.y=now.y;
			
			nw.type=3;
			q.push(nw);
		}
		if (now.y<m-1){
			nw.x=now.x;
			nw.y=now.y+1;
			nw.type=1;
			q.push(nw);
		}
		q.pop();
	}
	cout << maxx;
	return 0;
}