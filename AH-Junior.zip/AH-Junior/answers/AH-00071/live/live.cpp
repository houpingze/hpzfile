#include <bits/stdc++.h>
using namespace std;
int s[601];
int q[601];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	for (int j=0;j<601;j++){
		q[j]=0;
		s[j]=0;
	}
	int maxx=0;
	int n,w;
	cin >> n >> w;
	for (int i=0;i<n;i++){
		int x;
		cin >> x;
		if (x>maxx){
			maxx=x;
		}
		s[x]+=1;
		for (int j=0;j<x;j++){
			q[j]+=1;
		}
		int c=floor(float(i+1)*(float(w)/100.0));
		if (i==0){c=1;}
		//cout << c << endl;
		for (int j=600;j>=0;j--){
			if (q[j]+1>c&&j<=maxx){
				cout << j+1;
				if (i<n-1){
					cout << ' ';
				}
				break;
			}
		}
	}
	return 0;
}