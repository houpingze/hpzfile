#include<bits/stdc++.h>
using namespace std;
long long a,i,s=0,z=0,j;
int main()
{
freopen( "power.in","r",stdin);
freopen( "power.out","w",stdout);
cin>>a;
if(a%2!=0)
{
	cout<<"-1"<<endl;
}                                                      
	else if(a==0)
	{cout<<"-1"<<endl;}
else
for(i=0;i<=900;i++)
s=a/2;
z=s;
if(z%2==0)
cout<<z/2*2<<" "<<z/2*2<<endl;
else if(z%2!=0)
cout<<z-z%2*2*2<<" "<<z%2*2*2<<endl;
fclose(stdin);
fclose(stdout);
return 0;
}