#include<iostream>
#include<cstdio>
using namespace std;int n;long long int a[24]={2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608};
int d(int s)
{
	s=0;
	for(int i=22;i>=0;i--)
	{
		if(s+a[i]<=n)s+=a[i],cout<<a[i]<<" ";
	}
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2==1){cout<<"-1";return 0;}
	d(n);
	return 0;
}