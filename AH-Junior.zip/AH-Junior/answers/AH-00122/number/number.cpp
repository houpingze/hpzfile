#include<bits/stdc++.h>
using namespace std;	
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int m,n,a[1001][1001],s=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
		cin>>a[i][j];
		s+=a[i][j];
		}}
	cout<<s/m/n;
	return 0;
}