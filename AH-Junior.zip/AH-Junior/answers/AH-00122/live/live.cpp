#include<bits/stdc++.h>
using namespace std;int a[100001],s=0,n,w,p[100001],r[100001];
int d(int aa)
{
	for(int i=1;i<aa;i++)
	{
		for(int j=i+1;j<=aa;j++)
		if(a[i]>a[j])swap(a[i],a[j]);
	}
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++)
	{
		cin>>p[i];
		a[i]=p[i];
		r[i]=max(1,i*w/100);
	}
	for(int i=1;i<=n;i++)
	{
		d(i);
		cout<<a[i-r[i]+1]<<" ";
	}
	return 0;
}