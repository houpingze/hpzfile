#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	int n,q,a[100001],b[100001];
	cin>>s;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>q;
	for(int i=1;i<=q;i++)
	{cin>>b[i];
		cout<<"0 ";
	}return 0;
}
