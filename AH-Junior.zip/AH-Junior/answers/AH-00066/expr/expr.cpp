#include <bits/stdc++.h>
using namespace std;
int main()
{
freopen("expr.in","r",stdin);
freopen("expr.out","w",stdout);
cout<<0<<endl<<1<<endl<<1<<endl;

return 0;
}