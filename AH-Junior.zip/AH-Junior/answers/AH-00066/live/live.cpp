#include <bits/stdc++.h>
using namespace std;
bool a[1000000];
int main()
{
freopen("live.in","r",stdin);
freopen("live.out","w",stdout);
int w,x,rs=1,v;
double b;
cin>>w>>x;
for(int i=1;i<=w;i++)
{
	cin>>v;
	a[v]=0;
}
b=x*1.0/100.0;
for(int i=1;i<=12000;i++)
{
	if(rs<b*1.0*i)
	{
		rs=floor(b*1.0*i);
	}
	if(a[i]==0||i==rs)
	cout<<i<<" ";
}
return 0;
}
