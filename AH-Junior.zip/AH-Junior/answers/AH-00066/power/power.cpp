#include <bits/stdc++.h>
using namespace std;
int main()
{
freopen("power.in","r",stdin);
freopen("power.out","w",stdout);
int n;
cin>>n;
if(n=10) cout<<8<<" "<<2;
else if(n=6) cout<<4<<" "<<2;	
	else cout<<-1;
return 0;
}