#include <bits/stdc++.h>
using namespace std;

long long n, p=2;
bool op=false;

void poww(int a){
	int k=0;
	p=2;
	while(n>=p){
		if(n==p){
			cout<<n;
			op=true;
			}
		p=p*2;
		k++;
	}
	p=p/2;
	if(p!=1) cout<<p<<' ';
	}

int main(){
	freopen("power.in", "r", stdin);
	freopen("power.out", "w", stdout);
	cin>>n;
	if(n%2!=0){
		cout<<"-1";
		return 0;
		}
	poww(n);
	if(op==true) {
		return 0;
		}
	while(n>=2){
		n=n-p;
		if(n==2){
			cout<<n;
			return 0;
			}
		poww(n);
		}
	return 0;
}