#include <bits/stdc++.h>
using namespace std;

int n, m, ex[1005][1005], sum;
bool vis[1005][1005];

void dfs(int h, int z, int s){
	if(h==n&&z==m) {
		sum=max(sum, s);
		return;
		}
	if(vis[h][z]!=1&&h>=0&&z>=0){
		vis[h][z]=1;
		s+=ex[h][z];
		dfs(h+1, z, s);
		dfs(h-1, z, s);
		dfs(h, z+1, s);
		}
	}

int main(){
	freopen("number1.in","r", stdin);
	freopen("number.out","w", stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cin>>ex[i][j];
			}
		}
	dfs(0, 0, 0);
	cout<<sum;
	return 0;
}