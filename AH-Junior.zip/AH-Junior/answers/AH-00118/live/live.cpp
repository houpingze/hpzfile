#include <bits/stdc++.h>
using namespace std;

int n;
double w;
int com[100005];

bool cmpp(int a, int b){
	return a>b;
	}

int main(){
	freopen("live.in", "r", stdin);
	freopen("live.out", "w", stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>com[i];
		sort(com+1, com+i+1, cmpp);
		int t=i*(w/100);
		cout<<com[max(1, t)]<<' ';
		}
	return 0;
}