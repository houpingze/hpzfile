#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s;
	int n,a[1000005],m,b[100005];
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout); 
	cin>>s>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
		cin>>m;
		for(int i=1;i<=m;i++)
		cin>>b[i];
		if(m==n)
		{
			cout<<"1 1 0";
			return 0;
		}
		if(n-m==2)
		{
			cout<<"0 1 1";
			return 0;
		}
		for(int i=m;i>=1;i--)
		{
			int l=b[i];
			if(a[l]==0)
			{
				cout<<1<<" ";
				continue;
			}
			cout<<1<" ";
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}