#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long n,a;
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin >>n;
	if((n<2)&(n%2!=0))
	{
		cout<<"-1";
		return 0;
	}
	
	if(n%4==0)
	{
		cout<<"-1";
		return 0;
	}
	a=n/2+1;
	for(int i=1;;i++)
	{
		if(a==2)
		{
			cout<<a;
			break;
		}
		cout<<a<<" ";
		a/=2;
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}