#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,w,k,a[100005],b[100005];
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int j=1;
	sort(a,a+n);
	for(int i=1;i<=n;i--)
	{
		b[j]=a[i];
		j++;
	}
	for(int i=1;i<=n;i++)
	{
		cout<<b[1]<<" ";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}