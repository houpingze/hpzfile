#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
struct node{
	int score,num;
	int id;
}a[10000001];
bool cmp(node a,node b){
	return a.score>b.score;
}
int score,num,n,w;
void gc(int i){
	sort(1+a,a+1+i,cmp);
	for(int j=1;j<=i;j++){
		if(a[j].score==a[j-1].score)
			a[j].num=a[j-1].num;
		else
			a[j].num=a[j-1].num+1;
		a[j].id=j;
	}
	num=max(1,(i*w/100));
	for(int j=1;j<=i;j++){
		if(a[j].id==num){
			cout<<a[j].score<<" ";
			break;
		}
	}
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>a[i].score;
		gc(i);
	}
	return 0;
}
