#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cout<<9;
	return 0;
}