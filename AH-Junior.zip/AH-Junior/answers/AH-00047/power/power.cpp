#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;
int a[101]={},flag=0,maxx;
int n,step=1,x;
void search(){
	maxx=0;
	for(int i=1;i<=x;i++){
		if(x-pow(2,i)>=0){
			maxx=i;
		}
		if(x-pow(2,i)==0)
			flag=1;
	}
	x-=pow(2,maxx);
	a[step]=pow(2,maxx);
	step++;
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	x=n;
	while(x>0){
		search();
	}
	if(flag){
		for(int i=1;a[i]>0;i++){
			cout<<a[i]<<" ";
		}
	}else
		cout<<"-1";
	return 0;
}