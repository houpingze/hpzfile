#include<iostream>
#include<algorithm>
#include<fstream>
using namespace std;
ifstream fin("live.in");
ofstream fout("live.out");
long long A[1000001]={0},B[1000001]={0},p=0,w;
long long maxx(long long a,long long b)
{
	if(b/100-1==0)
		return 1;
	else
	{
		if(b/100-1<0)
			return 1;
		else
			return b/100-(b%100/100);
	}
}
bool cmp(long long a,long long b)
{
	return a>b;
}
int main()
{
	long long n,i,j=0,man=0,m;
	fin>>n>>w;
	for(i=0;i<n;i++)
	{
		fin>>A[i];
		++p;
		if(maxx(1,p*w==1))
			man=1;
		else
		{
			m=p*w;
			man=m/100-(m%100/100);
		}	
		sort(A,A+i,cmp);
		B[j]=A[man-1];
		++j;
	}
	for(i=0;i<j;i++)
		fout<<B[i]<<" ";
	return 0;
}