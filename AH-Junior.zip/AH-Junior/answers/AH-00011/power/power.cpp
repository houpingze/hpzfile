#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("power.in");
ofstream fout("power.out");
long long A[10000001]={0};
long long f1(int m)
{
	int i,sum=1;
	for(i=0;i<m;i++)
		sum=sum*2;
	return sum;
}
int main()
{
	long long n,i,j=0;
	fin>>n;
	for(i=1;i<=n;i++)
	{
		if(f1(i)==n)
		{
			A[j]=f1(i);
			break;
		}
		if(f1(i)>n && i!=1)
		{
			A[j]=f1(i-1);
			n=n-f1(i-1);
			i=1;
			if(n==1)
			{
				fout<<"-1";
				return 0;
			}
			j++;
		}
	}
	for(i=0;i<j;i++)
		fout<<A[i]<<" ";
	return 0;
}