#include<iostream>
using namespace std;
struct T
{
	long long number;
	long long tap1;
	long long tap2;
};
typedef struct T node;
node A[1001][1001];
long long maxx(lnode A[][])
{
	fo
}
int main()
{
	long long n,m,i,j;
	cin>>n>>m;
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
			cin>>A[i][j].number;
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			
		}
	}
	return 0;
}