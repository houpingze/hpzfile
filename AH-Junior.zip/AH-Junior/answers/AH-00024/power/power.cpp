#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
  freopen("power.in","r",stdin);
  freopen("power.out","w",stdout);
  int a,s=2,x=0;
  cin>>a;
  if(a%2!=0) {cout<<"-1";return 0;}
  while(x>=0)
{
  if(a-s/2%2!=0)  s=s*2;
     else x=a-s;
}
  if(s>x)  cout<<s<<"  "<<x;
    else  
     cout<<x<<"  "<<s;
  return 0;
}