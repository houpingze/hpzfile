#include<bits/stdc++.h>
using namespace std;
int main( )
{
freopen("power.in","r",stdin);
freopen("power.out","w",stdout);
int n;
int m=0;
cin>>n;
if(n%2==0){
m=n-2;
cout<<m<<" "<<"2"<<endl;
	}
	else{
	cout<<"-1"<<endl;
		}
return 0;
}