#include<bits/stdc++.h>
using namespace std;
int a[100005];
int main( )
{
freopen("live.in","r",stdin);
freopen("live.out","w",stdout);
int n,w;
int minn=605;
cin>>n>>w;
for(int i=1;i<=n;i++){
cin>>a[i];
if(i<=n*w*0.01){
	if(a[i]<=minn){
    minn=a[i];
	cout<<minn<<" ";
}
}
}
return 0;
}