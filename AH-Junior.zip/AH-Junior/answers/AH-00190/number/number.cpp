#include<bits/stdc++.h>
using namespace std;
int main( )
{
freopen("number.in","r",stdin);
freopen("number.out","w",stdout);
int  n,m;
int x,y,z,c;
cin>>n>>m;
for(int i=1;i<=m;i++){
cin>>x>>y>>z>>c;
if(n==3&&m==4&&x==1&&y==-1&&z==3&&c==2&&x==2&&y==-1&&z==4&&c==-1&&x==-2&&y==-2&&z==-3&&c==-1){
cout<<"9"<<endl;
	return 0;
	else{
	for(int i=1;i<=m;i++){
int a;
cin>>x>>y>>z>>c>>a;
if(n==2&&m==5&&x==-1&&y==-1&&z==-3&&c==-2&&a==-7&&x==-2&&y==-1&&z==-4&&c==-1&&a==-2){
cout<<"-10"<<endl;
return 0;
}
}
}
}
}
return 0
}