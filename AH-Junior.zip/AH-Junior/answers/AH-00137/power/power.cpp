#include<bits/stdc++.h>
using namespace std;
long long n;
long long s[40],ans[40];
int si;
bool c[40],pd;
void dfs(long long sy,int num)
{
	if(pd==true) return ;
	if(sy==0)
	{
		for(int i=1;i<num;i++) printf("%lld ",ans[i]);
		pd=true;
	}
	for(int i=si;i>=1;i--)
	{
		if(c[i]==false && s[i]<=sy)
		{
			c[i]=true;
			ans[num]=s[i];
			dfs(sy-s[i],num+1);
			c[i]=false;
		}
	}
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%lld",&n);
	if(n%2!=0) 
	{
		printf("-1");
		return 0;
	}
	else
	{
		for(int i=2;i<=n;i*=2) s[++si]=i;
		dfs(n,1);
	}
	if(!pd) printf("-1");
	return 0;
}