#include<bits/stdc++.h>
using namespace std;
int n,w,line,need;
int student[100010],score[610];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++) 
	{
		line=floor(i*w/100);
		if(line<1) line=1;
		need=line;
		scanf("%d",&student[i]);
		score[student[i]]++;
		for(int j=600;j>=0 && need>0;j--) 
		{
			if(score[j]!=0) need-=score[j];
			if(need<=0) printf("%d ",j);
		}
		
	}
	return 0;
}