#include<bits/stdc++.h>
using namespace std;
int n,m,ans=-10010;
long long number[1010][1010];
bool pd[1010][1010];
int dx[4]={0,0,1,-1};
int dy[4]={0,1,0,0};
void dfs(int x,int y,int sum)
{
	pd[x][y]=true;
	if(x==n && y==m) 
	{
		ans=max(ans,sum);
		return ;
	}
	for(int i=1;i<=3;i++)
	{
		int px=x+dx[i];
		int py=y+dy[i];
		if(!pd[px][py] && px<=n && px>=1 && py<=m && py>=1)
		{
			dfs(px,py,sum+number[px][py]);
			pd[px][py]=false;
		}
	}
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++) scanf("%lld",&number[i][j]);
	dfs(1,1,number[1][1]);
	printf("%d",ans);
	return 0;
}