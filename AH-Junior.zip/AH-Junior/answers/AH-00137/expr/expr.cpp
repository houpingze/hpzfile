#include<bits/stdc++.h>
using namespace std;
string s;
int n,ai[100010],bi[100010];
int p,pi;
bool pd;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='&') 
		{
			pd=true;
			break;
		}
		if(s[i]=='|')
		{
			pd=false;
			break;
		}
	}
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>ai[i];
		bi[i]=ai[i];
	}
	cin>>p;
	for(int i=1;i<=p;i++)
	{
		cin>>pi;
		bi[pi]=!bi[pi];
		if(pd==true)
		{
			for(int j=1;j<n;j++) 
			{
				if(bi[j]==0 || bi[j+1]==0) bi[j+1]=0;
					else bi[j+1]=1;
			}
			cout<<bi[n]<<endl;
		}
		else 
		{
			for(int j=1;j<n;j++) 
			{
				if(bi[j]==1 || bi[j+1]==1) bi[j+1]=1;
					else bi[j+1]=0;
			}
			cout<<bi[n]<<endl;
		}
		for(int j=1;j<=n;j++) bi[j]=ai[j];
	}
	return 0;
}
