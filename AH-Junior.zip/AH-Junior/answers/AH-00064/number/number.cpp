#include<iostream>
#include<cstdio>
#include<cstring>
#include<stdio.h>
using namespace std;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	char a[1000];
    int c,d,x,n,m,t=0;
	cin>>n>>m;
    for(int i=1;i<m;i++)
    cin>>a[n][m];
    if(a<t)
	{
		c=t;
		d=x;
		if(t<x)
	}
	else
	{
		c=t;
		x=c;
		if(c<x)
	}
	else
	{
		c=x;
		d=c;
		if(x<d)
	}
	cout<<n<<m<<endl;
	return 0;
        fclose(stdin);
        fclose(stdout);
}
