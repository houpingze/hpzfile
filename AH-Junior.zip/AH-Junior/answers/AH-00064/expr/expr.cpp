#include<iostream>
using namespace std;
int main()
{
  freopen("expr.in","r",stdin);
    freopen("expr.out","w",stdout);
   cout<<"0";
   return 0;
   fclose(stdin);
   fclose(stdout);
}
