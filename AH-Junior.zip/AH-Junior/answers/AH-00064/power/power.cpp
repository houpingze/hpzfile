#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
bool cmp
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	char a[1000],b[1000];
	int n;
	cin>>n;
	for(int i=0;i<=n;i++)
	  for(int t=0;t<=i;t++)
	if(a[i]%2==0&&b[i]%2==0)
	cout<<a<<b;
      if(a[i]+a[t]=n)&&(a[i]%4==0)&&(a[i]/4==0)
        cout<<a[i]<<a[t];
	return 0;
	fclose(stdin);
	fclose(stdout);
}
