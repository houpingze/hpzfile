#include<cstdio>
using namespace std;
int n,m,sum;
int Map[1007][1007];
bool marked[1007][1007];
int x_way[]={-1,1,0};
int y_way[]={0,0,1};
bool is_avail(int x,int y)
{
	if(x<0||y<0||marked[x][y]||x>m||y>m) return false;
	return true;
}
void dfs(int x,int y)
{
	for(int i=0;i<4;i++)
	{
		if(x==n-1&&y==m-1)
		{
			return;
		}
		else
		{
			sum=0;
		}
		sum+=Map[x][y];
		if(is_avail(x+x_way[i],y+y_way[i]))
		{
			marked[x+x_way[i]][y+y_way[i]]=true;
			dfs(x+x_way[i],y+y_way[i]);
		}
	}
}
int main()
{
	freopen("number3.in","r",stdin);
	freopen("number3.ans","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++) scanf("%d",&Map[i][j]);
	dfs(0,0);
	printf("%d\n",sum);
	return 0;
}