#include<cstdio>
#include<algorithm>
using namespace std;
bool cmp(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live3.ans","w",stdout);
	int n,w;
	scanf("%d%d",&n,&w);
	int a[100007];
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	printf("%d ",a[1]);
	for(int i=2;i<=n;i++)
	{
		sort(&a[1],a+i+1,cmp);
		printf("%d ",a[i*w/100]);
	}
	return 0;
}
