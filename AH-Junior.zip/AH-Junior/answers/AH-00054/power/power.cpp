#include<cstdio>
using namespace std;
int a[1000]={1};
int n;
bool tmp=false,flag=false;
bool panduan(int x)
{
	if(x==1)return false;
	while(x%2==0)
	{
		x/=2;
	}
	if(x==1)return true;
	return false;
}
void match(int t)
{
	for(int i=1;i<t;i++)
	{
		for(int j=i+1;j<=t;j++)
		{
			if(a[i]==a[j])return;
		}
	}
	for(int i=1;i<=t;i++)
	{
		if(panduan(a[i]))
		{
			tmp=true;
		}
		else {
			tmp=false;
			break;
		}
	}
	if(tmp){
		for(int i=1;i<t;i++) printf("%d ",a[i]);
		printf("%d",a[t]);
		printf("\n");
		flag=true;
	}
}
void dfs(int s,int t)
{
	for(int i=a[t-1];i<=s;i++)
	{
		if(i<n)
		{
			a[t]=i;
			s-=i;
			if(s==0)match(t);
			else dfs(s,t+1);
			s+=i;
		}
	}
}
int main()
{
	freopen("power3.in","r",stdin);
	freopen("power3.ans","w",stdout);
	scanf("%d",&n);
	dfs(n,1);
	if(!flag)printf("-1\n");
	return 0;
}