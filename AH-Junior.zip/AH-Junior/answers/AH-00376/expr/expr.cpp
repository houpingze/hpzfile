#include<bits/stdc++.h>
using namespace std;
#define reg register
#define rd io :: read
#define gtc io :: gtc
const int N = 1e7;
struct Node {
  int op, c, val, rev, ls, rs;
} tr[N];
char str[N];
int n, q, len, x[N], idx[N], id, ptr;
void build(int k) {
  while (id && isspace(str[id])) --id;
  while (id && str[id] == '!') {
    tr[k].rev ^= 1, --id;
    while (id && isspace(str[id])) --id;
  }
  while (id && isspace(str[id])) --id;
  if (!id) return ;
  if (isdigit(str[id])) {
    int tmp = 0, bas = 1;
    while (id && isdigit(str[id])) tmp += (str[id] - '0') * bas, bas *= 10, --id;
    idx[tmp] = k, tr[k].val = x[tmp] ^ tr[k].rev;
    tr[k].c = 0;
    return ;
  }
  tr[k].ls = ++ptr, tr[k].rs = ++ptr;
  char tp = str[id--]; tr[k].c = tp;
  build(tr[k].ls), build(tr[k].rs);
  if (tp == '&') tr[k].val = tr[tr[k].ls].val & tr[tr[k].rs].val;
  else tr[k].val = tr[tr[k].ls].val | tr[tr[k].rs].val;
  tr[k].val ^= tr[k].rev;
}
void calc(int k) {
  if (!tr[k].c) return ;
  if (tr[k].op == 2) {
    tr[tr[k].ls].op = tr[tr[k].rs].op = 2;
    calc(tr[k].ls), calc(tr[k].rs);
    return ;
  }
  if (tr[k].c == '&') {
    tr[tr[k].ls].op = tr[tr[k].rs].val == 0 ? 2 : tr[k].op, tr[tr[k].rs].op = tr[tr[k].ls].val == 0 ? 2 : tr[k].op;
  }
  else {
    tr[tr[k].ls].op = tr[tr[k].rs].val == 1 ? 2 : tr[k].op, tr[tr[k].rs].op = tr[tr[k].ls].val == 1 ? 2 : tr[k].op;
  }
  calc(tr[k].ls), calc(tr[k].rs);
}
int main() {
  freopen("expr.in", "r", stdin);
  freopen("expr.out", "w", stdout);
  reg char ch;
  while (ch = getchar(), (!isspace(ch) || ch == ' '))
    if (ch != 'x') str[++len] = ch;
  scanf("%d", &n);
  for (reg int i = 1; i <= n; ++i) scanf("%d", x + i);
  id = len, build(++ptr);
  tr[1].op = 1;
  calc(1);
  int ans = tr[1].val;
  scanf("%d", &q);
  for (reg int i = 1; i <= q; ++i) {
    int t; scanf("%d", &t);
    int tt = idx[t];
    if (tr[tt].op == 2) printf("%d\n", ans);
    else printf("%d\n", ans ^ 1);
  }
  return 0;
}
