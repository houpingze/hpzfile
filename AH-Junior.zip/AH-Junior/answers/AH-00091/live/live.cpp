#include<stdio.h>
#include<algorithm>
using namespace std;
struct Node{
	int x,i;
	}a[100005];
inline int read()
{
	int x=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		c=getchar();
		
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
		}
	return x;
}
inline bool cmpx(Node a,Node b)
{
	return a.x>b.x;
	}
	
inline bool cmpi(Node a,Node b)
{
	return a.i>b.i;
	}	
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	
	int n,w,i,j;
	n=read();
	w=read();
	for(i=1;i<=n;i++)
	{
		a[i].x=read();
		
		sort(a+1,a+i+1,cmpx);
		if(i*w/100<1)printf("%d ",a[i*w/100+1].x);
			else printf("%d ",a[i*w/100].x);
		//sort(a+1,a+i,cmpi);
		}
	
	return 0;
}