#include<stdio.h>
#include<algorithm>
#include<math.h>
#include<string.h>
#include<string>
using namespace std;
int a[1005][1005];
bool f[1005][1005];
int n,m,ans=-2147483646;
void dfs(int x,int y,int now)
{
	int i,j;
	int d[3][2]={{-1,0},{1,0},{0,1}};
	if(x==n&&y==m)
	{
		ans=max(ans,now);
		return ;
		}
	if(x<1)return ;
	if(y<1)return ;
	if(x>n)return ;
	if(y>m)return ;
	
	for(i=0;i<3;i++)
	{
		if(f[x+d[i][0]][y+d[i][1]]!=true)
		{
			f[x+d[i][0]][y+d[i][1]]=true;
			dfs(x+d[i][0],y+d[i][1],now+a[x+d[i][0]][y+d[i][1]]);
			f[x+d[i][0]][y+d[i][1]]=false;
			}
	}
}
int main(){

	int i,j;
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	memset(f,0,sizeof(f));
	scanf("%d%d",&n,&m);
	
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	dfs(1,1,a[1][1]);
	
	printf("%d",ans);
}