#include<stdio.h>
#include<iostream>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<string>
using namespace std;
int a[5005],ans[5005];
inline int read()
{
	int x=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		c=getchar();
		
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
		}
	return x;
}
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	
	int n,i,j;
	n=read();
	
	a[0]=0;a[1]=1;a[2]=2;
	
	i=2;
	
	while(a[i-1]<=10000007)
	{
		a[i]=a[i-1]*2;
		
		i++;
		}
	i-=1;
	j=1;
	while(i>1)
	{
		if(n>=a[i])
		{ans[j]=a[i];
			j++;
			n-=a[i];
			
		}
			i--;
		
	}
	if(n>0)puts("-1");
	else {
		for(i=1;i<j;i++)printf("%d ",ans[i]);
		}
	return 0;
}