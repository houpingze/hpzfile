#include<bits/stdc++.h>
using  namespace std;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n=0,b=0,c=0,sb=0;
	cin>>n;
	int a[n],bfb=0;
	cin>>bfb;
	bfb=bfb/10;
	for(int h=0;h<n;h++){
		cin>>a[h];
		for(int i=0;i<h;i++){
		if(h==0){break;}
		for(int j=0;j<h;j++){
			
			if(a[j]<a[j+1]){
				b=a[j];
				c=a[j+1];
				a[j+1]=b;
				a[j]=c;
				}
			}
		
		}
		//for(int y=0;y<h+1;y++){cout<<a[y]<<" ";}cout<<endl;
		
		
		sb=h*bfb/10;
		if(sb*10<h*bfb){sb=sb+1;}
		if(sb>h){cout<<a[h]<<" ";}else{cout<<a[sb]<<" ";}
	}
	
	return 0;
	}