#include<bits/stdc++.h>
using  namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	long long a=0,n=1,j=0,b=2;
	cin>>a;
	if(a%2==1){
		cout<<-1;
	}else{
		
		while(a>0){
			a=a-b;
			b=b*2;
			n=n+1;
			if(a==0){
				j=1;
				break;
			}
			if(a<0){
				cout<<-1;
				break;
				}

			}
		}
	b=2;
	int d[n];
	if(j==1){
		for(int i=1;i<n;i++){
			d[i]=b;
			b=b*2;
			
			}
		}
		for(int i=n-1;i>0;i--){
			cout<<d[i]<<" ";
			}
	
	
	return 0;
	}