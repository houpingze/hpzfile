#include<bits/stdc++.h>
using namespace std;
char a[100];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out"."w",stdout);
	int b,c,d,e,f,g,h,i;
	puts(a);
	cin>>b;
	cin>>c>>d>>e;
	cin>>f;
	cin>>g;
	cin>>h;
	cin>>i;
	cout<<'1'<<'\n'<<'1'<<<<'\n'<<'0';
	return 0;
}