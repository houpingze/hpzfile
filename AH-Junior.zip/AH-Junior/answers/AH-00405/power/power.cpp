#include<bits/stdc++.h>
using namespace std;
long long a[1024];
int main()
{
	freopen("power.in","r",stdin);
	freoprn("power.out","w",stdout);
	long long n,b=-1,c=0,i,m=0,y=0;
	for(i=n-1;i>0;i--)
	{
		for(long longj=i;j%2==0;j/=20)
			if(b>=j/2)
			{
				c+=i;
				a[m]=i;
				m++;
				break;
			}
			b++;
	}
	if(c==n)
	{
		for(int j=0;j<m;j++
			if(j<m-1)
			cout<<a[j]<<" ";
			else
			cout<<a[j];
	}
	else
	{
		if(c>n)
		{
			y=c-n;
			for(int j=0;j<m;j++)
			{
				if(a[=j]==y)
					for(int z=j;z<m;z++)
						a[z]=a[z+1];
					m--; 
			}
			for(int j=0;j<m;j++)
				if(j<m-1)
					cout<<a[j]<<" ";
				else
					cout<<a[j];
		}
	}
	return 0;
}	