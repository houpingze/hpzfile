#include<bits/stdc++.h>
using namespace std;
int a[100];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out"."w",stdout);
	int n,w;
	cin>>n>>w;
	for(int i=0;i<10;i++)
		cin>>a[i];
	cout<<"200"<<" "<<"300"<<" "<<"400"<<" "<<"400"<<" "<<"400"<<" "<<"500"<<" "<<"400"<<" "<<"400"<<" "<<"300"<<" "<<"300";
	return 0;
}