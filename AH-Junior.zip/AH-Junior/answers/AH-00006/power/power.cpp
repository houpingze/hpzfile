#include<stdio.h>
using namespace std;
int ans[105],sum=0;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n%2){
		printf("-1");return 0;
	}
	int pow=1,i;
	while(pow*2<=n){
		pow*=2;
	}
	while(n&&pow>1){
		if(pow<=n){
			n-=pow;ans[++sum]=pow;
		}
		pow/=2;
	}
	if(n){
		printf("-1");
	}
	else{
		for(i=1;i<=sum;i++){
			printf("%d ",ans[i]);
		}
	}
	return 0;
}