#include<stdio.h>
#include<map>
using namespace std;
map<int,int> a;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,m,k,i,now,sum;
	scanf("%d%d",&n,&m);
	scanf("%d",&k);a[k]++;now=k;sum=1;
	map<int,int>::iterator it=a.begin();
	printf("%d ",now);
	for(i=2;i<=n;i++){
		scanf("%d",&k);
		a[k]++;
		if(k>=now)sum++;
		int p=i*m/100;
		if(p<1)p=1;
		while(sum-a[now]+1>p){//up
			sum=sum-(it->second);it++;now=it->first;
		}
		while(sum+1<=p){//down
			it--;now=it->first;sum=sum+(it->second);
		}
		printf("%d ",now);
	}
	return 0;
}