#include<stdio.h>
using namespace std;
int a[1000005][2],c[100005][2],d[1000005];
struct node{
	int bh1,bh2,f1,f2,ys,jg,cx;//bian hao,flag(shi fou wei yun suan shi zi),yun suan fu,yuan lai jie guo,zai na chu xian le
}b[1000005];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int n,i,k,top=0,sum=0;
	char c1=getchar();
	while(c1!='\n'){//jian yun suan shi zi
		while(c1==' '){
		 	c1=getchar();
		}
		if(c1=='\n'){
			break;
		}
		if(c1=='x'){
			scanf("%d",&k);
			a[++top][0]=k;a[top][1]=0;
		}
		if(c1!='x'&&c1!=' '&&c1!='\n'){
			if(c1=='!'){
				b[++sum].bh1=a[top][0];b[sum].f1=a[top][1];b[sum].ys=3;
				if(a[top][1])b[a[top][0]].cx=sum;//mou yun suan shi zai $sum$ zhong chu xian le
				else c[a[top][0]][1]=sum;//mou shi zai $sum$zhong chu xian le
				a[top][0]=0;a[top--][1]=0;
				a[++top][0]=sum;a[top][1]=1;
			}
			if(c1=='&'){
				b[++sum].bh1=a[top][0];b[sum].f1=a[top][1];b[sum].ys=2;
				if(a[top][1])b[a[top][0]].cx=sum;//mou yun suan shi zai $sum$ zhong chu xian le
				else c[a[top][0]][1]=sum;//mou shi zai $sum$zhong chu xian le
				a[top][0]=0;a[top--][1]=0;
				b[sum].bh2=a[top][0];b[sum].f2=a[top][1];
				if(a[top][1])b[a[top][0]].cx=sum;//mou yun suan shi zai $sum$ zhong chu xian le
				else c[a[top][0]][1]=sum;//mou shi zai $sum$zhong chu xian le
				a[top][0]=0;a[top--][1]=0;
				a[++top][0]=sum;a[top][1]=1;
			}
			if(c1=='|'){
				b[++sum].bh1=a[top][0];b[sum].f1=a[top][1];b[sum].ys=1;
				if(a[top][1])b[a[top][0]].cx=sum;//mou yun suan shi zai $sum$ zhong chu xian le
				else c[a[top][0]][1]=sum;//mou shi zai $sum$zhong chu xian le
				a[top][0]=0;a[top--][1]=0;
				b[sum].bh2=a[top][0];b[sum].f2=a[top][1];
				if(a[top][1])b[a[top][0]].cx=sum;//mou yun suan shi zai $sum$ zhong chu xian le
				else c[a[top][0]][1]=sum;//mou shi zai $sum$zhong chu xian le
				a[top][0]=0;a[top--][1]=0;
				a[++top][0]=sum;a[top][1]=1;
			}
		}
		c1=getchar();
	}
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&c[i][0]);
	}
	for(i=1;i<=sum;i++){//yun suan yuan shi jie guo
		if(b[i].ys==3){
			if(b[i].f1==0)b[i].jg=!(c[b[i].bh1][0]);
			if(b[i].f1==1)b[i].jg=!(b[b[i].bh1].jg);
		}
		else{
			int h1,h2;
			if(b[i].f1)h1=b[b[i].bh1].jg;
			else h1=c[b[i].bh1][0];
			if(b[i].f2)h2=b[b[i].bh2].jg;
			else h2=c[b[i].bh2][0];
			if(b[i].ys==2)b[i].jg=h1&h2;
			if(b[i].ys==1)b[i].jg=h1|h2;
		}
		//printf("%d %d %d %d %d %d %d\n",b[i].bh1,b[i].bh2,b[i].f1,b[i].f2,b[i].ys,b[i].cx,b[i].jg);
	}
	int m;
	scanf("%d",&m);
	for(i=1;i<=m;i++){
		scanf("%d",&k);
		int now=!c[k][0],wz=c[k][1],bh=k,f=0,flag=0;
		while(wz){
			int h3;
			if(b[wz].bh1==bh&&b[wz].f1==f){
				if(b[wz].f2)h3=b[b[wz].bh2].jg;
				else h3=c[b[wz].bh2][0];
			}
			if(b[wz].bh2==bh&&b[wz].f2==f){
				if(b[wz].f1)h3=b[b[wz].bh1].jg;
				else h3=c[b[wz].bh1][0];
			}
			if(b[wz].ys==3){
				now=!now;
			}
			if(b[wz].ys==2){
				now=now&h3;
			}
			if(b[wz].ys==1){
				now=now|h3;
			}
			if(now==b[wz].jg){
				flag=1;break;
			}
			//printf("%d %d %d %d\n",wz,f,h3,now);
			bh=wz;wz=b[wz].cx;f=1;
		}
		if(flag)printf("%d\n",b[sum].jg);
		else printf("%d\n",now);
	}
	return 0;
}