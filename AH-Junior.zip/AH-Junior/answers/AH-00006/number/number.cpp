#include<stdio.h>
using namespace std;
int a[1005][1005],n,m,f[1005][1005],ans=-2147483647;
void DFS(int x,int y,int sum){
	if(x<1||y<1||x>n||y>m||f[x][y])return;
	//printf("%d %d %d\n",x,y,f[x][y]);
	f[x][y]=1;
	if(x==n&&y==m){
		if(sum>ans)ans=sum;
		f[x][y]=0;
		return;
	}
	DFS(x+1,y,sum+a[x+1][y]);
	DFS(x-1,y,sum+a[x-1][y]);
	DFS(x,y+1,sum+a[x][y+1]);
	f[x][y]=0;
	return;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	int i,j;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++){
		for(j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
			f[i][j]=0;
		}
	}
	DFS(1,1,a[1][1]);
	printf("%d",ans);
	return 0;
}