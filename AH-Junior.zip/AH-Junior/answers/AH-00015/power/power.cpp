#include<bits/stdc++.h>

#include<cstdio>
#include<cstdlib>
#include<iostream>
using namespace std;

long long n,i,l,q,can=1,b[24]={1,0},c[24];

int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	
	for(i=1;i<=23;i++)
		b[i]=b[i-1]*2;
	
	scanf("%lld",&n);
	for(i=1;i<=23;i++)
	{
		if(n==b[i])
		{
			printf("%lld",n);
			return 0;
		}
	}
	
	for(i=1;i<=23&&n>0;i++)
	{
		for(l=1;l<=23;l++)
		{
			for(q=1;q<=23;q++)
					{
					if(n-b[i]==b[l]-b[q]&&n>0)
					{
						n=n-b[i];
						c[can]=b[i];
						can++;
					}
				}
		}
	}
	
	if(n==0)
	{
		for(i=can-1;i>=1;i--)
			printf("%lld ",c[i]);
		return 0;
	}
	
	printf("-1");
	return 0;
}
