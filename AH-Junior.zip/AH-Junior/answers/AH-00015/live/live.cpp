#include<bits/stdc++.h>

#include<cstdio>
#include<cstdlib>
#include<iostream>
using namespace std;

int l;
int n,w,i,can;
int a[21];

int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	
	scanf("%d%d",&n,&w);

	for(i=1;i<=n;i++)
		scanf("%d",&a[i]);
	
for(i=1;i<=n;i++)
	{
		sort(a+1,a+1+i);
		can=i*w/100;
		if(can==0)
			can=1;	
		printf("%d ",a[i+1-can]);
	}

	return 0;
}

