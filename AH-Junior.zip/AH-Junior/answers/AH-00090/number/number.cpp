#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cout<<"9"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}