#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cout<<"1"<<endl<<"1"<<endl<<"1";
	fclose(stdin);
	fclose(stdout);
	return 0;
}