#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n;
	cin>>n;
	if(n==0){
		cout<<-1;
		return 0;
		}
	if(n%2==1){
		cout<<-1;
		return 0;
	}
	long long s=2;
	while(s<n)s*=2;
	while(n>0){
		while(s>n)s/=2;
		cout<<s<<' ';
		n-=s;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}