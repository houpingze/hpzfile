#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int cnt[601];
	for(int i=0;i<=600;i++)cnt[i]=0;
	int n,w;
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		int p;
		p=max(1,i*w/100);
		int t;
		scanf("%d",&t);
		cnt[t]++;
		int len=0,num=t;
		for(int j=600;j>=0;j--){
			if(cnt[j]){
				len+=cnt[j];
				num=j;
			}
			if(len>=p)break;
		}
		cout<<num<<' ';
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}