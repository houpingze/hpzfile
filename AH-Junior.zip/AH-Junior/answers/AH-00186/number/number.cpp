#include<bits/stdc++.h>
using namespace std;
int t[301][301],ans=-INT_MAX,n,m;
bool vis[301][301];
void dfs(int x,int y,int s){
	if(x<1||x>n||y<1||y>m||vis[x][y])return ;
	if(x==n&&y==m){
		ans=max(ans,s+t[n][m]);
		return;
	}
	vis[x][y]=1;
	dfs(x+1,y,s+t[x][y]);
	dfs(x-1,y,s+t[x][y]);
	dfs(x,y+1,s+t[x][y]);
	vis[x][y]=0;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)cin>>t[i][j];
	dfs(1,1,0);
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}