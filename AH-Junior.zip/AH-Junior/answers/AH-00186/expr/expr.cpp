#include<bits/stdc++.h>
using namespace std;
int x[10001];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int n;
	bool flag=0;
	char c;
	while(c=cin.get())if(c=='|')flag=1;
	if(flag){
		for(int i=1;i<=n;i++)cin>>x[i];
		int q;
		cin>>q;
		for(int i=1;i<=q;i++){
			int id;
			cin>>id;
			x[id]=!x[id];
			bool ok=0;
			for(int j=1;j<=n;j++)if(x[j])ok=1;
			cout<<ok<<'\n';
			x[id]=!x[id];
		}
	}
	else {
		for(int i=1;i<=n;i++)cin>>x[i];
		int q;
		cin>>q;
		for(int i=1;i<=q;i++){
			int id;
			cin>>id;
			x[id]=!x[id];
			bool ok=1;
			for(int j=1;j<=n;j++)if(!x[j])ok=0;
			cout<<ok<<'\n';
			x[id]=!x[id];
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}