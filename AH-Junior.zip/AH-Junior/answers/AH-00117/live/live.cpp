#include<bits/stdc++.h>
using namespace std;
int po[100005];
int cmp(int a,int b){
	return a>b;
	}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int n,w,t;
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		cin>>po[i];
		t=max(1,(i*w)/100);
	    sort(po+1,po+1+n,cmp);
	    cout<<po[t]<<" ";
	}
     
	
	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
	
	
	
	
	}