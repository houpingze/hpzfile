#include<iostream>
#include<cstdio>
using namespace std;
int a[24]={16777216,8388608,4194304,2097152,1048576,524288,262144,131702,65536,32768,16384,8192,4096,2048,1024,512,256,128,64,32,16,8,4,2};
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long n;
	cin>>n;
	if(n%2!=0){
		cout<<"-1";
	}else{
		for(int i=0;i<24;i++){
			if(n<2){
				break;
			}
			if(n>=a[i]){
				n=n-a[i];
				cout<<a[i]<<" ";
			}
			
		}
		
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
	
	}