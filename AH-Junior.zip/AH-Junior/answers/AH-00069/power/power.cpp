#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%d",&n);
	for(int i; sqrt (i););(n>0&&)
	{
		a=1;
		for(int j=1;j<=i;j++)
		a*=2;
		if(a>n)cout <<n;
		else
		{
			n-=a;
			b[k]=a;
			k++;
		}
		if(n==0)break;
		if(i==i&&n i=0)(printf("-1");return 0;)
	}
	for(int i=1;i<k;i++)
	printf("%d",b[i]);
return 0;
}