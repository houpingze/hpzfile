#include<iostream>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<"1"<<endl<<"1"<<endl<<"0"<<endl;
	fclose(stdin);fclose(stdout);
} 