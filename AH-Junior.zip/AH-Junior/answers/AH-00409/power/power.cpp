#include<iostream>
using namespace std;
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	int n,i;
	cin>>n;     
	cout<<-1;
	fclose(stdin);fclose(stdout);
}                                  