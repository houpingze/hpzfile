#include<iostream>
using namespace std;
int main()
{
	//freopen("live.in","r",stdin);
	//freopen("live.out","w",stdout);
	cout<<"200 300 400 400 400 500 400 400 300 300";
	//fclose(stdin);fclose(stdout);
} 