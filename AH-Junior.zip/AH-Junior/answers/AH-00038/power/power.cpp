#include<iostream>
#include<cstdio>
using namespace std;
int n,a[40],b[40],k,v;
int da(int x){
	int ans=1;
	for(int i=1;i<=x;i++){ans*=2;}
	return ans;
}
bool dfs(int x,int t){
	if(x==0)	return true;
	for(int i=t-1;i>=1;i--){
		b[++k]=a[i];
		if(dfs(x-b[k],i))	return true;
		b[k--]=0;
	}
	return false;
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	while(1){
		a[++v]=da(v);
		if(a[v]>n)	break;
	}
	if(dfs(n,v)){
		for(int i=1;i<=k;i++)	cout<<b[i]<<' ';
	}
	else{
		cout<<-1;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}