#include<iostream>
#include<cstdio>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
bool f[1005][1005],tip;
int a[1005][1005],n,m,vis[5][2]={
	{0,0},{1,0},{0,1},{-1,0}
};
long long dfs(long long sum,int x,int y){
	if(x==n&&y==m)	return sum;
	long long ans=-INF;
	bool k=false;
	int dx=0,dy=0;
	for(int i=1;i<=3;i++){
		if(y+vis[i][1]<=m&&x+vis[i][0]<=n &&x+vis[i][0]>=1&&!f[x+vis[i][0]][y+vis[i][1]]){
			f[x+vis[i][0]][y+vis[i][1]]=true;
			f[dx][dy]=false;
			long long t=dfs(a[x+vis[i][0]][y+vis[i][1]],x+vis[i][0],y+vis[i][1]);
			if(t<ans){
				f[dx][dy]=true;
				f[x+vis[i][0]][y+vis[i][1]]=false;
			}
			else{
				k=true;
				ans=t;
				dx=x+vis[i][0],dy=y+vis[i][1];
			}
		}
	}
	f[0][0]=false;
	if(k==false)	return -INF;
	return sum+ans;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
		}
	}
	f[1][1]=true;
	cout<<dfs(a[1][1],1,1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}