#include<iostream>
#include<cstdio>
using namespace std;
bool cmp(int x,int y){
	return x>y;
}
int n,w,a[610];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++){
		int t,pos=0;
		bool flag=0;
		cin>>t;
		a[t]++;
		int vis=max((int)(i*w/100.0),1);
		for(int j=600;j>=1;j--){
			vis-=a[j];
			if(vis<=0){
				cout<<j<<' ';
				flag=1;
				break;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}