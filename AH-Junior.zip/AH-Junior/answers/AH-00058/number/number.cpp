#include <cstdio>
#include <cstring>
const long long inf=1000000000000ll;

int n,m;
int dx[5]={-1,0,1},dy[5]={0,1,0};
long long a[1005][1005],ans=-inf;
bool vis[1005][1005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

long long Max(long long x,long long y){
	return x>y?x:y;
}

void dfs(int x,int y,long long s){
	if(x==n && y==m){
		ans=Max(ans,s);
		return;
	}
	for(int dir=0;dir<3;++dir){
		int xx=x+dx[dir],yy=y+dy[dir];
		if(xx<1 || xx>n || yy<1 || yy>m || vis[xx][yy])continue;
		vis[xx][yy]=1;
		dfs(xx,yy,s+a[xx][yy]);
		vis[xx][yy]=0;
	}
	return;
}

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			a[i][j]=read();
		}
	}
	vis[1][1]=1;
	dfs(1,1,a[1][1]);
	printf("%lld",ans);
	return 0;
}