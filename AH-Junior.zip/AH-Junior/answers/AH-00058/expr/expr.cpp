#include <cstdio>
#include <cstring>

int n,m,q,ans,top;
int st[100005][3],ch[1000005];
char s[100005];
bool a[100005],e[100005];
int t[100005];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int StoI(int fr){
	int ret=0;
	for(int i=fr;s[i];++i){
		ret=ret*10+s[i]-'0';
	}
	return ret;
}

int Max(int x,int y){
	return x>y?x:y;
}

int Min(int x,int y){
	return x>y?y:x;
}

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	while(1){
		scanf("%s",s+1);
		if(s[1]>='0' && s[1]<='9'){
			m=StoI(1);
			break;
		}
		if(s[1]=='x'){
			int tmp=StoI(2);
			ch[++n]=tmp;
			continue;
		}
		if(s[1]=='|'){
			ch[++n]=-1;
		}
		if(s[1]=='&'){
			ch[++n]=-2;
		}
		if(s[1]=='!'){
			ch[++n]=-3;
		}
	}
	for(int i=1;i<=m;++i){
		a[i]=read();
	}
	for(int i=1;i<=n;++i){
		if(ch[i]>0){
			st[++top][0]=a[ch[i]];
			st[top][1]=ch[i];
			continue;
		}
		if(ch[i]==-3){
			st[top][0]=!st[top][0];
			continue;
		}
		if(ch[i]==-2){
			int x=st[top][0],y=st[top-1][0];
			if(x==0 && y==0){
				int ii=st[top][1],jj=st[top][1];
				if(ii){
					e[ii]=1;
				}
				if(jj){
					e[jj]=1;
				}
			}
			top-=2;
			st[++top][0]=(x&y);
			st[top][1]=0;
			continue;
		}
		if(ch[i]==-1){
			int x=st[top][0],y=st[top-1][0];
			if(x==1 && y==1){
				int ii=st[top][1],jj=st[top][1];
				if(ii){
					e[ii]=1;
				}
				if(jj){
					e[jj]=1;
				}
			}
			top-=2;
			st[++top][0]=(x|y);
			st[top][1]=0;
			continue;
		}
	}
	ans=st[top][0];
	q=read();
	while(q--){
		int x=read();
		if(t[x]){
			printf("%d\n",t[x]-1);
			continue;
		}
		if(e[x]){
			printf("%d\n",ans);
			continue;
		}
		a[x]=!a[x];
		top=0;
		for(int i=1;i<=n;++i){
			if(ch[i]>0){
				st[++top][0]=a[ch[i]];
				st[top][1]=ch[i];
				continue;
			}
			if(ch[i]==-3){
				st[top][0]=!st[top][0];
				continue;
			}
			if(ch[i]==-2){
				int x=st[top][0],y=st[top-1][0];
				top-=2;
				st[++top][0]=(x&y);
				st[top][1]=0;
				continue;
			}
			if(ch[i]==-1){
				int x=st[top][0],y=st[top-1][0];
				top-=2;
				st[++top][0]=(x|y);
				st[top][1]=0;
				continue;
			}
		}
		printf("%d\n",st[top][0]);
		a[x]=!a[x];
		t[x]=st[top][0]+1;
	}
	return 0;
}
