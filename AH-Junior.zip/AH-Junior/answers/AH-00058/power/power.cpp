#include <cstdio>

int n,ai;
int a[105];

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Pow2(int x,int y){
	int ret=1;
	while(y){
		if(y&1){
			ret*=x;
		}
		x*=x;
		y>>=1;
	}
	return ret;
}

int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	n=read();
	if(n%2==1){
		printf("-1");
		return 0;
	}
	while(n){
		a[++ai]=n%2;
		n/=2;
	}
	for(int i=ai;i;--i){
		if(a[i]){
			printf("%d ",Pow2(2,i-1));
		}
	}
	return 0;
}