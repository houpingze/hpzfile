#include <cstdio>
#include <set>
#include <utility>
#include <iostream>
using namespace std;
multiset < int,greater<int> > q;

int n,w,l;

inline int read(){
	int s=0,f=1;char c=getchar();
	while(c<'0' || c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0' && c<='9'){
		s=(s<<3)+(s<<1)+c-'0';
		c=getchar();
	}
	return s*f;
}

int Max(int x,int y){
	return x>y?x:y;
}

int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	n=read(),w=read();
	int x=read();
	q.insert(x);
	multiset <int>:: iterator it=q.begin();
	l=1;
	printf("%d ",x);
	for(int i=2;i<=n;++i){
		x=read();
		q.insert(x);
		int pos=Max(1,i*w/100);
		if(pos>l){
			if(*it>=x){
				++it;
				printf("%d ",*it);
			}else {
				printf("%d ",*it);
			}
			l=pos;
		}else {
			if(*it>=x){
				printf("%d ",*it);
			}else {
				--it;
				printf("%d ",*it);
			}
		}
	}
	return 0;
}