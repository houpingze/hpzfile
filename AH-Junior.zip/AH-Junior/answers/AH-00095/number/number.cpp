#include<bits/stdc++.h>
using namespace std;
int[n,m];
int main()
{ 
	//freopen("number.in","r",stdin)
	//freopen("number.out","w",,stdout)
	int n,m;
    	
	return 0;
	}