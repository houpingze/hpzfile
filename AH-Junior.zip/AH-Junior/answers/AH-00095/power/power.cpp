#include<bits/stdc++.h>
using namespace std;

int main()	
{
freopen("power.in","r",stdin)
freopen("power.out","w",stdout)
	int n,m;
	cin>>n,m;
	if(n/4==0)
		for(int n=2;n<=1024;++n)
			cout<<n<<" "<<;
	else
		n%2!=0
		cout<<"-1"<<;
		return 0;
}
