#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("expr.in","r",stdin)
	//freopen("expr.out","w",stdout)
	int a,b,s,n,i,q;
	
	
	return 0;
	}