#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("live.in","r",stdin)
	//freopen("live.out","w",stdout)
	int a,b,w,n;
	cin>>a>>b;
	int a[n+1];
		
	return 0;
	}