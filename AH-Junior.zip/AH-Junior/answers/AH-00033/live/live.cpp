#include <bits/stdc++.h>
using namespace std;

int a[100001],b[100001];

int main(){
	freopen ("live.in","r",stdin);
	freopen ("live.out","w",stdout);
	int p,w;
	scanf("%d%d",&p,&w);
	
	for(int i=1;i<=p;i++){
		scanf("%d",&a[i]);
		sort(a+1,a+p+1);
		b[i]=max(1,i*w/100);
		cout<<a[p-b[i]+1]<<" ";
	}
	return 0;
}
