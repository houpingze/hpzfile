#include <bits/stdc++.h>
using namespace std;
int a[100];
int sum;
void power(int num){
    int t=2;	
	for(int i=0;i<=num;i++){
	    if(num==0) return;
		if(num%t==0){
			num=num-t;
			a[i]=t;
			t=t*2;
			sum++;
		}
		else {
			t=t*2;
		}
		if(t>num&&num!=0){cout<<"-1";exit(0);}
	}
		
}
int main(){
	freopen ("power.in","r",stdin);
	freopen ("power.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n%2!=0) printf("-1\n");
	else{
		power(n);
	}

	for(int i=sum;i>=0;i--){
		if(a[i]!=0) printf("%d ",a[i]);
	}
	return 0;
}

