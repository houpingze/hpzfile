#include<bits/stdc++.h>
using namespace std;
int a[1010][1010],n,m;
long long ans=-2147483646;
long long dp[1010][1010][3];
/*int doit(int last,int x,int y,long long sum)
{
	//cout<<"?"<<last<<"?";
	if(x==n&&y==m)
	{
		ans=max(ans,sum+a[x][y]);
	//	cout<<"!\n";
		return 0;
	}
	if(last==0||last==1)
	{
		if(x>1)
		{
			//cout<<x-1<<" "<<y<<"\n";
		doit(1,x-1,y,sum+a[x][y]);
		}
	}
	if(last==0||last==2)
		if(x<n)
		{//cout<<x+1<<" "<<y<<"\n";
			doit(2,x+1,y,sum+a[x][y]);
		}
	if(y<m)
	{//cout<<x<<" "<<y+1<<"\n";
		doit(0,x,y+1,sum+a[x][y]);
	}
	return 0;
}*/
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int i2=1;i2<=m;i2++)
		{
			cin>>a[i][i2];
		}
	}
	/*for(int i=1;i<=n;i++)
	{
		for(int j=0;j<=2;j++)
		{
			dp[i][0][j]=-2147483646;
			dp[0][i][j]=-2147483646;
		}
	}*/
	for(int i=1;i<=n;i++)
	{
		for(int i2=1;i2<=m;i2++)
		{
			long long temp=max(dp[i][i2-1][0],dp[i][i2-1][1]);
			dp[i][i2][0]=max(temp,dp[i][i2-1][2])+a[i][i2];
			
			dp[i][i2][2]=max(dp[i-1][i2][0],dp[i-1][i2][2])+a[i][i2];
		}
		for(int i3=m;i3>=1;i3--)
		dp[i][i3][1]=max(dp[i+1][i3][0],dp[i+1][i3][1])+a[i][i3];
	}
//	cout<<ans<<endl;
//	doit(0,1,1,0);
	cout<<max(max(dp[n][m][0],dp[n][m][1]),dp[n][m][2]);
	fclose(stdout);
	fclose(stdin);
return 0;
}