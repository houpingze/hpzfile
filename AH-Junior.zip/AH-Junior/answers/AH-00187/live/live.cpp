#include<bits/stdc++.h>
using namespace std;
int a[100010];
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	int m,w;cin>>m>>w;
	for(int i=1;i<=m;i++)
	{
		int l=i-max(1,w*i/100)+1;
		cin>>a[i];
		sort(a+1,a+i+1);
		cout<<a[l]<<" ";
	}
return 0;
}