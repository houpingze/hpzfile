#include<bits/stdc++.h>
using namespace std;
int main()
{
	
	srand(time(0));
	for(int i=1;i<=rand()%5+1;i++)
	cout<<rand()%2<<' ';
	
return 0;
}