#include<bits/stdc++.h>
using namespace std;
long long a[33];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	long long b;cin>>b;
	if(b%2==1)
	{
		cout<<"-1";return 0;
	}
	else 
	{
		long long temp=b;
		for(int i=1;temp!=0;i++)
		{
			a[i]=temp&1;
			temp=temp>>1;
		}
		long long wei=1<<29;
		for(int i=29;i>=1;i--)
		{
			wei=wei>>1;
			if(a[i]!=0)
			{
				cout<<wei<<' ';
			}
		}
	}
	fclose(stdout);
return 0;
}