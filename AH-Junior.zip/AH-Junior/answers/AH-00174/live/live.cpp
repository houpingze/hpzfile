#include <bits/stdc++.h>
using namespace std;
int n,w,x,xi,t[601],i,j,s;
int main () {
	freopen ("live.in","r",stdin);
	freopen ("live.out","w",stdout);
	scanf ("%d%d",&n,&w);
	for (i=1;i<=n;i++) {
		s=0;
		x=(i*w/100);
		if (x<1) x=1;
		scanf ("%d",&xi);
		t[xi]++;
		for (j=600;j>=0;j--) {
			s+=t[j];
			if (s>=x) {
				printf ("%d ",j);
				break;
			}
		}
	}
	return 0;
}