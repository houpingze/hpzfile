#include <bits/stdc++.h>
using namespace std;
int n,m,x[100001],i,j,k,q,x1,x2;
char c[1000001];
struct exp {int xi; char ci;}a[1000001];
int rp (int i) {
	if (a[i].ci=='!') return (rp(i-1)==1?0:1);
	if (a[i].xi!=-1) return a[i].xi;
	int j=i-1;
	while (a[j].ci=='!') j--;
	if (a[i].ci=='&') return rp(i-1)&&rp(j-1);    
	if (a[i].ci=='|') return rp(i-1)||rp(j-1);      
	return a[i].xi;
}
int main () {
	freopen ("expr.in","r",stdin);
	freopen ("expr.out","w",stdout);
	while (1) {
		m++;
		scanf ("%c",&c[m]);
		if (c[m]=='\n') break;
	}
	scanf ("%d",&n);
	for (i=1;i<=n;i++) scanf ("%d",&x[i]);
	scanf ("%d",&q);
	while (q--) {
		scanf ("%d",&x1);
		x[x1]=(x[x1]==1?0:1);
		for (i=1,k=0;i<=m;i++) {
			if (c[i]==' ') continue;
			if (c[i]=='|'||c[i]=='&'||c[i]=='!') k++,a[k].ci=c[i],a[k].xi=-1;
			if (c[i]=='x') {
				k++,x2=0,j=i+1;
				while (c[j]!=' ') x2*=10,x2+=(c[j]-48),j++;
				i=j,a[k].xi=x[x2];
			}
		}
		printf ("%d\n",rp(k));
		x[x1]=(x[x1]==1?0:1);
	}
	return 0;
}