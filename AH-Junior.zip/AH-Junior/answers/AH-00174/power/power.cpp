#include <bits/stdc++.h>
using namespace std;
int n,x[10000001],ans[10000001],i,j,k;
int main () {
	freopen ("power.in","r",stdin);
	freopen ("power.out","w",stdout);
	scanf ("%d",&n);
	if (n%2==1) {printf ("-1"); return 0;}
	for (i=0,k=2;k<=n;k*=2) x[++i]=k;
	for (j=1;;j++) {
		if (n==0) break;
		while (x[i]>n) i--;
		ans[j]=x[i];
		n-=x[i];
	}
	for (int i=1;i<j;i++) printf ("%d ",ans[i]);
	return 0;
}