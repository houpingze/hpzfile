#include <bits/stdc++.h>
using namespace std;
int n,m,i,j,a[1001][1001],f[1001][1001],ans=-10000000;
void dfs (int i,int j,int s) {
	s+=a[i][j];
	if (i==n&&j==m) {
		if (s>ans) ans=s;
		return;
	}
	f[i][j]=1;
	if (i>1&&f[i-1][j]==0) dfs (i-1,j,s);
	if (i<n&&f[i+1][j]==0) dfs (i+1,j,s);
	if (j<m&&f[i][j+1]==0) dfs (i,j+1,s);
	f[i][j]=0;
	return;
}
int main () {
	freopen ("number.in","r",stdin);
	freopen ("number.out","w",stdout);
	scanf ("%d%d",&n,&m);
	for (i=1;i<=n;i++) for (j=1;j<=m;j++) scanf ("%d",&a[i][j]);
	dfs (1,1,0);
	printf ("%d",ans);
	return 0;
}