#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
         freopen("live.in","r",stdin);
         freopen("live.out","w",stdout);
        int n=0,s=0,p=0;
         cout<<0<<1<<1;
         return 0;
         fclose(stdin);
         fclose(stdout);
}