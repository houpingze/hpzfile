#include<iostream>
#include<cstdio>
using namespace std;
int a[1700];
int main()
{
     freopen("live.in","r",stdin);
     freopen("live.out","w",stdout);
     int n,w;
     cin>>n>>w;
     for(int i=1;i<=n;i++)
    {
          cin>>a[i];
    }
	for(int i=1;i<=n;i++)
	{
		cout<<100;
	}
	
    return 0;
    fclose(stdin);
    fclose(stdout);
}
