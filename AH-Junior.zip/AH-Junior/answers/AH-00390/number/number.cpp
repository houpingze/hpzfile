#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
		freopen("number.in","r",stdin);
		freopen("number.out","w",stdout);
  cout<<0;
return 0;
	 fclose(stdin);
		fclose(stdout);
}