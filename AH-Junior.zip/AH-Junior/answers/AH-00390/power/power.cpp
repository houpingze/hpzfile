#include<iostream>
#include<cstdio>
using namespace std;
int a[100000001];
int main()
{
    freopen("power.in","r",stdin);
     freopen("power.out","w",stdout);
     int n;
     cin>>n;
     if(n%2!=0) 
     cout<<-1;
     return 0;
     fclose(stdin);
   fclose(stdout);
}
