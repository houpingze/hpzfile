#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e5;
const long long maxm=600;
long long n,w;
long long p[maxn+10];
long long cnt[1000];
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%lld%lld",&n,&w);
	for(long long i=1;i<=n;i++){
		p[i]=1.0*i*w/100.0;
		if(p[i]==0)p[i]=1;
	}
	for(long long i=0;i<=600;i++)cnt[i]=0;
	for(long long i=1;i<=n;i++){
		long long t;
		scanf("%lld",&t);
		cnt[t]++;
		long long sum=0;
		for(long long j=600;j>=0;j--){
			sum+=cnt[j];
			if(sum-cnt[j]<p[i]&&p[i]<=sum){
				printf("%lld ",j);
				break;
			}
		}
	}
	return 0;
}