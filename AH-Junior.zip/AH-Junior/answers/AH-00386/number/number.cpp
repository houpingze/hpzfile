#include<bits/stdc++.h>
using namespace std;
const long long maxn=1000;
const long long maxm=1000;
long long n,m,cnt;
long long a[maxn+10][maxm+10];
long long dp[maxn+10][maxn+10];
long long max(long long u,long long v){
	if(u>v)return u;
	else return v;
}
long long min(long long u,long long v){
	if(u<v)return u;
	else return v;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(long long i=1;i<=n;i++){
		for(long long j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
		}
	}
	for(long long i=1;i<=n;i++){
		for(long long j=1;j<=m;j++){
			dp[i][j]=-LLONG_MAX;
		}
	}
	long long sum=0;
	for(long long j=1;j<=n;j++){
		sum+=a[j][1];
		dp[j][1]=sum;
	}
	for(long long i=2;i<=m;i++){
		long long pos;
		
		cnt=dp[1][i-1]+a[1][i];
		dp[1][i]=max(dp[1][i],cnt);
		for(long long j=2;j<=n;j++){
			pos=a[j][i];
			dp[j][i]=max(dp[j][i],max(dp[j][i-1],cnt)+pos);
			cnt=max(cnt,dp[j][i-1]);
			cnt+=pos;
		}
		
		cnt=dp[n][i-1]+a[n][i];
		dp[n][i]=max(dp[n][i],cnt);
		for(long long j=n-1;j>=1;j--){
			pos=a[j][i];
			dp[j][i]=max(dp[j][i],max(dp[j][i-1],cnt)+pos);
			cnt=max(cnt,dp[j][i-1]);
			cnt+=pos;
		}
	}
	printf("%lld\n",dp[n][m]);
	return 0;
}