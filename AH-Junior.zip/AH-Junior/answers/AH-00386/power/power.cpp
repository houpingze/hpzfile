#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e7;
long long n;
long long quick_pow(long long a,long long b){
	long long ret=1;
	while(b){
		if(b&1)ret=ret*a;
		a=a*a;
		b>>=1;
	}
	return ret;
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	scanf("%lld",&n);
	if(n%2==1){
		long long ans=-1;
		printf("%lld",ans);
	}
	else{
		for(long long i=32;i>=1;i--){
			if(n&(1<<i)){
				printf("%lld ",quick_pow(2,i));
			}
		}
	}
	return 0;
}