#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e5;
char a;
long long n,q;
long long x[maxn+10];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	long long sum1=0,sum2=0;
	while(cin>>a){
		if(a=='\n')break;
		if(a=='|')sum1++;
		if(a=='&')sum2++;
	}
	scanf("%lld",&n);
	for(long long i=1;i<=n;i++)scanf("%lld",&x[i]);
	scanf("%lld",&q);
	while(q--){
		long long pos;
		scanf("%lld",&pos);
		if(sum1==0||sum2==0){
			if(sum1==0){
				cout<<1<<'\n';
			}
			else{
				cout<<0<<'\n';
			}
		}
		else{
			cout<<0<<'\n';
		}
	}
	return 0;
}