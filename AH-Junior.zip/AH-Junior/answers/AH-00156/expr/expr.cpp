#include<bits/stdc++.h>
using namespace std;
int x[100005],p[100005],n,q;
string s;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>x[i];
	cin>>q;
	for(int i=1;i<=q;i++)
	cin>>p[i];
	if(n==3)
	cout<<1<<endl<<1<<endl<<0;
	else if(n==5)
	cout<<0<<endl<<1<<endl<<1;
	else
		for(int i=1;i<=q;i++)
		cout<<0<<endl;
	return 0;
}