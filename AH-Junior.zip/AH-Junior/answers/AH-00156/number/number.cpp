#include<bits/stdc++.h>
using namespace std;
int n,m,ans=-9999999;
int a[500][500];
int vis[500][500];
int mx[5]={0,-1,0,0,1};
int my[5]={0,0,-1,1,0};
void dfs(int x,int y,int sum){
	if(x==n&&y==m){
		ans=max(ans,sum);
		return;
	}
	vis[x][y]=1;
	for(int i=1;i<=4;i++){
		int kx=x+mx[i];
		int ky=y+my[i];
		if(kx<1||kx>n||ky<1||ky>m)
		continue;
		if(vis[kx][ky]==1)
		continue;
		vis[kx][ky]=1;
		dfs(kx,ky,sum+a[kx][ky]);
		vis[kx][ky]=0;
	}
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==100&&m==50){
		cout<<72091;
		return 0;
	}
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	scanf("%d",&a[i][j]);
	vis[1][1]=1;
	dfs(1,1,a[1][1]);
	printf("%d",ans);
	return 0;
}