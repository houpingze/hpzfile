#include<bits/stdc++.h>
using namespace std;
int n,w;
int a[100005];
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sort(a+1,a+i+1,cmp);
	printf("%d ",a[max(1,i*w/100)]);
		//cout<<a[max(1,i*w/100)]<<" ";
	}
	return 0;
}