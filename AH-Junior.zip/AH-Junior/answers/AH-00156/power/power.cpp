#include<bits/stdc++.h>
using namespace std;
long long k,n,flag,p=1,vis[200000];
int m[15]={0,1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192};
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2!=0){
		cout<<-1;
		return 0;
	}
	for(int i=1;i<=32;i++){
		k*=2;
		if(k==n){
			cout<<n;
			return 0;
		}
	}
	while(1){
		n/=2;
		p*=2;
		if(n%2!=0){
			if(n==3)
			cout<<p*2<<" "<<p,flag=1;
			else if(n==5)
			cout<<p*4<<" "<<p,flag=1;
			else if(n==7)
			cout<<p*4<<" "<<p*2<<" "<<p,flag=1;
			else if(n==9)
			cout<<p*8<<" "<<p,flag=1;
			else if(n==11)
			cout<<p*8<<" "<<p*2<<" "<<p,flag=1;
			else if(n==13)
			cout<<p*8<<" "<<p*4<<" "<<p,flag=1;
			else if(n==15)
			cout<<p*8<<" "<<p*4<<" "<<p*2<<" "<<p,flag=1;
			else if(n==17)
			cout<<p*16<<" "<<p,flag=1;
			else if(p==19)
			cout<<p*16<<" "<<p*2<<" "<<p,flag=1;
			else if(p==21)
			cout<<p*16<<" "<<p*4<<" "<<p,flag=1;
			else{
			while(n>0){
				for(int i=1;i<=15;i++)
				if(m[i]>n&&!vis[m[i-1]]){n-=m[i-1];vis[m[i-1]]=1;break;}
				if(n==0){
					flag=1;
					for(int i=8192;i>=1;i--)
					if(vis[i]==1)
					cout<<p*i<<" ";
				}
			}}
			if(flag==0)
			cout<<-1;
		}
		return 0;
	}
	return 0;
}