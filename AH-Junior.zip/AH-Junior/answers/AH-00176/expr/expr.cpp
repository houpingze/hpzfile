#include <iostream>
#include <cstdio>
#include <stack>
#include <cstring>
#include <sstream>
using namespace std;
const int N = 1e5 + 5;
string buf;
string s;
stack<int> d;
stack<char> o;
int n, x[N], q, p;
void calc(){
	int x;
	x = d.top(); d.pop();
	char op = o.top(); o.pop();
	if(op == '!') d.push(!x); 
	else{
		int y = d.top(); d.pop();
		if(op == '|') d.push(x || y);
		else if(op == '&') d.push(x && y);
	}
}
int main(){
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	getline(cin, s);
	cin >> n;
	for(int i=1; i<=n; i++) cin >> x[i];
		cin >> q;
	while(q--){
		while(!d.empty()) d.pop();
		while(!o.empty()) o.pop();
		cin >> p;
		x[p] = !x[p];
		stringstream ss(s);
		while(ss >> buf){
			if(buf[0] == 'x'){
				int len = buf.size(), num = 0;
				for(int i=1; i<len; i++)
					num = num*10 + (buf[i]-'0');
				d.push(x[num]);
			}
			else if(buf[0] == '&' || buf[0] == '|' || buf[0] == '!'){
				o.push(buf[0]);
				calc();
			}
		}
		while(!o.empty()) calc();
		cout << d.top() << endl;
		x[p] = !x[p];
	}
	return 0;
}