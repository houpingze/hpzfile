#include <iostream>
#include <cstdio>
using namespace std;
const int N = 1005, M = 1005, dlt[4][2] = {{1, 0}, {-1, 0}, {0, 1}};
int n, m, a[N][M], ans = -0x3f3f3f3f;
bool vis[N][M];
bool inline check(int x, int y){
	return x>=1 && x<=n && y>=1 && y<=m && !vis[x][y];
}
void dfs(int x, int y, int sum){
	if(x == n && y==m){
		ans = max(ans, sum);
		return ;
	}
	for(int i=0; i<4; i++){
		int dx = x+dlt[i][0], dy = y+dlt[i][1];
		if(check(dx, dy)){
			vis[dx][dy] = true;
			dfs(dx, dy, sum + a[dx][dy]);
			vis[dx][dy] = false;
		}
	}
}
int main(){
	freopen("number.in", "r", stdin);
	freopen("number.out", "w", stdout);
	cin >> n >> m;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++)
			cin >> a[i][j];
		vis[1][1] = true;
		dfs(1, 1, a[1][1]);
		cout << ans;
	return 0;
}