#include <iostream>
#include <cstdio>
using namespace std;
const int N = 25;
int n, a[N], x;
int main(){
	freopen("power.in", "r", stdin);
	freopen("power.out", "w", stdout);
	scanf("%d", &n);
	if(n%2 == 1)
		cout << -1;
	else{
		a[0] = 1;
		for(int i=1; i<=N; i++){
			if(a[i-1] * 2 > n){
				x = i-1;
				break;
			}	
			a[i] = a[i-1] * 2;
		}
		while(n){
			cout << a[x] << " ";
			n -= a[x];
			for(int i=x-1; i>=1; i--)
				if(a[i] <= n){
					x = i;
					break;
				}
		}
	}
	return 0;
}