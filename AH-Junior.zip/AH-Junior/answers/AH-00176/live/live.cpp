#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
const int S = 605;
int n, w, s, b[605], p;
int main(){
	freopen("live.in", "r", stdin);
	freopen("live.out", "w", stdout);
	scanf("%d %d", &n, &w);
	for(int i=1; i<=n; i++){
		scanf("%d", &s);
		b[s]++;
		p = max(1, i*w/100);
		for(int j=600; j>=0; j--)
			if(p <= b[j]){
				cout << j << " ";
				break;
			}
			else p -= b[j];
	}
	return 0;
}