#include<iostream>
#include<cstdio>
using namespace std;
long long power(long long a)
{
	long long s=1;
	for(long long ii=1;ii<=a;ii++)
	{
		s*=2;
	}
	return s;
}
long long n,k,a[100];
int main()
{
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2==1)
	{
		cout<<-1;
		return 0;
	}
	else
	{
		for(int i=1;power(i)<=n;i++)
		{
			if(power(i)==n)
			{
				cout<<n;
				return 0;
			}
			k=i;
		}
		int m=n;
		for(int i=k;i>=1;i--)
		{
			if(m-power(i)<0)
			{
				continue;
			}
			//cout<<"i="<<i<<endl;
			m-=power(i);
			a[i]=power(i);
			if(m==0)
			{
				for(int j=k;j>=i;j--)
				{
					if(a[j]!=0)
					cout<<a[j]<<' ';
				}
			}
		}
	}
	return 0;
}