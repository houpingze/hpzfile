#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
using namespace std;
int n,w,a[100001],ton[600];
int cmp(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		ton[a[i]]++;
		sort(a+1,a+n+1,cmp);
		/*for(int ji=1;ji<=n;ji++)
		{
			cout<<a[ji]<<' ';
		}cout<<endl;*/
		cout<<a[max(100,i*w)/100]<<' ';
	}
	return 0;
}