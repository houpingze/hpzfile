#include<iostream>
#include<cstdio>
using namespace std;
int m,n,a[1001][1001],s;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	for(int i=0;i<=1001;i++)
		a[1][i]=a[i][1]=-1001;
	cin>>n>>m;
	for(int i=0;i<=m;i++)a[n+1][i]=-1001;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			if(i!=1||j!=1)
			a[i][j]+=max(max(a[i][j-1],a[i+1][j]),a[i-1][j]);
		}
	cout<<a[n][m];
		return 0;
}