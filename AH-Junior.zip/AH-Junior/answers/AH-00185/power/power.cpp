#include<iostream>
#include<cstdio>
using namespace std;
int flag=0,x,flag1=0;
unsigned long long ans[21];
unsigned long long n,a[21]={2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576};
int read(){
	long long int f=1,x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return f*x;
}
int main(){
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	n=read();
	if(n%2!=0){
		cout<<"-1";
		return 0;
		}
	for(int i=20;i>=0;i--){
		if(n>=a[i]){
			n-=a[i];
			ans[i]=a[i];
			if(flag1==0){
				x=i;
			    flag1=1;
			}
		}
		if(n==0){
			flag=1;
			break;
		}
	}
	if(flag) 
		for(int i=x;i>=0;i--){
		if(ans[i]!=0) cout<<ans[i]<<" ";
		}
	else cout<<"-1";
	fclose(stdin);
	fclose(stdout);
	return 0;
}