#include<iostream>
#include<cstdio>
using namespace std;
//char ch;
char ch[100001];
int n,q,x[100005],a[100005];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	//ch=getchar();
	//while(ch<'0'||ch>'9') ch=getchar();
	gets(ch);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>x[i];
	cin>>q;
	for(int i=1;i<=q;i++) cin>>a[i];
	for(int i=1;i<=q;i++){
		cout<<"0"<<endl;
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}