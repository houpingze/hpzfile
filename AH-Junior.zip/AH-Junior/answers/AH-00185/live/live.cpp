#include<iostream>
#include<algorithm>
#include<cmath>
#include<deque>
#include<cstdio>
using namespace std;
long long n;
int w,data[1000005],ans;
bool cmp(int a,int b){
	return a>b;
}
int read(){
	long long int f=1,x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return f*x;
}
int main(){
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	n=read();
	w=read();
	for(int i=1;i<=n;i++){
		data[i]=read();
		sort(data+1,data+i+1,cmp);
		ans=floor(double(i*w)/100);
		ans=max(1,ans);
		cout<<data[ans]<<" "; 
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}