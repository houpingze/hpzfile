#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int m,n,max_=-2147483647,sum;
int a[1001][1001],vis[1001][1001],dir[3][2]={{-1,0},{1,0},{0,1}};
void dfs(int x,int y){
	sum+=a[x][y];
	if(x==m&&y==n){
		sum-=a[x][y];
		max_=max(max_,sum);
		return ;
		}
	for(int i=0;i<3;i++){
		int nx=x+dir[i][0];
		int ny=y+dir[i][1];
		if(nx>=1&&nx<=m&&ny>=1&&ny<=n&&vis[nx][ny]==0){
			vis[nx][ny]=1;
			dfs(nx,ny);
			//vis[nx][ny]=0;
		}
	}
	sum-=a[x][y];
	//max_=max(max_,sum);
	return ;
	}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];
			}
		}
	dfs(1,1);
	cout<<max_; 
	fclose(stdin);
	fclose(stdout);
	return 0;
}