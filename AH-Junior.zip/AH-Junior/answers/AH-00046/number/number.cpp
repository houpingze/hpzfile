#include<iostream>
using namespace std;
int a[ ];
int main()
{
	return 0;
}
	