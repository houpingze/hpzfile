#include<iostream>
using namespace std;
int a[ ]{
	int m;
	if(printf%2;m)
	cout<<m<<endl;
	else;
	cout return 0;
	return 1;
}
int mi(int m)
int wx(int m)
{
	//freoren(
	//freoren(

	return 0;
}