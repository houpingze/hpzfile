//#include <bits/stdc++.h>
//by bcnet
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <iostream>
//#include <cstdlib>
using namespace std;
int main()
{
	string a;
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	if(a=="x1 x2 & x3 |")cout<<1<<endl<<1<<endl<<0;
	if(a=="x1 ! x2 x4 | x3 x5 ! & & ! &")cout<<1<<endl<<1<<endl<<0;
	return 0;
}