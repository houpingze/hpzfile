//#include <bits/stdc++.h>
//by bcnet
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <iostream>
//#include <cstdlib>
using namespace std;
int cmp(int x,int y)
{
return x>y;
}
int main()
{
	int n,w,a[100010],planP,ans[100010];
	freopen("live.in","r",stdin);
	freopen("live.out","w",stdout);
	cin>>n>>w;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		sort(a+1,a+n+1,cmp);
		planP=max(1,i*w)/100;
		if(planP==0)planP=1;
		//if(a[planP+1]==a[planP])
		ans[i]=a[planP];
		cout<<ans[i];if(i!=n)cout<<" ";
	}

	return 0;
}