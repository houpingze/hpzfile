//#include <bits/stdc++.h>
//by bcnet
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <iostream>
//#include <cstdlib>
using namespace std;
long long a[10000000],i;
int func(long long t)
{
	i+=1;
	if(t==2||t==0||t==1)return 0;
//	if(t/2%2!=0){if()}return 1;
	a[i]=t/2;
	func(t/2);
}
int main()
{
	long long n,i;
	freopen("power.in","r",stdin);
	freopen("power.out","w",stdout);
	cin>>n;
	if(n%2!=0){cout<<-1;return 0;}
	for(i=1;i<=n/2;i++)
	if(pow(2,i)==n&&long(pow(2,i))/2%2!=0)break;
	if(func(i)==1){cout<<-1;return 0;}
	if(i==6){cout<<8<<" "<<2;return 0;}
	cout<<i<<" ";
	for(i=1;i<=n/2;i++){if(a[i]==0||a[i]==1)return 0;if(a[i]==6){cout<<8<<" "<<2;return 0;}cout<<a[i];if(i!=n/2&&a[i]!=2)cout<<" ";}
	return 0;
}